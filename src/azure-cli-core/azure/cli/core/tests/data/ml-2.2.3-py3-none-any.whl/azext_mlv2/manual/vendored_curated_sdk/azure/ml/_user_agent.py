# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.version import VERSION

USER_AGENT = "{}/{}".format("azure-ml", VERSION)
