# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any, Union, List, Dict, Tuple
import json

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    FeaturizationSettings as RestFeaturizationSettings,
)

module_logger = logging.getLogger(__name__)


class CustomFeaturizationSettings(RestTranslatableMixin):
    """Base class for custom featurization settings on a set of given fields

    :param fields: The fields on which to perform custom featurization
    """

    def __init__(
        self,
        fields: List[str] = None,
    ):
        self.fields = fields

    def _to_rest_object(self) -> Tuple[List[str], Dict[str, Any]]:
        dict_repr = self.__dict__.copy()
        dict_repr.pop(AutoMLConstants.FIELDS, None)
        return (self.fields, dict_repr)

    def __eq__(self, other: "CustomerFeaturizationSettings") -> bool:
        return self.fields == other.fields


class ImputerSettings(CustomFeaturizationSettings):
    """Imputer settings for a given set of fields

    :param fields:
    :type field: List[str]
    :param strategy: Strategy used to fill missing fields. The options are: 'constant', 'median', 'ffill', 'mean', 'most_frequent'
    :type strategy: str
    :param fill_value: If the strategy is "constant", value to use to fill missing values for the fields
    """

    def __init__(self, strategy: str = None, fill_value: float = None, **kwargs):
        super().__init__(**kwargs)
        self.strategy = strategy
        self.fill_value = fill_value

    @classmethod
    def _from_rest_obj(self, obj: Tuple[List[str], Dict[str, Any]]) -> "ImputerSettings":
        fields, props_dict = obj
        return ImputerSettings(fields=fields, **props_dict)

    def __eq__(self, other: "ImputerSettings") -> bool:
        return super().__eq__(other) and self.strategy == other.strategy and self.fill_value == other.fill_value

    def __ne__(self, other: "ImputerSettings") -> bool:
        return not self.__eq__(other)


class HashOneHotEncoderSettings(CustomFeaturizationSettings):
    """Hash one hot encoding settings for a set of fields

    :param fields: List of fields to apply hash one hot encoding settings
    :type fields: List[str]
    :param number_of_bits: Number of bits to use in hash one hot encoding
    :type number_of_bits: int
    """

    def __init__(self, number_of_bits: int = None, **kwargs):
        super().__init__(**kwargs)
        self.number_of_bits = number_of_bits

    @classmethod
    def _from_rest_obj(self, obj: Tuple[List[str], Dict[str, Any]]) -> "HashOneHotEncoderSettings":
        fields, props_dict = obj
        return HashOneHotEncoderSettings(fields=fields, **props_dict)

    def __eq__(self, other: "HashOneHotEncoderSettings") -> bool:
        return super().__eq__(other) and self.number_of_bits == other.number_of_bits

    def __ne__(self, other: "HashOneHotEncoderSettings") -> bool:
        return not self.__eq__(other)


class TransformerParameters(RestTranslatableMixin):
    """Transformer parameters for custom featurization

    :param imputer: List of imputer settings
    :type imputer: List[ImputerSettings]
    :param hash_one_hot_encoder: List of hash one-hot encoding settings
    :type hash_one_hot_encoder: List[HashOneHotEncoderSettings]
    """

    def __init__(
        self,
        imputer: List[ImputerSettings] = None,
        hash_one_hot_encoder: List[HashOneHotEncoderSettings] = None,
        tfidf: Dict[str, Any] = None,
    ):
        self.imputer = imputer
        self.hash_one_hot_encoder = hash_one_hot_encoder
        self.tfidf = tfidf

    def _to_rest_object(self) -> Dict[str, Any]:
        rest_imputers = [i._to_rest_object() for i in self.imputer]
        rest_one_hot_encoders = [o._to_rest_object() for o in self.hash_one_hot_encoder]
        rest_dict = {}
        if rest_imputers:
            rest_dict[AutoMLConstants.IMPUTER] = rest_imputers
        if rest_one_hot_encoders:
            rest_dict[AutoMLConstants.HASH_ONE_HOT_ENCODER] = rest_one_hot_encoders
        if self.tfidf:
            rest_dict[AutoMLConstants.TFIDF] = self.tfidf
        return rest_dict

    @classmethod
    def _from_rest_object(cls, obj: Dict[str, Any]) -> "TransformerParameters":
        return TransformerParameters(
            imputer=[ImputerSettings._from_rest_obj(i) for i in obj.get(AutoMLConstants.IMPUTER, None)],
            hash_one_hot_encoder=[
                HashOneHotEncoderSettings._from_rest_obj(i) for i in obj.get(AutoMLConstants.HASH_ONE_HOT_ENCODER, None)
            ],
            tfidf=obj.get(AutoMLConstants.TFIDF, None),
        )

    def __eq__(self, other: "TransformerParameters") -> bool:
        return (
            self.imputer == other.imputer
            and self.hash_one_hot_encoder == other.hash_one_hot_encoder
            and self.tfidf == other.tfidf
        )

    def __ne__(self, other: "TransformerParameters") -> bool:
        return not self.__eq__(other)


class FeaturizationConfig(RestTranslatableMixin):
    """Custom featurization configuration

    :param blocked_transformers: A list of transformers to ignore when featurizing.
    :type blocked_transformers: List[str]
    :param column_purposes: A dictionary of column names and feature types used to update column purpose.
    :type column_purposes: Dict[str, str]
    :param transformer_params: Object of transformer and corresponding customization parameters
    :type transformer_params: TransformerParams
    """

    def __init__(
        self,
        blocked_transformers: List[str] = None,
        column_purposes: Dict[str, str] = None,
        transformer_params: TransformerParameters = None,
    ):
        self.blocked_transformers = blocked_transformers
        self.column_purposes = column_purposes
        self.transformer_params = transformer_params

    def _to_rest_object(self) -> Dict[str, Any]:
        dict_repr = self.__dict__.copy()
        dict_repr[AutoMLConstants.TRANSFORMER_PARAMS] = (
            self.transformer_params._to_rest_object() if self.transformer_params else None
        )
        return json.dumps(dict_repr)

    @classmethod
    def _from_rest_object(cls, obj: Dict[str, Any]) -> "FeaturizationConfig":
        rest_transformers_params = obj.pop("_" + AutoMLConstants.TRANSFORMER_PARAMS, None)
        transformer_params = (
            TransformerParameters._from_rest_object(rest_transformers_params) if rest_transformers_params else None
        )
        column_purposes = obj.pop("_" + AutoMLConstants.COLUMN_PURPOSES, None)
        blocked_transformers = obj.pop("_" + AutoMLConstants.BLOCKED_TRANSFORMERS, None)
        return FeaturizationConfig(
            transformer_params=transformer_params,
            column_purposes=column_purposes,
            blocked_transformers=blocked_transformers,
        )

    def __eq__(self, other: "FeaturizationConfig") -> bool:
        return (
            self.blocked_transformers == other.blocked_transformers
            and self.column_purposes == other.column_purposes
            and self.transformer_params == other.transformer_params
        )

    def __ne__(self, other: "FeaturizationConfig") -> bool:
        return not self.__eq__(other)


class FeaturizationSettings(RestTranslatableMixin):
    """Featurization settings for an AutoML Job

    :param featurization_config: Depending on the value, represents if featurization step should be done automatically or not, or whether customized featurization should be used. Takes one of: "auto", "off", or a custom featurization configuration
    :type featurization_config: Union[str, FeaturizationConfig]
    :param enable_dnn_featurization: Whether or ot BERT DNN based featurization should be enabled. Default is False.
    :type enable_dnn_featurization: bool
    """

    def __init__(
        self, featurization_config: Union[str, FeaturizationConfig] = None, enable_dnn_featurization: bool = None
    ):
        self.featurization_config = featurization_config
        self.enable_dnn_featurization = enable_dnn_featurization

    def _to_rest_object(self) -> RestFeaturizationSettings:
        if isinstance(self.featurization_config, str):
            featurization_config = json.dumps({AutoMLConstants.MODE: self.featurization_config.lower()})
        else:
            featurization_config = self.featurization_config._to_rest_object() if self.featurization_config else None
        return RestFeaturizationSettings(
            featurization_config=featurization_config,
            enable_dnn_featurization=self.enable_dnn_featurization,
        )

    @classmethod
    def _from_rest_object(cls, obj: RestFeaturizationSettings) -> "FeaturizationSettings":
        featurization_config = obj.featurization_config
        if featurization_config.lower() != AutoMLConstants.OFF and featurization_config.lower() != AutoMLConstants.AUTO:
            featurization_config = FeaturizationConfig._from_rest_object(json.loads(featurization_config))
        return FeaturizationSettings(
            featurization_config=featurization_config,
            enable_dnn_featurization=obj.enable_dnn_featurization,
        )

    def __eq__(self, other: "FeaturizationSettings") -> bool:
        return (
            self.featurization_config == other.featurization_config
            and self.enable_dnn_featurization == other.enable_dnn_featurization
        )

    def __ne__(self, other: "FeaturizationSettings") -> bool:
        return not self.__eq__(other)
