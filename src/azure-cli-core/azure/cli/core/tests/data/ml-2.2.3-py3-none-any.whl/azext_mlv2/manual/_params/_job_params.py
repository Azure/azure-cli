# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_max_results_params, add_include_archived_param
from azure.cli.core.commands.parameters import get_three_state_flag


def add_job_common_params(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the job.")


def load_job_params(self):
    with self.argument_context("ml job create") as c:
        add_common_params(c)
        add_job_common_params(c)
        add_override_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML job specification.",
        )
        c.argument(
            "save_as",
            options_list=["--save-as", "-a"],
            help="File to which the created job's state in YAML format will be written.",
        )
        c.argument(
            "stream", options_list=["--stream", "-s"], help="Indicates whether to stream the job's logs to the console."
        )
        c.argument(
            "web", options_list=["--web", "-e"], help="Show the job's run details in Azure ML studio in a web browser."
        )

    with self.argument_context("ml job update") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument(
            "web", options_list=["--web", "-e"], help="Show the job's run details in Azure ML studio in a web browser."
        )

    with self.argument_context("ml job list") as c:
        add_common_params(c)
        c.argument(
            "max_results",
            options_list=["--max-results", "-r"],
            type=int,
            help="Max number of results to return. Default is 50",
        )
        c.argument("all_results", arg_type=get_three_state_flag(), help="Returns all results.")
        add_include_archived_param(c, help_message="List archived jobs and active jobs.")

        c.argument(
            "parent_job_name",
            options_list=["--parent-job-name", "-p"],
            type=str,
            help="Name of the parent job. Will list all jobs whose parent_job_name matches the given name.",
        )
    with self.argument_context("ml job show") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument(
            "web", options_list=["--web", "-e"], help="Show the job's run details in Azure ML studio in a web browser."
        )

    with self.argument_context("ml job download") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument(
            "download_path",
            options_list=["--download-path", "-p"],
            help="Path to download the job files to. If omitted, job files will be downloaded to the current directory.",
        )
        c.argument(
            "output_name",
            options_list=["--output-name"],
            help="The name of the user-defined output to download. This should correspond to a key in the outputs dictionary of a job. If omitted, the job's default artifact output files will be downloaded.",
        )
        c.argument("all", options_list=["--all"], help="Download all the outputs of the job.")

    with self.argument_context("ml job stream") as c:
        add_common_params(c)
        add_job_common_params(c)

    with self.argument_context("ml job cancel") as c:
        add_common_params(c)
        add_job_common_params(c)

    with self.argument_context("ml job archive") as c:
        add_common_params(c)
        add_job_common_params(c)

    with self.argument_context("ml job restore") as c:
        add_common_params(c)
        add_job_common_params(c)
