# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    ComponentVersionResource,
    ComponentVersion,
    Component as RestComponent,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.command_component import CommandComponentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Environment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import AMLVersionedArmId
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ParameterizedCommand
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BASE_PATH_CONTEXT_KEY,
    COMPONENT_TYPE,
    ComponentType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.component.utils import component_io_from_rest_obj, component_io_to_rest_obj

from .component import Component


class CommandComponent(Component, ParameterizedCommand):
    """Command component.

    :param name: Name of the resource.
    :type name: str
    :param version: Version of the resource.
    :type version: int
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param type:  Type of the component, supported is 'command_component'.
    :type type: str
    :param description: Description of the resource.
    :type description: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param display_name: Display name of the component.
    :type display_name: str
    :param is_deterministic: Whether the component is deterministic.
    :type is_deterministic: bool
    :param inputs: Inputs of the component.
    :type inputs: ComponentInputs
    :param outputs: Outputs of the component.
    :type outputs: ComponentOutputs
    :param command: Command to be executed in component.
    :type command: str
    :param code: Code file or folder that will be uploaded to the cloud for component execution.
    :type code: Union[InternalCodeAsset, str]
    :param environment: Environment that component will run in.
    :type environment: Union[Environment, str]
    """

    def __init__(self, parameters={}, **kwargs):
        kwargs[COMPONENT_TYPE] = ComponentType.COMMAND
        super().__init__(**kwargs)

    def dump_to_dict(self) -> Dict:
        """Dump the command component content into a dictionary."""
        return CommandComponentSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    def _get_environment_id(self) -> Union[str, None]:
        # Return environment id of environment
        # handle case when environment is defined inline
        if isinstance(self.environment, Environment):
            return self.environment.id
        else:
            return self.environment

    @classmethod
    def _load_from_dict(cls, data: Dict, context: Dict, **kwargs) -> "CommandComponent":
        return CommandComponent(**(CommandComponentSchema(context=context).load(data, **kwargs)))

    def _to_rest_object(self) -> ComponentVersionResource:
        self._validate()
        component = RestComponent(
            display_name=self.display_name,
            is_deterministic=self.is_deterministic,
            inputs=component_io_to_rest_obj(self.inputs),
            outputs=component_io_to_rest_obj(self.outputs),
        )
        properties = ComponentVersion(
            component=component,
            description=self.description,
            code_id=self.code,
            command=self._command,
            properties=self.properties,
            environment_id=self._get_environment_id(),
            tags=self.tags,
            is_anonymous=self.is_anonymous,
        )
        result = ComponentVersionResource(properties=properties)
        result.name = self.name
        return result

    @classmethod
    def _load_from_rest(cls, obj: ComponentVersionResource) -> "CommandComponent":
        arm_id = AMLVersionedArmId(obj.id)
        rest_component_version = obj.properties
        command_component = CommandComponent(
            name=arm_id.asset_name,
            version=int(arm_id.asset_version),
            display_name=rest_component_version.component.display_name,
            is_deterministic=rest_component_version.component.is_deterministic,
            id=obj.id,
            type=obj.type,
            description=rest_component_version.description,
            tags=rest_component_version.tags,
            inputs=component_io_from_rest_obj(rest_component_version.component.inputs),
            outputs=component_io_from_rest_obj(rest_component_version.component.outputs),
            properties=rest_component_version.properties,
            code=rest_component_version.code_id,
            environment=rest_component_version.environment_id,
            is_anonymous=rest_component_version.is_anonymous,
            command=rest_component_version.command,
        )

        return command_component

    def _validate(self) -> None:
        # TODO: more validation logic
        if self.name is None:
            raise NameError("Component name is required")
