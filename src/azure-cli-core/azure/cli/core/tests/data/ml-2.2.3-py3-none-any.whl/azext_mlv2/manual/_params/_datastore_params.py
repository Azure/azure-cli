# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_max_results_params


def load_datastore_params(self):
    with self.argument_context("ml datastore delete") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the datastore.")

    with self.argument_context("ml datastore show") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the datastore.")

    with self.argument_context("ml datastore list") as c:
        add_common_params(c)
        add_max_results_params(c)

    with self.argument_context("ml datastore create") as c:
        add_common_params(c)
        add_override_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML datastore specification.",
        )
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the datastore. This overwrites the 'name' field in the YAML file provided to --file/-f.",
        )

    with self.argument_context("ml datastore update") as c:
        add_common_params(c)
        add_override_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML datastore specification.",
        )
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the datastore. This overwrites the 'name' field in the YAML file provided to --file/-f.",
        )
