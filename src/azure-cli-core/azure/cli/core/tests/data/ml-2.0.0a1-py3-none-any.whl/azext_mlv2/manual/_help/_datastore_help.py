# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_datastore_help():
    helps[
        "ml datastore"
    ] = """
        type: group
        short-summary: Manage Azure ML datastores.
        long-summary: >
            Azure ML datastores securely link your Azure storage services to your workspace so that you can
            access your storage without having to hardcode the connection information into your scripts.
            The connection secrets, like the storage service's authentication credentials, are stored in your
            workspace's Key Vault.


            When you create a workspace, an Azure Storage account is automatically created as an associated
            resource. A blob container is created in this account, and its connection information is stored
            as a datastore named 'workspaceblobstore'. This serves as the workspace's default datastore,
            and the blob container is used to store your workspace artifacts and machine learning job logs
            and outputs.
    """
    helps[
        "ml datastore list"
    ] = """
        type: command
        short-summary: List datastores in a workspace.
    """
    helps[
        "ml datastore show"
    ] = """
        type: command
        short-summary: Show details for a datastore.
    """
    helps[
        "ml datastore create"
    ] = """
        type: command
        short-summary: Create a datastore.
        long-summary: >
            This connects the underlying Azure storage service to the workspace. The storage service
            types that can currently be connected to by creating a datastore include Azure Blob
            storage, Azure File Share, Azure Data Lake Storage Gen1 and Azure Data Lake Storage Gen2.
        examples:
        - name: Create a datastore from a YAML specification file
          text: az ml datastore create --file blobstore.yml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml datastore delete"
    ] = """
        type: command
        short-summary: Delete a datastore.
        long-summary: >
            This deletes the connection information to the storage service from the workspace but does
            not delete the underlying data in storage.
    """
    helps[
        "ml datastore update"
    ] = """
        type: command
        short-summary: Update a datastore.
        long-summary: >
            The 'description', 'tags', and 'credential' properties can be updated.
    """
