.. :changelog:

Release History
===============
0.0.5 (2017-06-21)
++++++++++++++++++
* No changes.

0.0.4 (2017-06-13)
++++++++++++++++++
* Remove useless line-too-long suppression
* Move all existing recording files to latest folder
* Fix various pylint disable rules

0.0.3 (2017-05-30)
++++++++++++++++++

* Add exception handler for endpoint list that provides a better message when the profile specified by '--profile-name' does not exist.

0.0.2 (2017-05-09)
++++++++++++++++++

* Minor fixes.

0.0.1 (2017-05-05)
++++++++++++++++++

* Add support for CDN commands.
