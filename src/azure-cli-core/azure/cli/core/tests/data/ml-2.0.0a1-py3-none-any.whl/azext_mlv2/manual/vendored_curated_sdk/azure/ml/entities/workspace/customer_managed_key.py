# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


class CustomerManagedKey:
    def __init__(self, key_vault: str = None, key_uri: str = None):
        self.key_vault = key_vault
        self.key_uri = key_uri
