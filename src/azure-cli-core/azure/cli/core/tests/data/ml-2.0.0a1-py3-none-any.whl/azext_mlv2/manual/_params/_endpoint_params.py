# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands.parameters import get_three_state_flag
from ._common_params import add_common_params, add_override_param


def add_endpoint_common_param(
    c,
    type_help_message="The type of endpoint. Allowed values: online, batch.",
    name_help_message="Name of the endpoint.",
    local_help_message=None,
):
    c.argument("name", options_list=["--name", "-n"], type=str, help=name_help_message)
    c.argument(
        "type",
        options_list=["--type", "-t"],
        help=type_help_message,
    )
    if local_help_message is not None:
        c.argument(
            "local",
            arg_type=get_three_state_flag(),
            help=f"{local_help_message} If specified, --type/-t must be 'online'.",
            default=False,
        )


def load_endpoint_params(self):
    with self.argument_context("ml endpoint create") as c:
        add_common_params(c)
        add_endpoint_common_param(
            c,
            type_help_message="The type of endpoint. Allowed values: online, batch.",
            local_help_message="Indicates whether to create the endpoint locally.",
        )
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML endpoint specification.",
        )
        add_override_param(c)

    with self.argument_context("ml endpoint show") as c:
        add_common_params(c)
        add_endpoint_common_param(c, local_help_message="Indicates whether to show only the local endpoints.")

    with self.argument_context("ml endpoint delete") as c:
        add_common_params(c)
        add_endpoint_common_param(c, local_help_message="Indicates whether to delete the local endpoint.")
        c.argument("deployment", options_list=["--deployment", "-d"], help="Name of the deployment to delete.")

    with self.argument_context("ml endpoint get-credentials") as c:
        add_common_params(c)
        add_endpoint_common_param(
            c,
            type_help_message="The type of endpoint. Only online endpoints are currently supported.",
        )

    with self.argument_context("ml endpoint list") as c:
        add_common_params(c)
        c.argument(
            "type",
            options_list=["--type", "-t"],
            help="The type of endpoint. Allowed values: online, batch.",
        )
        c.argument(
            "local",
            arg_type=get_three_state_flag(),
            help="Indicates whether to show all local endpoints. If specified, --type/-t must be 'online'.",
            default=False,
        )

    with self.argument_context("ml endpoint get-logs") as c:
        add_common_params(c)
        add_endpoint_common_param(c, local_help_message="Indicates whether to get logs from the local endpoint.")
        c.argument("deployment", options_list=["--deployment", "-d"], help="Name of the deployment.")
        c.argument("lines", options_list=["--lines", "-l"], help="The maximum number of lines to tail.")
        c.argument(
            "container",
            options_list=["--container", "-c"],
            help="The type of container from which to retrieve logs. Allowed values: inference-server, storage-initializer.",
        )

    with self.argument_context("ml endpoint update") as c:
        add_common_params(c)
        add_endpoint_common_param(
            c,
            local_help_message="Indicates whether to update the local endpoint.",
        )
        c.argument("deployment", options_list=["--deployment", "-d"], help="Name of the deployment to update.")
        c.argument("traffic", options_list=["--traffic", "-r"], help="Traffic settings for the endpoint.")
        c.argument(
            "instance_count",
            options_list=["--instance-count", "-i"],
            help="Instance count for the deployment. If specified, --deployment/-d must also be provided.",
        )
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML endpoint specification.",
        )
        c.argument(
            "deployment_file",
            options_list=["--deployment-file", "-e"],
            help="Local path to the YAML file containing the Azure ML deployment specification to update. If specified, --deployment/-d must also be provided.",
        )

    with self.argument_context("ml endpoint invoke") as c:
        add_common_params(c)
        add_endpoint_common_param(c, local_help_message="Invoke the local endpoint.")
        add_override_param(c)
        c.argument("deployment", options_list=["--deployment", "-d"], help="Name of the deployment to target.")

    with self.argument_context("ml endpoint invoke", arg_group="BatchEndpoint") as c:
        c.argument(
            "input_data",
            options_list=["--input-data", "-i"],
            help="Input data asset. Format should be azureml:<data-name>:<data-version>.",
        )
        c.argument(
            "input_path",
            options_list=["--input-path", "-p"],
            help="URL or path on the datastore where the input data is located.",
        )
        c.argument(
            "input_local_path",
            options_list=["--input-local-path", "-l"],
            help="Local path to the input data. The file(s) will be uploaded and registered as an Azure ML data asset.",
        )
        c.argument(
            "input_datastore",
            options_list=["--input-datastore", "-u"],
            help="Datastore to which --input-path/-p is relative or files in --input-local-path/-l will be uploaded. Defaults to the workspace's default datastore.",
        )
        c.argument(
            "output_path",
            options_list=["--output-path", "-x"],
            help="Path on the datastore where output files will be uploaded to.",
        )
        c.argument(
            "output_datastore",
            options_list=["--output-datastore", "-s"],
            help="Datastore to which --output-path/-x is relative. Defaults to the workspace's default datastore.",
        )
        c.argument(
            "mini_batch_size",
            options_list=["--mini-batch-size", "-m"],
            help="Size of each mini batch that the input data will be split into for prediction.",
        )
        c.argument(
            "instance_count",
            options_list=["--instance-count", "-c"],
            help="Number of instances the prediction will run on.",
        )

    with self.argument_context("ml endpoint invoke", arg_group="OnlineEndpoint") as c:
        c.argument(
            "request_file",
            options_list=["--request-file", "-r"],
            help="Local path to the JSON file containing the request data.",
        )

    with self.argument_context("ml endpoint list-jobs") as c:
        add_common_params(c)
        add_endpoint_common_param(c, type_help_message="The type of endpoint. Only batch endpoints are supported.")
        c.argument("deployment", options_list=["--deployment", "-d"], help="Name of the deployment to target.")

    with self.argument_context("ml endpoint regenerate-keys") as c:
        add_common_params(c)
        add_endpoint_common_param(
            c,
            type_help_message="The type of the endpoint. Only online endpoints are supported.",
        )
        c.argument("key_type", type=str, help="The type of key to regenerate. Allowed values: primary, secondary.")
