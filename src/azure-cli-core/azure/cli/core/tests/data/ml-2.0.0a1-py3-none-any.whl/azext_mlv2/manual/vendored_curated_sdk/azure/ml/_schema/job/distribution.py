# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import Mpi, PyTorch, TensorFlow
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    DistributionType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from marshmallow import ValidationError, fields, post_load, pre_dump, pre_load, validate

from ..schema import PatchedSchemaMeta

module_logger = logging.getLogger(__name__)


class MPIDistributionSchema(metaclass=PatchedSchemaMeta):
    distribution_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=DistributionType.MPI
    )
    process_count_per_instance = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return Mpi(**data)


class TensorFlowDistributionSchema(metaclass=PatchedSchemaMeta):
    distribution_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=DistributionType.TENSOR_FLOW
    )
    parameter_server_count = fields.Int()
    worker_count = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return TensorFlow(**data)


class PyTorchDistributionSchema(metaclass=PatchedSchemaMeta):
    distribution_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=DistributionType.PY_TORCH
    )
    process_count = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return PyTorch(**data)
