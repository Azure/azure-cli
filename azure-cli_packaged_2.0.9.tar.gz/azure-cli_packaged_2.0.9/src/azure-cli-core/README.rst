Microsoft Azure CLI Core Module
==================================
