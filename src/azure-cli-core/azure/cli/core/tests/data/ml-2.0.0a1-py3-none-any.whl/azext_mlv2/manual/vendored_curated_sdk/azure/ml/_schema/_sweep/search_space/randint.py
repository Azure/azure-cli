# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import SearchSpace
from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PatchedSchemaMeta


class RandintSchema(metaclass=PatchedSchemaMeta):
    type = StringTransformedEnum(required=True, allowed_values=SearchSpace.RANDINT)
    upper = fields.Integer(required=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Randint

        return Randint(**data)
