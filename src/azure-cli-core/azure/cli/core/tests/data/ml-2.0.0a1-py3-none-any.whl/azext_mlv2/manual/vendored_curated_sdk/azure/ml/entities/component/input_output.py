# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import copy
from typing import Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    ComponentInput as RestComponentInput,
    ComponentOutput as RestComponentOutput,
    ComponentInputEnum,
    ComponentInputRangedNumber,
    ComponentInputGeneric,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin


class ComponentIOItem(dict, RestTranslatableMixin):
    """Component input/output. Inherit from dictionary for flexibility."""

    def __init__(self, port_dict: Dict):
        super().__init__(port_dict)


class ComponentInput(ComponentIOItem):
    DATA_TYPE_MAPPING = {
        "string": "String",
        "integer": "Integer",
        "number": "Number",
        "boolean": "Boolean",
    }
    PARAM_PARSERS = {
        "float": float,
        "integer": lambda v: int(float(v)),  # backend returns 10.0 for integer, parse it to float before int
        "boolean": lambda v: str(v).lower() == "true",
    }

    def __init__(self, port_dict: Dict):
        # parse value from string to it's original type. eg: "false" -> False
        if port_dict["data_type"] in self.PARAM_PARSERS.keys():
            for key in ["default", "min", "max"]:
                if key in port_dict.keys():
                    port_dict[key] = self.PARAM_PARSERS[port_dict["data_type"]](port_dict[key])
        super().__init__(port_dict)

    def _to_rest_object(self) -> RestComponentInput:
        # This logic is copied from backend:
        # https://msdata.visualstudio.com/Vienna/_git/vienna?path=%2Fsrc%2Fazureml-api%2Fsrc%2FManagementFrontEnd%2FServices%2FConverters%2FComponentVersionConverter.cs&version=GBmaster # noqa: E501
        if "max" in self.keys() or "min" in self.keys():
            io_class = ComponentInputRangedNumber
        elif "enum" in self.keys():
            io_class = ComponentInputEnum
        else:
            io_class = ComponentInputGeneric

        result = copy.deepcopy(self)
        # parse string -> String, integer -> Integer, etc.
        if result["data_type"] in result.DATA_TYPE_MAPPING.keys():
            result["data_type"] = result.DATA_TYPE_MAPPING[result["data_type"]]
        return io_class.from_dict(result)

    @classmethod
    def _from_rest_object(cls, rest_object: RestComponentInput) -> "ComponentInput":
        reversed_data_type_mapping = {v: k for k, v in cls.DATA_TYPE_MAPPING.items()}
        result = rest_object.as_dict()
        # hide type from client side
        result.pop("input_type")
        # parse String -> string, Integer -> integer, etc
        if result["data_type"] in reversed_data_type_mapping.keys():
            result["data_type"] = reversed_data_type_mapping[result["data_type"]]
        return ComponentInput(result)


class ComponentOutput(ComponentIOItem):
    def _to_rest_object(self) -> RestComponentOutput:
        result = copy.deepcopy(self)
        return RestComponentOutput.from_dict(result)

    @classmethod
    def _from_rest_object(cls, rest_object: RestComponentOutput) -> "ComponentOutput":
        return ComponentOutput(rest_object.as_dict())
