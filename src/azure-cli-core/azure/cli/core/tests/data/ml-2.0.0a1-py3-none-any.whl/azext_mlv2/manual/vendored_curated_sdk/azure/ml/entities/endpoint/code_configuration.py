# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Optional, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    CodeConfiguration as RestCodeConfiguration,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Code

module_logger = logging.getLogger(__name__)


class CodeConfiguration:
    """CodeConfiguration.

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param code: Code entity, defaults to None
    :type code: Union[Code, str, None], optional
    :param scoring_script: defaults to None
    :type scoring_script: str, optional
    """

    def __init__(
        self,
        base_path: Optional[str] = None,
        code: Union[Code, str, None] = None,
        scoring_script: str = None,
    ):
        self._code = code
        self._scoring_script = scoring_script

    @property
    def code(self) -> Union[Code, str, None]:
        return self._code

    @code.setter
    def code(self, value: Union[Code, str, None]):
        self._code = value

    @property
    def scoring_script(self) -> str:
        return self._scoring_script

    def _to_rest_code_configuration(self) -> RestCodeConfiguration:
        return RestCodeConfiguration(code_id=self.code, scoring_script=self.scoring_script)

    def _validate(self) -> None:
        if self.code and not self.scoring_script:
            raise Exception("scoring script can't be empty")

    @staticmethod
    def _from_rest_code_configuration(code_configuration: RestCodeConfiguration):
        if code_configuration:
            return CodeConfiguration(code=code_configuration.code_id, scoring_script=code_configuration.scoring_script)

    def __eq__(self, other: "CodeConfiguration") -> bool:
        if not other:
            return False
        # only compare mutable fields
        return (
            self.scoring_script == other.scoring_script
            and (
                isinstance(self.code, Code)
                and isinstance(other.code, Code)
                or isinstance(self.code, str)
                and isinstance(other.code, str)
            )
            and self.code == other.code
        )

    def __ne__(self, other: "CodeConfiguration") -> bool:
        return not self.__eq__(other)
