# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from itertools import islice

from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities import Datastore
from .utils import get_ml_client, _dump_entity_with_warnings
from .raise_error import log_and_raise_error
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._load_functions import load_datastore


def ml_datastore_delete(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.datastores.delete(name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_datastore_show(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.datastores.get(name, include_secrets=False)._to_dict()
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_datastore_show(cmd, resource_group_name, workspace_name, file=None, name=None):
    try:
        if file:
            params_override = []
            if name:
                params_override = [{"name": name}]
            return load_datastore(file, params_override=params_override)._to_dict()
        else:
            return ml_datastore_show(cmd, resource_group_name, workspace_name, name)
    except Exception as err:
        log_and_raise_error(err)


def ml_datastore_list(cmd, resource_group_name, workspace_name, max_results=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if max_results:
            results = islice(ml_client.datastores.list(include_secrets=False), int(max_results))
        else:
            results = ml_client.datastores.list(include_secrets=False)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_datastore_create(cmd, resource_group_name, workspace_name, file, name=None, params_override=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    params_override = params_override or []
    if name:
        params_override.append({"name": name})

    try:
        datastore = load_datastore(file, params_override=params_override)
        return ml_client.datastores.create_or_update(datastore)._to_dict()
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_datastore_update(cmd, resource_group_name, workspace_name, parameters: Dict):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        datastore = Datastore._load(parameters)
        return ml_client.datastores.create_or_update(datastore)._to_dict()
    except Exception as err:
        log_and_raise_error(err, debug)
