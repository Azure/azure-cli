# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_max_results_params


def add_version_param(c):
    c.argument("version", options_list=["--version", "-v"], type=str, help="Version of the environment.")


def add_name_param(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the environment.")


def load_environment_params(self):
    with self.argument_context("ml environment create") as c:
        add_common_params(c)
        add_name_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML environment specification.",
        )
        add_override_param(c)
        add_version_param(c)

    with self.argument_context("ml environment show") as c:
        add_common_params(c)
        c.argument(
            "version",
            options_list=["--version", "-v"],
            help="Version of the environment. If omitted, the latest version is shown.",
        )
        add_name_param(c)

    with self.argument_context("ml environment list") as c:
        add_common_params(c)
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the environment. If provided, all the environment versions under this name will be returned.",
        )
        add_max_results_params(c)

    with self.argument_context("ml environment update") as c:
        add_common_params(c)
        add_version_param(c)
        add_name_param(c)

    with self.argument_context("ml environment delete") as c:
        add_common_params(c)
        add_version_param(c)
        add_name_param(c)
