# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


from abc import ABC, abstractclassmethod, abstractmethod
from os import PathLike
from typing import Dict, Union


class Resource(ABC):
    """Base class for entity classes, can't be instantiated directly.

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param description: Description of the resource.
    :type description: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param base_path: TBD.
    :type base_path: str
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    def __init__(
        self,
        name: str,
        id: str = None,
        description: str = None,
        tags: Dict = None,
        properties: Dict = None,
        base_path: str = None,
        **kwargs,
    ):

        """Initialize base attributes of a resource object, can't be used directly."""
        self._name = name
        self._id = id
        self._description = description
        self._tags = dict(tags) if tags else {}
        self._properties = dict(properties) if properties else {}
        self._base_path = base_path or "./"
        super().__init__(**kwargs)

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name: str) -> None:
        self._name = name

    @property
    def id(self) -> str:
        return self._id

    @id.setter
    def id(self, id: str) -> None:
        self._id = id

    @property
    def description(self) -> str:
        return self._description

    @description.setter
    def description(self, description: str) -> None:
        self._description = description

    @property
    def tags(self) -> Dict:
        return self._tags

    @tags.setter
    def tags(self, tags: Dict) -> None:
        self._tags = tags

    @property
    def properties(self) -> Dict:
        return self._properties

    @properties.setter
    def properties(self, properties: Dict) -> None:
        self._properties = properties

    @property
    def base_path(self) -> str:
        return self._base_path

    @abstractmethod
    def dump(self, path: Union[PathLike, str]) -> None:
        """Dump the object content into a file.

        :param path: Path to a local file as the target.
        :type path: str
        """
        pass

    @abstractclassmethod
    def load(cls, path: Union[PathLike, str]) -> "Resource":
        """Construct a resource object from a file.

        :param path: Path to a local file as the source.
        :type path: str
        """
        pass

    def __repr__(self):
        var_dict = {k.strip("_"): v for (k, v) in vars(self).items()}
        return f"{self.__class__.__name__}({var_dict})"

    def __str__(self):
        return self.__repr__()
