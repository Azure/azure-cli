# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Optional, Dict, Any, Union
from os import PathLike
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY, ComputeType, ComputeDefaults
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Compute
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute.attached_compute import AttachedComputeSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    ComputeResource,
    VirtualMachineProperties,
    VirtualMachine as VMResource,
    VirtualMachineSshCredentials,
)


class VirtualMachineCompute(Compute):
    """Compute resource

    :param type: The type of the compute, must be "virtualmachine"
    :type type: str
    :param name: Name of the compute
    :type name: Optional[str], optional
    :param location: The resource location, defaults to None
    :type location: Optional[str], optional
    :param description: Description of the resource.
    :type description: Optional[str], optional
    :param admin_username: Describes the admin user name., defaults to None
    :type admin_username: Optional[str], optional
    :param admin_password: Describes the admin user password, defaults to None
    :type admin_password: Optional[str], optional
    :param ssh_key_value:  Specifies the SSH rsa private key as a string. Use "ssh-keygen -t
        rsa -b 2048" to generate your SSH key pairs.
    :type ssh_key_value: Optional[str], optional
    :param tags: Tags that can be specified by customers. defaults to None
    :type tags: Optional[Dict[str, str]], optional
    :param resource_id: ARM resource id of the underlying compute, defaults to None
    :type resource_id: Optional[str], optional
    :param created_on: defaults to None
    :type created_on: Optional[str], optional
    :param provisioning_state: defaults to None
    :type provisioning_state: Optional[str], optional
    """

    def __init__(
        self,
        name: str,
        type: Optional[str] = None,
        id: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        location: Optional[str] = None,
        resource_id: Optional[str] = None,
        provisioning_state: Optional[str] = None,
        ssh_port: Optional[int] = 22,
        admin_username: Optional[str] = ComputeDefaults.ADMIN_USER,
        admin_password: Optional[str] = None,
        public_key_data: Optional[str] = None,
        ssh_key_value: Optional[str] = None,
        compute_location: Optional[str] = None,
        created_on: Optional[str] = None,
        **kwargs,
    ):
        super().__init__(
            name=name,
            id=id,
            description=description,
            tags=tags,
            location=location,
            type=ComputeType.VIRTUALMACHINE,
            resource_id=resource_id,
            provisioning_state=provisioning_state,
            admin_username=admin_username,
            admin_password=admin_password,
            ssh_key_value=ssh_key_value,
            created_on=created_on,
            **kwargs,
        )
        self.ssh_port = ssh_port
        self.public_key_data = public_key_data
        self.compute_location = compute_location

    @classmethod
    def _from_rest_obj(cls, rest_obj: ComputeResource) -> "VirtualMachineCompute":
        prop = rest_obj.properties
        credentials = prop.properties.administrator_account
        response = VirtualMachineCompute(
            name=rest_obj.name,
            id=rest_obj.id,
            description=prop.description,
            tags=rest_obj.tags,
            location=rest_obj.location,
            compute_location=prop.compute_location,
            resource_id=prop.resource_id,
            ssh_port=prop.properties.ssh_port,
            admin_username=credentials.username if credentials else None,
            admin_password=credentials.password if credentials else None,
            public_key_data=credentials.public_key_data if credentials else None,
            ssh_key_value=credentials.private_key_data if credentials else None,
            provisioning_state=prop.provisioning_state,
            created_on=prop.additional_properties["createdOn"],
        )
        return response

    def dump(self, path: Union[PathLike, str]) -> None:
        """Dump the compute content into a file in yaml format.

        :param path: Path to a local file as the target, new file will be created, raises exception if the file exists.
        :type path: str
        """

        yaml_serialized = self._dump_yaml()
        dump_yaml_to_file(path, yaml_serialized, default_flow_style=False)

    def _dump_yaml(self) -> Dict:
        return AttachedComputeSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    @classmethod
    def _load_from_dict(cls, data: Dict, context: Dict, **kwargs) -> "VirtualMachineCompute":
        loaded_data = load_from_dict(AttachedComputeSchema, data, context, **kwargs)
        return VirtualMachineCompute(**loaded_data)

    @classmethod
    def load(
        cls,
        path: Union[PathLike, str],
        params_override: list = None,
        **kwargs,
    ) -> "Compute":
        """Construct a compute object from a yaml file.

        :param path: Path to a local file as the source.
        :type path: str
        :param params_override: Fields to overwrite on top of the yaml file. Format is [{"field1": "value1"}, {"field2": "value2"}]
        :type params_override: list

        :return: Loaded compute object.
        :rtype: Compute
        """

        data = load_yaml(path)
        loaded_data = load_from_dict(AttachedComputeSchema, data, context, **kwargs)
        return VirtualMachineCompute(**loaded_data)

    def _to_rest_object(self) -> ComputeResource:
        credentials = VirtualMachineSshCredentials(
            username=self.admin_username,
            password=self.admin_password,
            public_key_data=self.public_key_data,
            private_key_data=self.ssh_key_value,
        )
        properties = VirtualMachineProperties(ssh_port=self.ssh_port, administrator_account=credentials)
        vm_compute = VMResource(
            name=self.name, properties=properties, resource_id=self.resource_id, description=self.description
        )
        resource = ComputeResource(location=self.location, tags=self.tags, properties=vm_compute)
        return resource
