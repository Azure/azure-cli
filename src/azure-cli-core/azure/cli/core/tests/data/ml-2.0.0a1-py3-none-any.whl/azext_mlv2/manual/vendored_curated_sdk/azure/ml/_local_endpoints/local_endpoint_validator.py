# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


from typing import Iterable

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Deployment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Code, Model
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets.environment import Environment, _DockerConfiguration, _DockerBuild

from .errors import CloudArtifactsNotSupportedError, RequiredLocalArtifactsNotFoundError


class LocalEndpointValidator:
    def get_local_environment_artifacts(self, endpoint_name: str, deployment: Deployment) -> Iterable[str]:
        """Validates and returns local artifacts from environment specification.

        :param endpoint_name: name of endpoint which this deployment is linked to
        :type endpoint_name: str
        :param deployment: deployment to validate
        :type deployment: Deployment entity
        :return: (environment.docker.image, environment.docker.build.dockerfile) - one is expected to be None.
        :type return: Iterable[str]
        :raises: azure.ml._local_endpoints.errors.RequiredLocalArtifactsNotFoundError
        :raises: azure.ml._local_endpoints.errors.CloudArtifactsNotSupportedError
        """
        # Validate environment for local endpoint
        if not self._local_environment_is_valid(deployment=deployment):
            raise RequiredLocalArtifactsNotFoundError(
                endpoint_name=endpoint_name,
                required_artifact="environment.docker",
                required_artifact_type=str(_DockerConfiguration),
                deployment_name=deployment.name,
            )
        if self._environment_contains_cloud_artifacts(deployment=deployment):
            raise CloudArtifactsNotSupportedError(
                endpoint_name=endpoint_name, invalid_artifact="environment", deployment_name=deployment.name
            )
        return (deployment.environment.docker.image, deployment.environment.docker.build.dockerfile)

    def get_local_code_configuration_artifacts(self, endpoint_name: str, deployment: Deployment) -> Iterable[str]:
        """Validates and returns local artifacts from environment specification.

        :param endpoint_name: name of endpoint which this deployment is linked to
        :type endpoint_name: str
        :param deployment: deployment to validate
        :type deployment: Deployment entity
        :return: (local_path to code, name of scoring script file)
        :type return: Iterable[str]
        :raises: azure.ml._local_endpoints.errors.RequiredLocalArtifactsNotFoundError
        :raises: azure.ml._local_endpoints.errors.CloudArtifactsNotSupportedError
        """
        # Validate code for local endpoint
        if not self._local_code_path_is_valid(deployment=deployment):
            raise RequiredLocalArtifactsNotFoundError(
                endpoint_name=endpoint_name,
                required_artifact="code_configuration.code.local_path",
                required_artifact_type=str(str),
                deployment_name=deployment.name,
            )
        if not self._local_scoring_script_is_valid(deployment=deployment):
            raise RequiredLocalArtifactsNotFoundError(
                endpoint_name=endpoint_name,
                required_artifact="code_configuration.scoring_script",
                required_artifact_type=str(str),
                deployment_name=deployment.name,
            )
        if self._code_configuration_contains_cloud_artifacts(deployment=deployment):
            raise CloudArtifactsNotSupportedError(
                endpoint_name=endpoint_name, invalid_artifact="code_configuration", deployment_name=deployment.name
            )
        return (deployment.code_configuration.code.local_path, deployment.code_configuration.scoring_script)

    def get_local_model_artifacts(self, endpoint_name: str, deployment: Deployment) -> str:
        """Validates and returns local artifacts from environment specification.

        :param endpoint_name: name of endpoint which this deployment is linked to
        :type endpoint_name: str
        :param deployment: deployment to validate
        :type deployment: Deployment entity
        :return: the local_path to model artifact
        :type return: str
        :raises: azure.ml._local_endpoints.errors.RequiredLocalArtifactsNotFoundError
        :raises: azure.ml._local_endpoints.errors.CloudArtifactsNotSupportedError
        """
        # Validate model for local endpoint
        if not self._local_model_is_valid(deployment=deployment):
            raise RequiredLocalArtifactsNotFoundError(
                endpoint_name=endpoint_name,
                required_artifact="model.local_path",
                required_artifact_type=str(str),
                deployment_name=deployment.name,
            )
        if self._model_contains_cloud_artifacts(deployment=deployment):
            raise CloudArtifactsNotSupportedError(
                endpoint_name=endpoint_name, invalid_artifact="model", deployment_name=deployment.name
            )
        return deployment.model.local_path

    def _local_environment_is_valid(self, deployment: Deployment):
        return (
            isinstance(deployment.environment, Environment)
            and isinstance(deployment.environment.docker, _DockerConfiguration)
            and (
                deployment.environment.docker.image
                or (deployment.environment.docker.build and deployment.environment.docker.build.dockerfile)
            )
        )

    def _local_code_path_is_valid(self, deployment: Deployment):
        return (
            deployment.code_configuration
            and deployment.code_configuration.code
            and isinstance(deployment.code_configuration.code, Code)
            and deployment.code_configuration.code.local_path
        )

    def _local_scoring_script_is_valid(self, deployment: Deployment):
        return deployment.code_configuration and deployment.code_configuration.scoring_script

    def _local_model_is_valid(self, deployment: Deployment):
        return deployment.model and isinstance(deployment.model, Model) and deployment.model.local_path

    def _environment_contains_cloud_artifacts(self, deployment: Deployment):
        return isinstance(deployment.environment, str)

    def _code_configuration_contains_cloud_artifacts(self, deployment: Deployment):
        # If the deployment.code_configuration.code is a string, then it is the cloud code artifact name or full arm ID
        return (
            isinstance(deployment.code_configuration.code, str)
            or deployment.code_configuration.code.datastore
            or deployment.code_configuration.code.id
        )

    def _model_contains_cloud_artifacts(self, deployment: Deployment):
        # If the deployment.model is a string, then it is the cloud model name or full arm ID
        return isinstance(deployment.model, str) or deployment.model.datastore or deployment.model.id
