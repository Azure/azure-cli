# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import _check_and_upload_path
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts.constants import ASSET_PATH_ERROR, CHANGED_ASSET_PATH_MSG
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations.datastore_operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import get_datastore_arm_id, is_ARM_id_for_resource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import API_VERSION_2021_03_01_PREVIEW
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Code

module_logger = logging.getLogger(__name__)


class CodeOperations(_WorkspaceDependentOperations):
    """Represents a client for performing operations on code assets

    You should not instantiate this class directly. Instead, you should create MLClient and
    use this client via the property MLClient.code
    """

    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: AzureMachineLearningWorkspaces,
        datastore_operations: DatastoreOperations,
        **kwargs: Dict,
    ):
        super(CodeOperations, self).__init__(workspace_scope)
        self._service_client = service_client
        self._version_operation = service_client.code_versions
        self._container_operation = service_client.code_containers
        self._datastore_operation = datastore_operations
        self._init_kwargs = kwargs

    def create_or_update(self, code: Code) -> Code:
        """Returns created or updated code asset.

        If not already in storage, asset will be uploaded to datastore name specified in code.datastore or the workspace's default datastore.

        :param code: Code asset object.
        :type code: Code
        """
        name = code.name
        version = code.version

        code = _check_and_upload_path(asset=code, asset_operations=self)

        # For anonymous code, if the code already exists in storage, we reuse the name, version stored in the storage
        # metadata so the same anonymous code won't be created again.
        if code._is_anonymous:
            name = code.name
            version = code.version

        if not is_ARM_id_for_resource(code.datastore):
            code._datastore = get_datastore_arm_id(code.datastore, self._workspace_scope)
        code_version_resource = code._to_rest_object()
        try:
            result = self._version_operation.create_or_update(
                name=name,
                version=version,
                subscription_id=self._workspace_scope.subscription_id,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                body=code_version_resource,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
        except Exception as e:
            # service side raises an exception if we attempt to update an existing asset's asset path
            if str(e) == ASSET_PATH_ERROR:
                raise Exception(CHANGED_ASSET_PATH_MSG)
            else:
                raise e

        return Code._from_rest_object(result)

    def get(self, name: str, version: int) -> Code:
        """Returns information about the specified code asset.

        :param name: Name of the code asset.
        :type name: str
        :param version: Version of the code asset.
        :type version: int
        """
        if not version:
            raise Exception("Code asset version must be specified as part of name parameter, in format 'name:version'.")
        else:
            code_version_resource = self._version_operation.get(
                name=name,
                version=version,
                subscription_id=self._workspace_scope.subscription_id,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
            return Code._from_rest_object(code_version_resource)

    def delete(self, name: str, version: int) -> None:
        """Deletes a specified version of a code asset"""
        if version:
            return self._version_operation.delete(
                name=name, version=str(version), workspace_name=self._workspace_name, **self._scope_kwargs
            )
        else:
            raise Exception("Deletion on the whole lineage is not supported yet. " "Please specify a version.")
