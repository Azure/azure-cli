# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._sweep.constants import TYPE
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import SearchSpace
from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PatchedSchemaMeta


class NormalSchema(metaclass=PatchedSchemaMeta):
    type = StringTransformedEnum(required=True, allowed_values=SearchSpace.NORMAL_LOGNORMAL)
    mu = fields.Float(required=True)
    sigma = fields.Float(required=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Normal, LogNormal

        return Normal(**data) if data[TYPE] == SearchSpace.NORMAL else LogNormal(**data)


class QNormalSchema(metaclass=PatchedSchemaMeta):
    type = StringTransformedEnum(required=True, allowed_values=SearchSpace.QNORMAL_QLOGNORMAL)
    mu = fields.Float(required=True)
    sigma = fields.Float(required=True)
    q = fields.Int(required=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import QNormal, QLogNormal

        return QNormal(**data) if data[TYPE] == SearchSpace.QNORMAL else QLogNormal(**data)
