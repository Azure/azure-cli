# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import TrainingSettings


class TrainingSettingsSchema(metaclass=PatchedSchemaMeta):
    block_list_models = fields.List(fields.Str(), data_key=AutoMLConstants.BLOCKED_ALGORITHMS_YAML)
    allow_list_models = fields.List(fields.Str(), data_key=AutoMLConstants.ALLOWED_ALGORITHMS_YAML)
    enable_dnn_training = fields.Bool()

    @post_load
    def make(self, data, **kwargs):
        return TrainingSettings(**data)
