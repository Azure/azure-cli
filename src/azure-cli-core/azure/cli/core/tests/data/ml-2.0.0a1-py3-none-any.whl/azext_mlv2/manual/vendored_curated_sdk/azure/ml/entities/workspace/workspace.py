# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from os import PathLike
from pathlib import Path
from typing import Dict, Union
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.workspace.workspace import WorkspaceSchema

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import dump_yaml_to_file, load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._workspace_utils import get_endpoint_parts
from .customer_managed_key import CustomerManagedKey
from .private_endpoint import PrivateEndpoint, EndpointConnection
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Resource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY, PARAMS_OVERRIDE_KEY, WorkspaceResourceConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import Workspace as RestWorkspace
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict


class Workspace(Resource):
    def __init__(
        self,
        name: str,
        id: str = None,
        description: str = None,
        tags: Dict[str, str] = None,
        location: str = None,
        friendly_name: str = None,
        discovery_url: str = None,
        hbi_workspace: bool = None,
        storage_account: str = None,
        container_registry: str = None,
        key_vault: str = None,
        application_insights: str = None,
        customer_managed_key: CustomerManagedKey = None,
        private_endpoints: PrivateEndpoint = None,
        **kwargs,
    ):

        """Azure ML workspace.

        :param name: Name of the workspace.
        :type name: str
        :param id:  Global id of the workspace, Azure Resource Manager ID, system generated.
        :type id: str
        :param description: Description of the workspace.
        :type description: str
        :param tags: Tags of the workspace.
        :type tags: dict
        :param location: Azure region.
        :type location: str
        :param friendly_name: Friendly name of the workspace.
        :type friendly_name: str
        :param hbi_workspace:  Indicates if the workspace is used for confidential data.
        :type hbi_workspace: bool
        :param storage_account: Status of the job.
        :type storage_account: str
        :param container_registry: Id of a Azure container registry that will be used by the workspace.
        :type container_registry: str
        :param key_vault: Id of a Azure key vault that will be used by the workspace.
        :type key_vault: str
        :param application_insights: Id of the Azure application insight that will be used by the workspace.
        :type application_insights: str
        :param customer_managed_key: Customer managed key that will be used by the workspace.
        :type customer_managed_key: CustomerManagedKey
        :param private_endpoints: Private endpoint for private link use case.
        :type private_endpoints: PrivateEndpoint
        :param kwargs: A dictionary of additional configuration parameters.
        :type kwargs: dict
        """
        super().__init__(name=name, id=id, description=description, tags=tags, **kwargs)

        self.location = location
        self.friendly_name = friendly_name
        self._discovery_url = discovery_url
        self._hbi_workspace = hbi_workspace
        self.storage_account = storage_account
        self.container_registry = container_registry
        self.key_vault = key_vault
        self.application_insights = application_insights
        self.customer_managed_key = customer_managed_key
        self.private_endpoints = private_endpoints

    @property
    def discovery_url(self) -> str:
        return self._discovery_url

    @property
    def hbi_workspace(self) -> str:
        return self._hbi_workspace

    def dump(self, path: Union[PathLike, str]) -> None:
        """Dump the workspace spec into a file in yaml format.

        :param path: Path to a local file as the target, new file will be created, raises exception if the file exists.
        :type path: str
        """
        yaml_serialized = self._dump_yaml()
        dump_yaml_to_file(path, yaml_serialized, default_flow_style=False)

    def _dump_yaml(self) -> Dict:
        return WorkspaceSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    @classmethod
    def load(
        cls,
        path: Union[PathLike, str],
        params_override: list = [],
        **kwargs,
    ) -> "Workspace":
        """Load a workspace object from a yaml file.

        :param path: Path to a local file as the source.
        :type path: str
        :param params_override: Fields to overwrite on top of the yaml file. Format is [{"field1": "value1"}, {"field2": "value2"}]
        :type params_override: list

        :return: Loaded workspace object.
        :rtype: Workspace
        """

        yaml_dict = load_yaml(path)
        return cls._load(data=yaml_dict, yaml_path=path, params_override=params_override, **kwargs)

    @classmethod
    def _load(
        cls,
        data: Dict = {},
        yaml_path: Union[PathLike, str] = None,
        params_override: list = [],
        **kwargs,
    ) -> "Workspace":

        context = {
            BASE_PATH_CONTEXT_KEY: Path(yaml_path).parent if yaml_path else Path("./"),
            PARAMS_OVERRIDE_KEY: params_override,
        }
        loaded_schema = load_from_dict(WorkspaceSchema, data, context, **kwargs)
        return Workspace(**loaded_schema)

    @classmethod
    def _from_rest_object(cls, rest_obj: RestWorkspace) -> "Workspace":

        customer_managed_key = (
            CustomerManagedKey(
                key_vault=rest_obj.encryption.key_vault_properties.key_vault_arm_id,
                key_uri=rest_obj.encryption.key_vault_properties.key_identifier,
            )
            if rest_obj.encryption
            and rest_obj.encryption.status == WorkspaceResourceConstants.ENCRYPTION_STATUS_ENABLED
            else None
        )

        private_endpoints = None
        if rest_obj.private_endpoint_connections:
            for name in rest_obj.private_endpoint_connections:
                conn_name, subscription_id, resource_group, vnet_name, subnet_name = get_endpoint_parts(
                    name.private_endpoint.id, name.private_endpoint.subnet_arm_id
                )
                connection = EndpointConnection(subscription_id, resource_group, vnet_name, subnet_name)
                approval_type = name.private_link_service_connection_state.description
                private_endpoints = PrivateEndpoint(approval_type=approval_type, connections={conn_name: connection})

        return Workspace(
            name=rest_obj.name,
            id=rest_obj.id,
            description=rest_obj.description,
            tags=rest_obj.tags,
            location=rest_obj.location,
            friendly_name=rest_obj.friendly_name,
            discovery_url=rest_obj.discovery_url,
            hbi_workspace=rest_obj.hbi_workspace,
            storage_account=rest_obj.storage_account,
            container_registry=rest_obj.container_registry,
            key_vault=rest_obj.key_vault,
            application_insights=rest_obj.application_insights,
            customer_managed_key=customer_managed_key,
            private_endpoints=private_endpoints,
        )
