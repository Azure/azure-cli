# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from os import getenv

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AZUREML_PRIVATE_FEATURES_ENV_VAR
from .print_error import print_warning, print_error_and_exit
from azure.core.polling import LROPoller


def _dump_entity_with_warnings(entity: "Resource") -> Dict:
    if isinstance(entity, LROPoller):
        return entity
    try:
        return entity._dump_yaml()  # type: ignore
    except Exception as err:
        print_warning("Failed to deserialize response: " + str(err))
        print_warning(str(entity))


def _is_debug_set(cli_context):
    if "--debug" in cli_context.data["safe_params"]:
        return True
    else:
        return False


def check_private_feature_enabled_and_exit():
    if not private_features_enabled():
        print_error_and_exit("Specified operation is not supported.")


def private_features_enabled():
    return getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR)
