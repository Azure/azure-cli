# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict
from itertools import islice
from marshmallow import ValidationError
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities import Component
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml._ml_exceptions import ValidationException
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._validation import ValidationResult
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings, get_list_view_type
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._load_functions import load_component


def ml_component_list(
    cmd, resource_group_name, workspace_name, name=None, max_results=None, include_archived=False, archived_only=False
):
    return _ml_component_list(
        cmd=cmd,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        name=name,
        max_results=max_results,
        include_archived=include_archived,
        archived_only=archived_only,
    )


def ml_component_show(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    return _ml_component_show(
        cmd=cmd,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        name=name,
        version=version,
        label=label,
    )


def ml_component_validate(cmd, file, resource_group_name, workspace_name, params_override=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    try:
        try:
            # 1. load to component schema
            component = load_component(path=file, params_override=params_override)

            # 2. validate component
            result = ml_client.components.validate(component)
        except ValidationException as err:
            result = ValidationResult._create_instance(err.message)
        except ValidationError as err:
            result = ValidationResult._from_validation_error(err)

        return _dump_entity_with_warnings(result)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_component_create(cmd, file, resource_group_name, workspace_name, name=None, version=None, params_override=None):
    return _ml_component_create(
        cmd=cmd,
        file=file,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        version=version,
        name=name,
        params_override=params_override,
    )


def ml_component_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        # 1. load parameters into component entity
        component_entity = Component._load(data=parameters, yaml_path=".")
        # 2. update the component
        result = ml_client.create_or_update(component_entity)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_component_archive(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        ml_client.components.archive(name=name, version=version, label=label)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_component_restore(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        ml_client.components.restore(name=name, version=version, label=label)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_component_show_private_preview(
    cmd, resource_group_name, workspace_name, name, version=None, label=None, registry_name=None
):
    return _ml_component_show(
        cmd=cmd,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        name=name,
        version=version,
        label=label,
        registry_name=registry_name,
    )


def ml_component_list_private_preview(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    max_results=None,
    registry_name=None,
    include_archived=False,
    archived_only=False,
):
    return _ml_component_list(
        cmd=cmd,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        name=name,
        max_results=max_results,
        registry_name=registry_name,
        include_archived=include_archived,
        archived_only=archived_only,
    )


def ml_component_create_private_preview(
    cmd, file, resource_group_name, workspace_name, version=None, name=None, params_override=None, registry_name=None
):
    return _ml_component_create(
        cmd=cmd,
        file=file,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        version=version,
        params_override=params_override,
        registry_name=registry_name,
        name=name,
    )


def _ml_component_list(
    cmd, resource_group_name, workspace_name, name, max_results, include_archived, archived_only, registry_name=None
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        registry_name=registry_name,
    )

    try:
        list_view_type = get_list_view_type(include_archived=include_archived, archived_only=archived_only)
        if max_results:
            results = islice(
                ml_client.components.list(name=name, list_view_type=list_view_type),
                int(max_results),
            )
        else:
            results = ml_client.components.list(name=name, list_view_type=list_view_type)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))

    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_component_show(cmd, resource_group_name, workspace_name, name, version, label, registry_name=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        registry_name=registry_name,
    )

    try:
        component = ml_client.components.get(name=name, version=version, label=label)
        return _dump_entity_with_warnings(component)
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_component_create(
    cmd, file, resource_group_name, workspace_name, version, params_override, name, registry_name=None
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        registry_name=registry_name,
    )
    params_override = params_override or []

    try:
        # 1. update override params
        if version:
            params_override.append({"version": version})
        if name:
            params_override.append({"name": name})
        # 2. load to component schema
        component = load_component(path=file, params_override=params_override)
        # 3. create component
        result = ml_client.create_or_update(component)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        log_and_raise_error(err, debug)
