# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_endpoint_help():
    helps[
        "ml endpoint"
    ] = """
        type: group
        short-summary: Manage Azure ML endpoints.
        long-summary: >
          Azure ML endpoints provide a simple interface for creating and managing model deployments.
          Each endpoint can have one or more deployments, enabling the traffic from a single scoring
          endpoint to be served to multiple deployments if needed. This is useful for scenarios such
          as controlled rollout.


          Azure ML supports two types of endpoints: online and batch. Online endpoints support real-time
          inference, while batch endpoints are used for offline batch scoring.
    """
    helps[
        "ml endpoint create"
    ] = """
        type: command
        short-summary: Create an endpoint.
        long-summary: >
          To create an endpoint, provide a YAML file with either an online or batch endpoint
          configuration. The endpoint can have one or more deployments defined. A deployment
          configuration will typically include the model to deploy, the scoring code, the
          environment encapsulating the scoring dependencies, the compute configuration, and
          any additional settings.
        examples:
        - name: Create an endpoint from a YAML specification file
          text: az ml endpoint create --file endpoint.yml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint delete"
    ] = """
        type: command
        short-summary: Delete an endpoint or a specific deployment.
        examples:
        - name: Delete an online endpoint, including all its deployments
          text: az ml endpoint delete --name my-online-endpoint --resource-group my-resource-group --workspace-name my-workspace
        - name: Delete a specific deployment for a batch endpoint. This does not delete the endpoint itself.
          text: az ml endpoint delete --name my-batch-endpoint --deployment my-deployment --type batch --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint invoke"
    ] = """
        type: command
        short-summary: Invoke an endpoint
        long-summary: >
          You can test an endpoint by invoking it with some request data. For online endpoints, this
          will be real-time inference and the scoring results will be returned immediately. For batch
          endpoints, invocation will trigger an asynchronous batch scoring job.
        examples:
        - name: Invoke an online endpoint with some request data
          text: az ml endpoint invoke --name my-online-endpoint --request-file sample_request.json --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke an online endpoint, targeting a specific deployment
          text: az ml endpoint invoke --name my-online-endpoint --deployment my-deployment --request-file sample_request.json --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke a batch endpoint with input data from a registered Azure ML data asset (and override default deployment setting for mini_batch_size)
          text: az ml endpoint invoke --name my-batch-endpoint --type batch --input-data azureml:mnist-data:1 --mini-batch-size 64 --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke a batch endpoint with input data from a storage URL
          text: az ml endpoint invoke --name my-batch-endpoint --type batch --input-path https://pipelinedata.blob.core.windows.net/sampledata/mnist --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke a batch endpoint with input data from a path on a datastore
          text: az ml endpoint invoke --name my-batch-endpoint --type batch --input-datastore my-datastore --input-path mnist --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke a batch endpoint with input data from local files
          text: az ml endpoint invoke --name my-batch-endpoint --type batch --input-local-path ./mnist --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint list"
    ] = """
        type: command
        short-summary: List endpoints in a workspace.
        examples:
        - name: List all the online endpoints in a workspace
          text: az ml endpoint list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the batch endpoints in a workspace
          text: az ml endpoint list --type batch --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint list-jobs"
    ] = """
        type: command
        short-summary: List the batch scoring jobs for a batch endpoint.
        examples:
        - name: List all the batch scoring jobs for an endpoint
          text: az ml endpoint list-jobs --name my-batch-endpoint --resource-group my-resource-group --workspace-name my-workspace
        - name: List the batch scoring jobs for a specific deployment
          text: az ml endpoint list-jobs --name my-batch-endpoint --deployment my-deployment --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint get-credentials"
    ] = """
        type: command
        short-summary: List the token/keys for an online endpoint.
        examples:
        - name: List the keys for an online endpoint
          text: az ml endpoint get-credentials --name my-online-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint regenerate-keys"
    ] = """
        type: command
        short-summary: Regenerate the keys for an online endpoint.
        examples:
        - name: Regenerate the keys for an online endpoint
          text: az ml endpoint regenerate-keys --name my-online-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint get-logs"
    ] = """
        type: command
        short-summary: Get the container logs for an online deployment
        examples:
        - name: Get the container logs for an online deployment
          text: az ml endpoint get-logs --name my-online-endpoint --deployment my-deployment --lines 100 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint show"
    ] = """
        type: command
        short-summary: Show details for an endpoint.
        examples:
        - name: Show the details for a batch endpoint
          text: az ml endpoint show --name my-batch-endpoint --type batch --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml endpoint update"
    ] = """
        type: command
        short-summary: Update an endpoint.
        long-summary: >
          The 'description', 'tags', and 'traffic' properties of an endpoint can be updated.
          In addition, new deployments can be added to an endpoint, and existing deployments
          can be updated.
        examples:
        - name: Update an endpoint from a YAML specification file
          text: az ml endpoint update --file updated_endpoint.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Add a new deployment to an existing endpoint
          text: az ml endpoint update --name my-batch-endpoint --type batch --deployment my-new-deployment --deployment-file new_deployment.yml  --resource-group my-resource-group --workspace-name my-workspace
        - name: Update the traffic settings for an endpoint
          text: az ml endpoint update --name my-batch-endpoint --type batch --traffic my-new-deployment:100 --resource-group my-resource-group --workspace-name my-workspace
    """
