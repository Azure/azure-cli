# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import CreationContextSchema
from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from .fields import ArmStr, ArmVersionedStr

module_logger = logging.getLogger(__name__)


class ModelSchema(PathAwareSchema):
    name = fields.Str(required=True)
    id = ArmVersionedStr(azureml_type=AzureMLResourceType.MODEL, dump_only=True)
    path = fields.Str()
    local_path = fields.Str()
    version = fields.Integer(required=True)
    description = fields.Str()
    properties = fields.Dict()
    tags = fields.Dict()
    utc_time_created = fields.DateTime()
    flavors = fields.Dict()
    creation_context = NestedField(CreationContextSchema, dump_only=True)
    datastore = ArmStr(
        azureml_type=AzureMLResourceType.DATASTORE,
        metadata={"description": "the datastore in which the data resides (once the Artifact is created)"},
    )

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Model

        return Model(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
