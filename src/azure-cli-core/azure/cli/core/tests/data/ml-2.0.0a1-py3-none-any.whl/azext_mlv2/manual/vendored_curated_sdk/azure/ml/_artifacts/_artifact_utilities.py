# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import os
from typing import Optional, Dict, Union
from pathlib import Path

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._storage_utils import get_storage_client
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.datastore.credentials import AccountKeyCredentials
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import get_datastore_arm_id, AMLNamedArmId
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import (
    _validate_path,
    get_object_hash,
    AssetNotChangedError,
    get_ignore_file,
    IgnoreFile,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    ContentsType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Asset

module_logger = logging.getLogger(__name__)


class AssetArtifact:
    def __init__(self, name: str, version: str, path: str, datastore_id: str):
        self.name = name
        self.version = version
        self._storage_info = {"path": path, "datastore_id": datastore_id}

    @property
    def storage_info(self) -> Dict[str, str]:
        return self._storage_info


def get_datastore_info(operations: DatastoreOperations, name: str) -> Dict[str, str]:
    """
    Get datastore account, type, and auth information
    """
    datastore_info = {}
    datastore = operations.get(name, include_secrets=True)
    credentials = datastore.credential
    datastore_info["storage_type"] = datastore.storage_type
    datastore_info["storage_account"] = datastore.account_name
    datastore_info["container_name"] = str(
        datastore.container_name if datastore.storage_type == ContentsType.AZURE_BLOB else datastore.file_share_name
    )
    if isinstance(credentials, AccountKeyCredentials):
        datastore_info["credential"] = credentials.key
    else:
        datastore_info["credential"] = credentials.sas_token
    return datastore_info


def upload_artifact(
    local_path: str,
    datastore_operation: DatastoreOperations,
    workspace_scope: WorkspaceScope,
    datastore_name: Optional[str],
    asset_hash: str = None,
    show_progress: bool = True,
    include_container_in_asset_path: bool = True,
    asset_name: str = None,
    asset_version: str = None,
    ignore_file: IgnoreFile = IgnoreFile(None),
) -> AssetArtifact:
    """
    Upload local file or directory to datastore
    """
    datastore_info = get_datastore_info(datastore_operation, datastore_name)
    storage_client = get_storage_client(**datastore_info)
    artifact_info = storage_client.upload(
        local_path,
        asset_hash=asset_hash,
        show_progress=show_progress,
        name=asset_name,
        version=asset_version,
        ignore_file=ignore_file,
    )

    uploaded_asset_id = artifact_info["remote path"]
    # work around a bug in MFE that requires some asset paths to include the container name
    # and others to exclude it
    if include_container_in_asset_path:
        path = f'{datastore_info["container_name"]}/{uploaded_asset_id}'
    else:
        path = uploaded_asset_id

    artifact = AssetArtifact(
        name=artifact_info["name"],
        version=artifact_info["version"],
        path=path,
        datastore_id=get_datastore_arm_id(datastore_name, workspace_scope),
    )
    return artifact


def _upload_to_datastore(
    workspace_scope: WorkspaceScope,
    datastore_operation: DatastoreOperations,
    path: Union[str, Path, os.PathLike],
    datastore_name: str = None,
    show_progress: bool = True,
    include_container_in_asset_path: bool = False,
    asset_name: str = None,
    asset_version: str = None,
) -> AssetArtifact:
    _validate_path(path)
    datastore_name = datastore_name or datastore_operation.get_default().name
    try:
        # parse arm id to datastore name
        datastore_name = AMLNamedArmId(datastore_name).asset_name
    except (ValueError, AttributeError):
        module_logger.debug(f"datastore_name {datastore_name} is not a full arm id. Proceed with a shortened name.\n")
    ignore_file = get_ignore_file(path)
    asset_hash = get_object_hash(path, ignore_file)
    artifact = upload_artifact(
        str(path),
        datastore_operation,
        workspace_scope,
        datastore_name,
        show_progress=show_progress,
        asset_hash=asset_hash,
        include_container_in_asset_path=include_container_in_asset_path,
        asset_name=asset_name,
        asset_version=asset_version,
        ignore_file=ignore_file,
    )
    return artifact


def _check_and_upload_path(
    asset: Asset, asset_operations: Union["DataOperations", "ModelOperations", "CodeOperations"]
) -> Asset:
    if asset.local_path:
        path = Path(asset.local_path)
        if not path.is_absolute():
            path = Path(asset.base_path, path).resolve()
        artifact = _upload_to_datastore(
            asset_operations._workspace_scope,
            asset_operations._datastore_operation,
            path,
            datastore_name=asset.datastore,
            include_container_in_asset_path=False,
            asset_name=asset.name,
            asset_version=str(asset.version),
        )
        asset.name, asset.version = artifact.name, artifact.version
        asset._path, asset._datastore = artifact.storage_info["path"], artifact.storage_info["datastore_id"]

    return asset
