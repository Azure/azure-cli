# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


import concurrent.futures
from concurrent.futures import Future
from azure.core.exceptions import HttpResponseError
import logging
import time
from azure.core.polling import LROPoller
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import OnlineEndpointConfigurations, PollerStatus, HttpResponseStatusCode
from typing import Callable, Any, Dict, Iterable, Optional, Union


module_logger = logging.getLogger(__name__)


def polling_wait(
    poller: Union[LROPoller, Future], message: str = None, start_time: float = None, is_local=False
) -> Any:
    """Print out status while polling and time of operation once completed.

    :param Union[LROPoller, concurrent.futures.Future] poller: An poller which will return status update via function done().
    :param (str, optional) message: Message to print out before starting operation write-out.
    :param (float, optional) start_time: Start time of operation.
    """
    module_logger.info(f"{message}")

    if is_local:
        count = 0
        while not poller.done() and count < OnlineEndpointConfigurations.MAX_WAIT_COUNT:
            module_logger.info(".")
            time.sleep(OnlineEndpointConfigurations.SLEEP_TIME)
            count += 1
    else:
        # There is one limitation on MFE. So we have to catch the 404 exception and continue.
        # we can swtich to use poller.result(timeout=xxx) and remove "try and catch" when MFE bug 1185359
        # Task 1185359: When polling status of deletion operation, MFE returns 404. New task created.
        # https://msdata.visualstudio.com/Vienna/_workitems/edit/1185359
        try:
            poller.wait(timeout=OnlineEndpointConfigurations.POLLING_TIMEOUT)
        except HttpResponseError as e:
            if e.status_code != HttpResponseStatusCode.NOT_FOUND:
                raise

    module_logger.info("Done ")

    if start_time:
        end_time = time.time()
        duration = divmod(int(round(end_time - start_time)), 60)
        module_logger.info(f"({duration[0]}m {duration[1]}s)\n")


def local_endpoint_polling_wrapper(func: Callable, message: str, **kwargs) -> Any:
    """Wrapper for polling local endpoint operations.

    :param Callable func: Name of the endpoint.
    :param str message: Message to print out before starting operation write-out.
    :param dict kwargs: kwargs to be passed to the func
    :return: The type returned by Func
    """
    pool = concurrent.futures.ThreadPoolExecutor()
    start_time = time.time()
    event = pool.submit(func, **kwargs)
    polling_wait(poller=event, start_time=start_time, message=message, is_local=True)
    return event.result()
