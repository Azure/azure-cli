# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

ENV_LIVE_TEST = 'CLI_TEST_RUN_LIVE'
ENV_SKIP_ASSERT = 'CLI_TEST_SKIP_ASSERT'
ENV_TEST_DIAGNOSE = 'CLI_TEST_DIAGNOSE'
