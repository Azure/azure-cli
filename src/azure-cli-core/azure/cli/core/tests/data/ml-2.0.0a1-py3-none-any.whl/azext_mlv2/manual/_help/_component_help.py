# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps
from ..custom.utils import private_features_enabled


def get_component_help():
    if private_features_enabled():
        helps[
            "ml component"
        ] = """
            type: group
            short-summary: Manage Azure ML components.
        """
        helps[
            "ml component show"
        ] = """
            type: command
            short-summary: Show details for a component.
            examples:
            - name: Show detail for the latest version of a component with the specified name
              text: az ml component show --name my-component --resource-group my-resource-group --workspace-name my-workspace
            - name: Show detail for a component with the specified name and version
              text: az ml component show --name my-component --version 1 --resource-group my-resource-group --workspace-name my-workspace
        """
        helps[
            "ml component list"
        ] = """
            type: command
            short-summary: List components in a workspace.
            examples:
            - name: List all the components in a workspace
              text: az ml component list --resource-group my-resource-group --workspace-name my-workspace
            - name: List all the component versions for the specified name in a workspace
              text: az ml component list --name my-component --resource-group my-resource-group --workspace-name my-workspace
        """
        helps[
            "ml component create"
        ] = """
            type: command
            short-summary: Create a component.
            examples:
            - name: Create a component from a YAML specification file
              text: az ml component create --file my_component.yml --resource-group my-resource-group --workspace-name my-workspace
            - name: Create a component from a YAML specification file with specified version
              text: az ml component create --file my_component.yml --version 1 --resource-group my-resource-group --workspace-name my-workspace
        """
        helps[
            "ml component update"
        ] = """
            type: command
            short-summary: Update a component. Currently only a few fields(description, display_name) support update.
            examples:
            - name: Update a component's description
              text: az ml component update -n my_component -v 1 --set description="new description" -g my-resource-group -w my-workspace
        """
        helps[
            "ml component delete"
        ] = """
            type: command
            short-summary: Delete a component.
            examples:
            - name: Delete a component
              text: az ml component delete -n my_component -v 1
        """
