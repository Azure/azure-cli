Microsoft Azure CLI 'cognitive services' Command Module
=======================================================

This package is for the 'cognitive services' module.
i.e. 'az cognitiveservices'


