import json
import logging
import traceback
from colorama import init, Fore, Style
from azure.core.exceptions import HttpResponseError, ODataV4Format

module_logger = logging.getLogger(__name__)

init()


def _get_exception_with_error(error_details):
    """
    Converts error message to ARMErrorFormat (if possible)
    and builds error message from it. Otherwise raise exception
    by using message for error passed.
    """
    try:
        json_error = json.loads(error_details.message)
        formatted_error = ODataV4Format(json_object=json_error)
        return Exception(formatted_error.message_details())
    except Exception:
        module_logger.debug(f"Error parsing details of deployment failed error : {error_details.message}")
        return Exception(error_details.message_details())


def _handle_deployment_failed_error(error_response):
    """
    Extracts error message from error details and returns an exception
    """
    if error_response.error.details:
        details = error_response.error.details
        for error_details in details:
            # For time being only handling first element. Assuming there will be only one error message
            # coming from service side rather then clubbing multiple together
            return _get_exception_with_error(error_details=error_details)
    return error_response


def print_error_and_exit(error, debug=False):
    # use an f-string to automatically call str() on error
    if isinstance(error, HttpResponseError):
        module_logger.debug(f"Received HttpResponseError: {traceback.format_exc()}")
        if error.error and isinstance(error.error, ODataV4Format):
            if error.error and error.error.code and error.error.code == "DeploymentFailed":
                processed_error = _handle_deployment_failed_error(error_response=error)
                print(f"{Style.BRIGHT}{Fore.RED}{processed_error}")
            else:
                print(f"{Style.BRIGHT}{Fore.RED}{error.error.message_details()}")
        else:
            print(f"{Style.BRIGHT}{Fore.RED}{error.message}")
    else:
        module_logger.debug(traceback.format_exc())
        print(f"{Style.BRIGHT}{Fore.RED}{error}")
    if debug:
        print(f"{Style.BRIGHT}{Fore.RED}{traceback.print_exc()}")
    exit(1)


def print_warning(text):
    print(Fore.LIGHTYELLOW_EX + text)


def print_warning_with_fore_reset(text):
    print("{}{}{}".format(Fore.LIGHTYELLOW_EX, text, Fore.RESET))
