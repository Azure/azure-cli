# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_workspace_help():
    helps[
        "ml workspace"
    ] = """
        type: group
        short-summary: Manage Azure ML workspaces.
        long-summary: >
            An Azure ML workspace is the top-level resource for Azure Machine Learning. It provides
            a centralized place to track the assets and resources used in your ML workflows, along
            with the logs and artifacts produced from your training jobs.


            If you are upgrading from CLI v1 to v2, you require the following two changes in scope of workspace management:

            - Upgrade `az ml workspace private-endpoint` commands to equivalent `az network private-endpoint` commands.

            - Also, upgrade `az ml workspace share` commands to equivalent `az role assignment create` commands.
    """
    helps[
        "ml workspace list"
    ] = """
        type: command
        short-summary: List all the workspaces in a subscription.
        long-summary: >
            The list of workspaces can be filtered by resource group.
        examples:
        - name: List all the workspaces in a resource group
          text: az ml workspace list --resource-group my-resource-group
        - name: List all the workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml workspace list --query \"[].{Name:name}\"  --output table --resource-group my-resource-group
    """
    helps[
        "ml workspace show"
    ] = """
        type: command
        short-summary: Show details for a workspace.
    """
    helps[
        "ml workspace delete"
    ] = """
        type: command
        short-summary: Delete a workspace.
        long-summary: >
            By default the dependent resources associated with the workspace (Azure Storage,
            Azure Container Registry, Azure Key Vault, Azure Application Insights) are not deleted.
            To delete those as well, include --all-resources.
    """
    helps[
        "ml workspace create"
    ] = """
        type: command
        short-summary: Create a workspace.
        long-summary: >
            When a workspace is created, several Azure resources that will be used by Azure ML
            also get created by default: Azure Storage, Azure Container Registry, Azure Key Vault, and Azure Application
            Insights. You can instead use existing Azure resource instances for those when creating the workspace
            by specifying the resource IDs in the workspace configuration YAML file.
        examples:
        - name: Create a workspace from a YAML specification file.
          text: az ml workspace create --file workspace.yml --resource-group my-resource-group
    """
    helps[
        "ml workspace list-keys"
    ] = """
        type: command
        short-summary: List workspace keys for dependent resources such as Azure Storage, Azure Container Registry,
            and Azure Application Insights.
    """
    helps[
        "ml workspace sync-keys"
    ] = """
        type: command
        short-summary: Sync workspace keys for dependent resources such as Azure Storage, Azure Container Registry,
            and Azure Application Insights.
        long-summary: >
            If the keys for any resource in the workspace are changed, it can take around an hour for them to automatically
            be updated. This command triggers the workspace to immediately synchronize keys. A possible scenario is
            needing immediate access to storage after regenerating the storage keys.
     """
    helps[
        "ml workspace update"
    ] = """
        type: command
        short-summary: Update a workspace.
        long-summary: >
            The 'description', 'tags', and 'friendly_name' properties can be updated.
        examples:
        - name: update a workspace from a YAML specification file.
          text: az ml workspace update --resource-group my-resource-group --name my-workspace-name --file workspace.yml
    """
    helps[
        "ml workspace diagnose"
    ] = """
        type: command
        short-summary: Diagnose workspace setup problems.
        long-summary: >
            If your workspace is not working as expected, you can run this diagnosis to check if the workspace has been broken.
            For private endpoint workspace, it will also help check out if the network setup to this workspace and its dependent resource
            has problem or not.
        examples:
        - name: diagnose a workspace.
          text: az ml workspace diagnose --name my-workspace-name --no-wait -g my-resource-group
    """
