# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_max_results_params
from azure.cli.core.commands.parameters import tags_type


def compute_param(c):
    c.argument(
        "name",
        options_list=["--name", "-n"],
        type=str,
        help="Name of the compute target (Required if not specified in the yaml file).",
    )


def load_compute_params(self):
    with self.argument_context("ml compute list") as c:
        add_common_params(c)
        add_max_results_params(c)
        c.argument("type", help="The type of compute target. Allowed values: AmlCompute, ComputeInstance.")

    with self.argument_context("ml compute show") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute create") as c:
        add_common_params(c)
        add_override_param(c)
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the compute target. Required if --file/-f is not provided.",
        )
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML compute specification.",
        )
        c.argument(
            "admin_username", help="Name of the administrator user account that can be used to SSH into the node(s)."
        )
        c.argument("ssh_key_value", help="SSH public key of the administrator user account.")
        c.argument("vnet_name", help="Name of the virtual network.")
        c.argument("subnet", help="Name of the subnet.")
        c.argument(
            "type",
            options_list=["--type", "-t"],
            help="The type of compute target. Required if --file/-f is not provided. Allowed values: AmlCompute, ComputeInstance.",
        )
        c.argument("description", help="Description of the compute target.")
        c.argument("tags", tags_type, help="Space-separated tags for the compute target.")
        c.argument(
            "enable_public_ip", help="Indicates whether to enable public IP for the compute.", is_experimental=True
        )
        c.argument(
            "size",
            help="VM size to use for the compute target. More details can be found here: https://aka.ms/azureml-vm-details.",
        )

    with self.argument_context("ml compute create", arg_group="AmlCompute") as c:
        c.argument(
            "identity_type",
            help="The type of managed identity. Allowed values: SystemAssigned, UserAssigned.",
        )
        c.argument(
            "user_assigned_identities",
            options_list=["--user-assigned-identities", "-i"],
            help="Comma-separated resource IDs (e.g. 'ResourceID1,ResourceID2') to set user-assigned managed identities. Only supported if --identity-type is 'UserAssigned'.",
        )
        c.argument(
            "admin_password", help="Password for the administrator user account if authentication type is 'Password'"
        )
        c.argument("min_instances", help="The minimum number of nodes to use on the cluster. Default: 0.")
        c.argument("max_instances", help="The maximum number of nodes to use on the cluster.")
        c.argument(
            "idle_time_before_scale_down",
            options_list=["--idle-time-before-scale-down", "-s"],
            help="Idle time in seconds before scaling down the cluster.",
        )
        c.argument("priority", help="VM priority. Allowed values: Dedicated, LowPriority.")

    with self.argument_context("ml compute create", arg_group="ComputeInstance") as c:
        c.argument("user_tenant_id", help="AAD tenant ID of the assigned user.")
        c.argument("user_object_id", help="AAD object ID of the assigned user.")
        c.argument("public_ip", help="Public IP Address of this ComputeInstance (only applies to ComputeInstance)")

    with self.argument_context("ml compute delete") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute list-sizes") as c:
        add_common_params(c)
        compute_param(c)
        c.argument(
            "type",
            options_list=["--type", "-t"],
            help="The type of compute target. Allowed values: AmlCompute, ComputeInstance",
        )
        c.argument("recommended", help="Indicates whether to return recommended VM sizes or all VM sizes.")

    with self.argument_context("ml compute list-usage") as c:
        add_common_params(c)
        compute_param(c)
        c.argument("location", help="Defaults to workspace location.")

    with self.argument_context("ml compute start") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute stop") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute restart") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute update") as c:
        add_common_params(c)
        compute_param(c)
        c.argument(
            "identity_type",
            help="The type of managed identity. Allowed values: SystemAssigned, UserAssigned.",
        )
        c.argument(
            "user_assigned_identities",
            options_list=["--user-assigned-identities", "-i"],
            help="Comma-separated resource IDs (e.g. 'ResourceID1,ResourceID2') to set user-assigned managed identities. Only supported if --identity-type is 'UserAssigned'.",
        )
        c.argument("min_instances", help="Minimum number of nodes to use.")
        c.argument("max_instances", help="Maximum number of nodes to use.")
        c.argument(
            "idle_time_before_scale_down",
            options_list=["--idle-time-before-scale-down", "-s"],
            help="Idle time in seconds before scaling down the cluster.",
        )

    with self.argument_context("ml compute detach") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute attach") as c:
        add_common_params(c)
        compute_param(c)
        c.argument(
            "type", options_list=["--type", "-t"], help="The type of compute target. Allowed values: AKS, RemoteVM."
        )
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML compute specification.",
        )
        c.argument(
            "resource_id", help="The fully qualified ID of the resource, including the resource name and resource type."
        )
        c.argument(
            "admin_username", help="Name of the administrator user account that can be used to SSH into the node(s)."
        )
        c.argument("file", help="Local path to the YAML file containing the Azure ML compute specification.")
        c.argument("ssh_key_value", help="SSH public key of the administrator user account.")
