# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import json
import copy
from typing import Dict, Optional, Union
from math import ceil
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.command_job import CommandJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    JobBaseResource,
    CommandJob as RestCommandJob,
    ManagedIdentity,
    AmlToken,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import from_iso_duration_format, to_iso_duration_format
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BASE_PATH_CONTEXT_KEY,
    TYPE,
    JobType,
)
from .job import Job
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict
from .parameterized_command import ParameterizedCommand

module_logger = logging.getLogger(__name__)


class CommandJob(Job, ParameterizedCommand):
    """Command job

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param description: Description of the resource.
    :type description: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param experiment_name:  Name of the experiment the job will be created under, if None is provided, default will be set to current directory name.
    :type experiment_name: str
    :param status: Status of the job.
    :type status: str
    :param creation_context: Creation metadata of the job.
    :type creation_context: SystemData
    :param interaction_endpoints: Infomation on how to interact with the job.
    :type interaction_endpoints: dict[str, JobEndpoint]
    :param timeout: The maximum time allowed for the run in seconds. The system will attempt to
        automatically cancel the run if it took longer than this value.
    :type timeout: int
    :param inputs: Inputs to the command.
    :type inputs: dict
    :param command: Command to be executed in training.
    :type command: str
    :param compute: Creation metadata of the job.
    :type compute: ComputeBinding
    :param code: Code object or code file or folder that will be uploaded to the cloud for job execution.
    :type code: Union[Code, str]
    :param distribution: Distribution configuration for distributed training.
    :type distribution: Union[PyTorch, Mpi, TensorFlow]
    :param environment: Environment that training job will run in.
    :type environment: Union[InternalEnvironment, str]
    :param identity: Identity that training job will use while running on compute.
    :type identity: Union[ManagedIdentity, AmlToken]
    :param parameters: MLFlow parameters logged in job
    :type parameters: dict
    :param output: Location of job output and logs in storage.
    :type output: JobOutput
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    def __init__(
        self,
        timeout: int = None,
        identity: Union[ManagedIdentity, AmlToken] = None,
        parameters={},
        environment_variables=None,
        **kwargs
    ):
        kwargs[TYPE] = JobType.COMMAND
        super().__init__(**kwargs)
        self.timeout = timeout
        self._identity = identity
        self._parameters = parameters
        self._environment_variables = dict(environment_variables) if environment_variables else {}

    @property
    def parameters(self) -> Dict[str, str]:
        return self._parameters

    @property
    def identity(self) -> Union[ManagedIdentity, AmlToken]:
        return self._identity

    @identity.setter
    def identity(self, identity: Union[ManagedIdentity, AmlToken]) -> None:
        self._identity = identity

    @property
    def environment_variables(self) -> Dict[str, str]:
        return self._environment_variables

    @environment_variables.setter
    def environment_variables(self, environment_variables) -> None:
        self._environment_variables = environment_variables

    def _dump_yaml(self) -> Dict:
        return CommandJobSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    def _to_rest_object(self) -> JobBaseResource:
        self._bind_inputs()
        self._validate()
        # TODO: Remove writing service endpoints via properties after MFE removes readonly flag
        # https://msdata.visualstudio.com/DefaultCollection/Vienna/_workitems/edit/1153695
        modified_properties = copy.deepcopy(self.properties)
        if self.interaction_endpoints:
            endpoints = {}
            for key, value in self.interaction_endpoints.items():
                # duplicate entries, since client missed the contract change,
                # and the MFE function that reads this loads it to the old contract.
                entry = value.as_dict()

                entry["type"] = entry.get("job_endpoint_type", None)
                endpoints[key] = entry
            modified_properties["ServiceEndpoints"] = json.dumps(endpoints)
        properties = RestCommandJob(
            description=self.description,
            timeout=to_iso_duration_format(self.timeout),
            command=self._bound_command,
            code_id=self.code,
            compute=self.compute.dump_to_rest(),
            properties=modified_properties,
            experiment_name=self.experiment_name,
            input_data_bindings=self._data_bindings,
            environment_id=self.environment,
            distribution=self.distribution,
            tags=self.tags,
            identity=self.identity,
            environment_variables=self.environment_variables,
        )
        result = JobBaseResource(properties=properties)
        result.name = self.name
        return result

    @classmethod
    def _load_from_dict(cls, data: Dict, context: Dict, additional_message: str, **kwargs) -> "CommandJob":
        loaded_data = load_from_dict(CommandJobSchema, data, context, additional_message, **kwargs)
        return CommandJob(**loaded_data)

    @classmethod
    def _load_from_rest(cls, obj: JobBaseResource) -> "CommandJob":
        rest_command_job = obj.properties
        rest_compute = rest_command_job.compute
        compute = InternalComputeConfiguration(
            target=rest_compute.target,
            is_local=rest_compute.is_local,
            instance_count=rest_compute.instance_count,
            location=rest_compute.location,
            instance_type=rest_compute.instance_type,
            properties=rest_compute.properties,
            deserialize_properties=True,
        )
        command_job = CommandJob(
            name=obj.name,
            id=obj.id,
            description=rest_command_job.description,
            tags=rest_command_job.tags,
            properties=rest_command_job.properties,
            timeout=from_iso_duration_format(rest_command_job.timeout),
            experiment_name=rest_command_job.experiment_name,
            interaction_endpoints=rest_command_job.interaction_endpoints,
            status=rest_command_job.status,
            creation_context=obj.system_data,
            code=rest_command_job.code_id,
            compute=compute,
            environment=rest_command_job.environment_id,
            distribution=rest_command_job.distribution,
            parameters=rest_command_job.parameters,
            output=rest_command_job.output,
            identity=rest_command_job.identity,
            environment_variables=rest_command_job.environment_variables,
        )

        command_job._unbind_inputs(rest_command_job)
        return command_job

    def _validate(self) -> None:
        if self.name is None:
            raise NameError("Job name is required")
        if self.compute is None:
            raise NameError("compute is required")
        if self._bound_command is None:
            raise NameError("command is required")
        if self.environment is None:
            raise NameError("environment is required for non-local runs")
