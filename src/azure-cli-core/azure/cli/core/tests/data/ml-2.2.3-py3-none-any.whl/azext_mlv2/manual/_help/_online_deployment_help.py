# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_online_deployment_help():
    helps[
        "ml online-deployment"
    ] = """
        type: group
        short-summary: Manage Azure ML online deployments.
        long-summary: >
          Azure ML deployments provide a simple interface for creating and managing model deployments.

    """
    helps[
        "ml online-deployment create"
    ] = """
        type: command
        short-summary: Create a deployment. If the deployment already exists, it will be over-written with the new settings.
        examples:
        - name: Create a deployment from a YAML specification file
          text: az ml online-deployment create --file deployment.yaml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-deployment update"
    ] = """
        type: command
        short-summary: Update a deployment.
        examples:
        - name: Update a deployment from a YAML specification file
          text: az ml online-deployment update --file deployment.yaml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-deployment show"
    ] = """
        type: command
        short-summary: Show a deployment.
        examples:
        - name: Show a deployment
          text: az ml online-deployment show --name my-deployment --endpoint-name my-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-deployment list"
    ] = """
        type: command
        short-summary: List deployments.
        examples:
        - name: List deployment in an endpoint
          text: az ml online-deployment list --endpoint-name my-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-deployment delete"
    ] = """
        type: command
        short-summary: Delete a deployment.
        examples:
        - name: Delete a deployment with confirmation
          text: az ml online-deployment delete --name my-deployment --endpoint-name my-endpoint --yes --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-deployment get-logs"
    ] = """
        type: command
        short-summary: Get the container logs for an online deployment.
        examples:
        - name: Get the container logs for an online deployment
          text: az ml online-deployment get-logs --name my-deployment --endpoint-name my-endpoint --lines 100 --resource-group my-resource-group --workspace-name my-workspace
    """
