# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict
from itertools import islice
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Environment
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings


def ml_environment_create(
    cmd,
    resource_group_name,
    workspace_name,
    file=None,
    name=None,
    version=None,
    tags=None,
    description=None,
    image=None,
    conda_file=None,
    build_context=None,
    dockerfile_path="/Dockerfile",
    os_type=None,
    params_override=None,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    if name:
        params_override.append({"name": name})
    if version:
        params_override.append({"version": version})
    if tags:
        params_override.append({"tags": tags})
    if description:
        params_override.append({"description": description})
    if image:
        params_override.append({"image": image})
    if conda_file:
        params_override.append({"conda_file": conda_file})
    if build_context:
        build = {"local_path": build_context, "dockerfile_path": dockerfile_path}
        params_override.append({"build": build})
    if os_type:
        params_override.append({"os_type": os_type})

    try:
        environment = Environment.load(path=file, params_override=params_override)
        environment = ml_client.create_or_update(environment)
        return _dump_entity_with_warnings(environment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_environment_show(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        environment = ml_client.environments.get(name=name, version=version, label=label)
        return _dump_entity_with_warnings(environment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_environment_list(cmd, resource_group_name, workspace_name, name=None, max_results=None, include_archived=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if max_results:
            results = islice(
                ml_client.environments.list(name=name, include_archived=include_archived), int(max_results)
            )
        else:
            results = ml_client.environments.list(name=name, include_archived=include_archived)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_environment_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        # Set unknown to EXCLUDE so that marshallow doesn't raise on dump only fields.
        environment = Environment._load(data=parameters)
        updated_environment = ml_client.create_or_update(environment)
        return _dump_entity_with_warnings(updated_environment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_environment_archive(cmd, name, resource_group_name, workspace_name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        return ml_client.environments.archive(name=name, version=version, label=label)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_environment_restore(cmd, name, resource_group_name, workspace_name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        return ml_client.environments.restore(name=name, version=version, label=label)
    except Exception as err:
        log_and_raise_error(err, debug)
