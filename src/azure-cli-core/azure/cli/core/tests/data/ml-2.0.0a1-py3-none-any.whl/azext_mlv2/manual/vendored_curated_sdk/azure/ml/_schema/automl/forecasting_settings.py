# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load, pre_load, pre_dump
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, NestedField, UnionField, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.automl.forecasting import ForecastingSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    TargetLagsMode,
)


class ForecastingSettingsSchema(metaclass=PatchedSchemaMeta):
    country_or_region_for_holidays = fields.Str()
    forecast_horizon = fields.Int()
    target_lags = UnionField(
        [
            StringTransformedEnum(allowed_values=[TargetLagsMode.AUTO, TargetLagsMode.OFF]),
            fields.Int(),
            fields.List(fields.Int()),
        ]
    )
    target_rolling_window_size = fields.Int()
    time_column_name = fields.Str()
    time_series_id_column_names = UnionField([fields.Str(), fields.List(fields.Str())])

    @post_load
    def make(self, data, **kwargs):
        return ForecastingSettings(**data)
