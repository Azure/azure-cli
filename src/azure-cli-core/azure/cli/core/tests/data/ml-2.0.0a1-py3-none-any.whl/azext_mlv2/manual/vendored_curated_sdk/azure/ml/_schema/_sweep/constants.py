# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


TYPE = "type"

BASE_ERROR_MESSAGE = "Search space type not one of: "
