# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import re
from typing import Dict, Optional, Any, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    CodeConfiguration as RestCodeConfiguration,
    InputDataBinding,
    TrialComponent,
    Mpi,
    TensorFlow,
    PyTorch,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Code
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.loadable_mixin import LoadableMixin
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import InputOutputEntry
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import InputPort


module_logger = logging.getLogger(__name__)


class ParameterizedCommand(LoadableMixin):
    """Command component that contains the traning command and supporting parameters for the command.

    :param base_path: TBD.
    :type base_path: str
    :param inputs: Inputs to the command.
    :type inputs: dict
    :param command: Command to be executed in training.
    :type command: str
    :param compute: Creation metadata of the job.
    :type compute: ComputeConfiguration
    :param code: Code object or code file or folder that will be uploaded to the cloud for job execution.
    :type code: Union[Code, str]
    :param distribution: Distribution configuration for distributed training.
    :type distribution: Union[PyTorch, Mpi, TensorFlow]
    :param environment: Environment that training job will run in.
    :type environment: Union[Environment, str]
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    INPUT_BINDING_PREFIX = "AZURE_ML_INPUT_"
    OLD_INPUT_BINDING_PREFIX = "AZURE_ML_INPUT"

    def __init__(
        self,
        base_path: Optional[str] = None,
        inputs: Dict[str, InputOutputEntry] = None,
        command: str = "",
        compute: InternalComputeConfiguration = None,
        code: Union["Code", str] = None,
        distribution: Union[PyTorch, Mpi, TensorFlow] = None,
        environment: Union["Environment", str] = None,
        **kwargs,
    ):

        super().__init__(**kwargs)
        self.input_values = inputs or {}
        self._command = command
        self._input_ports = {}
        self._bound_command: str
        self._data_bindings: Dict[str, Any] = {}
        self._base_path = base_path
        self.compute = compute
        self.code = code
        self.environment = environment
        self.distribution = distribution

    @property
    def command(self) -> str:
        return self._command

    @command.setter
    def command(self, value: str) -> None:
        self._command = value

    def _add_implicit_ports(self) -> None:
        implicit_inputs = re.findall(r"\{inputs\.([\w\.-]+)}", self._command)
        for key in implicit_inputs:
            if not self._input_ports.get(key, None):
                self._input_ports[key] = InputPort(type_string="null", optional=False)

    def _bind_inputs(self) -> None:
        self._add_implicit_ports()
        data_bindings: Dict[str, Any] = {}

        self._bound_command = self._command
        input_index = 0
        for key, port in self._input_ports.items():
            connected_value = self.input_values.get(key, None)
            value = connected_value.data or port.default
            if not value and not port.optional:
                raise Exception("Missing required input: " + key)
            # handle constants directly
            if port.type_string == "number" or (port.type_string == "null" and connected_value.mode is None):
                self._bound_command = re.sub(r"\{inputs\." + key + "}", value, self._bound_command)
            else:
                local_reference = self.INPUT_BINDING_PREFIX + key
                data_bindings[key] = InputDataBinding(data_id=value, mode=connected_value.mode)
                self._bound_command = re.sub(r"\{inputs\." + key + "}", f"${local_reference}", self._bound_command)
                input_index += 1
        self._data_bindings = data_bindings

    def _unbind_inputs(self, properties: TrialComponent) -> None:
        command = properties.command
        inputs = {}

        try:
            if properties.input_data_bindings:
                for key, input in properties.input_data_bindings.items():
                    command = re.sub(r"\$" + f"{self.INPUT_BINDING_PREFIX + key}", "{inputs." + key + "}", command)
                    # Commands with input binding from before change stored env var name in 'PathOnCompute'
                    if (
                        hasattr(input, "path_on_compute")
                        and input.path_on_compute is not None
                        and re.match(f"{self.OLD_INPUT_BINDING_PREFIX}" + r"\d+", input.path_on_compute)
                    ):
                        # Following change to support single file datasets, inputs are referenced as env vars
                        command = re.sub(r"\$" + f"{input.path_on_compute}", "{inputs." + key + "}", command)
                        # Prior to the change, inputs were subbed in as directory names, they should still be shown on client
                        command = re.sub(f"{input.path_on_compute}", "{inputs." + key + "}", command)
                    inputs[key] = InputOutputEntry(mode=input.mode, data=input.data_id)
        except Exception:
            raise Exception("Unable to load data bindings")
        self.inputs = inputs
        self.command = command

    def _generate_code_configuration(self) -> RestCodeConfiguration:
        return RestCodeConfiguration(code_id=self.code, scoring_script=None)

    def load(self, obj: TrialComponent) -> None:
        super().load(obj)
        self._unbind_inputs(obj)
        self.code = obj.code_id
        self._environment = obj.environment_id
        self.distribution = obj.distribution
