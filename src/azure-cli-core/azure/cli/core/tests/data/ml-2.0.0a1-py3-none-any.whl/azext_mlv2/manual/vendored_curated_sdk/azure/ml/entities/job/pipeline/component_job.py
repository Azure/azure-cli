# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict, Any
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import ComponentJobConstants, JobType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import InputOutputEntry
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    ComponentJob as RestComponentJob,
    ComponentJobInput,
    ComponentJobOutput,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.pipeline._pipeline_job_helpers import (
    to_rest_dataset_literal_inputs,
    from_rest_dataset_literal_inputs,
    to_rest_data_outputs,
    from_rest_data_outputs,
    process_sdk_component_job_io,
    process_rest_component_job_io,
)


class ComponentJob(RestTranslatableMixin):
    """ComponentJob

    :param type: Type of ComponentJob
    :type type: str
    :param component: Id of the component to be run for the step
    :type component: str
    :param compute: Compute defintion containing the compute information for the step
    :type compute: InternalComputeConfiguration
    :param inputs: Inputs to the step
    :type inputs: Dict[str, Any]
    """

    def __init__(
        self,
        type: str = JobType.COMPONENT,
        component: str = None,
        compute: InternalComputeConfiguration = None,
        inputs: Dict[str, Any] = None,
        outputs: Dict[str, InputOutputEntry] = None,
    ):
        self.type = type
        self.component = component
        self.compute = compute
        self.inputs = dict(inputs) if inputs else {}
        self.outputs = dict(outputs) if outputs else {}

    def _to_rest_object(self) -> RestComponentJob:

        rest_inputs, dataset_literal_inputs = process_sdk_component_job_io(
            self.inputs, [ComponentJobConstants.INPUT_PREFIX, ComponentJobConstants.JOB_PREFIX], ComponentJobInput
        )
        rest_dataset_literal_inputs = to_rest_dataset_literal_inputs(dataset_literal_inputs, ComponentJobInput)
        rest_inputs = {**rest_inputs, **rest_dataset_literal_inputs}

        rest_outputs, data_outputs = process_sdk_component_job_io(
            self.outputs,
            [
                ComponentJobConstants.OUTPUT_PREFIX,
            ],
            ComponentJobOutput,
        )
        rest_data_outputs = to_rest_data_outputs(data_outputs, ComponentJobOutput)
        rest_outputs = {**rest_outputs, **rest_data_outputs}
        return RestComponentJob(
            compute=self.compute.dump_to_rest() if self.compute else None,
            component_id=self.component,
            inputs=rest_inputs,
            outputs=rest_outputs,
        )

    @classmethod
    def _from_rest_object(cls, obj: RestComponentJob) -> "ComponentJob":
        from_rest_input_bindings, rest_data_literal_inputs = process_rest_component_job_io(obj.inputs)
        from_rest_data_literal_inputs = from_rest_dataset_literal_inputs(rest_data_literal_inputs)
        from_rest_inputs = {**from_rest_input_bindings, **from_rest_data_literal_inputs}

        from_rest_output_bindings, rest_data_outputs = process_rest_component_job_io(obj.outputs)
        data_outputs_from_rest = from_rest_data_outputs(rest_data_outputs)
        from_rest_outputs = {**from_rest_output_bindings, **data_outputs_from_rest}

        compute_binding = obj.compute
        compute = (
            InternalComputeConfiguration(
                target=compute_binding.target,
                is_local=compute_binding.is_local,
                instance_count=compute_binding.instance_count,
            )
            if compute_binding
            else None
        )
        return ComponentJob(
            component=obj.component_id,
            compute=compute,
            inputs=from_rest_inputs,
            outputs=from_rest_outputs,
        )
