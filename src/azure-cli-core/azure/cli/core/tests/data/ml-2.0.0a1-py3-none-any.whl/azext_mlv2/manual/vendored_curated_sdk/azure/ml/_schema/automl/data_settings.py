# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType, AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, NestedField, ArmVersionedStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    DataSettings,
    TrainingDataSettings,
    ValidationDataSettings,
)


class TrainingDataSchema(metaclass=PatchedSchemaMeta):
    dataset_arm_id = ArmVersionedStr(
        azureml_type=AzureMLResourceType.DATA, required=True, data_key=AutoMLConstants.DATASET_YAML
    )
    target_column_name = fields.Str(required=True)
    weight_column_name = fields.Str()

    @post_load
    def make(self, data, **kwargs):
        return TrainingDataSettings(**data)


class ValidationDataSchema(metaclass=PatchedSchemaMeta):
    dataset_arm_id = ArmVersionedStr(azureml_type=AzureMLResourceType.DATA, data_key=AutoMLConstants.DATASET_YAML)
    validation_size = fields.Float(data_key=AutoMLConstants.VALIDATION_DATASET_SIZE_YAML)
    n_cross_validations = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return ValidationDataSettings(**data)


class DataSettingsSchema(metaclass=PatchedSchemaMeta):
    training_data = NestedField(TrainingDataSchema(), data_key=AutoMLConstants.TRAINING_DATA_SETTINGS_YAML)
    validation_data = NestedField(ValidationDataSchema(), data_key=AutoMLConstants.VALIDATION_DATA_SETTINGS_YAML)

    @post_load
    def make(self, data, **kwargs):
        return DataSettings(**data)
