# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands.parameters import get_enum_type

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AssetTypes
from ._common_params import (
    add_common_params,
    add_override_param,
    add_max_results_params,
    add_description_param,
    add_include_archived_param,
)


def add_name_and_version_params(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the data asset.")
    c.argument("version", options_list=["--version", "-v"], help="Version of the data asset.")


def add_label_param(c):
    c.argument("label", options_list=["--label", "-l"], help="Label of the data asset.")


def load_data_params(self):
    with self.argument_context("ml data list") as c:
        add_common_params(c)
        c.argument(
            "name",
            options_list=["--name", "-n"],
            type=str,
            help="Name of the data asset. If provided, all the data versions under this name will be returned.",
        )
        add_include_archived_param(c, help_message="List archived data assets and active data assets.")
        add_max_results_params(c)

    with self.argument_context("ml data show") as c:
        add_common_params(c)
        add_name_and_version_params(c)

    with self.argument_context("ml data create") as c:
        add_common_params(c)
        add_override_param(c)
        add_name_and_version_params(c)
        add_description_param(c, help_message="Description of the data asset.")
        c.argument("description", options_list=["--description", "-d"], help="Description of the data asset.")
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML data specification. --name/-n and --version/-v must be provided if YAML file does not have name and version.",
        )
        c.argument("path", options_list=["--path", "-p"], help="Path to the data asset, can be local or remote.")
        c.argument(
            "type",
            options_list=["--type", "-t"],
            help="Type of the data asset.",
            arg_type=get_enum_type([AssetTypes.URI_FILE, AssetTypes.URI_FOLDER]),
        )

    with self.argument_context("ml data update") as c:
        add_common_params(c)
        add_name_and_version_params(c)

    with self.argument_context("ml data archive") as c:
        add_common_params(c)
        add_name_and_version_params(c)
        add_label_param(c)

    with self.argument_context("ml data restore") as c:
        add_common_params(c)
        add_name_and_version_params(c)
        add_label_param(c)
