# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import fields
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._utils.utils import validate_arm_str
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.workspace.customer_managed_key import CustomerManagedKeySchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.workspace.private_endpoint import PrivateEndpointSchema


class WorkspaceSchema(PathAwareSchema):
    name = fields.Str(required=True)
    location = fields.Str()
    description = fields.Str()
    discovery_url = fields.Str()
    friendly_name = fields.Str()
    hbi_workspace = fields.Bool()
    storage_account = fields.Str(validate=validate_arm_str)
    container_registry = fields.Str(validate=validate_arm_str)
    key_vault = fields.Str(validate=validate_arm_str)
    application_insights = fields.Str(validate=validate_arm_str)
    customer_managed_key = NestedField(CustomerManagedKeySchema)
    private_endpoints = NestedField(PrivateEndpointSchema)
    tags = fields.Dict(keys=fields.Str(), values=fields.Str())
