# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import json
import logging
from os import PathLike, getenv
from os.path import sep
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Union

import jwt
from azure.identity import ChainedTokenCredential
from azure.core.exceptions import HttpResponseError

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations.run_history_constants import RunHistoryConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces as ServiceClient032021Preview,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import JobBaseResource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces as ServiceClient092020Preview,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._storage_utils import get_storage_client
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import create_session_with_retry, download_text_from_url
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    API_VERSION_2021_03_01_PREVIEW,
    API_VERSION_2020_09_01_PREVIEW,
    AzureMLResourceType,
    TID_FMT,
    DEFAULT_SCOPES,
    AZUREML_PRIVATE_FEATURES_ENV_VAR,
    BATCH_JOB_NOT_SUPPORTED_ERROR_CODE,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import (
    AutoMLJob,
    CommandJob,
    Job,
    SweepJob,
    PipelineJob,
    Component,
    CommandComponent,
    PipelineJobDefaults,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.pipeline.component_job import ComponentJob
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets.artifacts.data import Data
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import InputOutputEntry
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration

from .job_ops_helper import get_git_properties, list_logs, stream_logs_until_completion
from .local_job_invoker import is_local_run, start_run_if_local
from .operation_orchestrator import OperationOrchestrator
from .run_operations import RunOperations

module_logger = logging.getLogger(__name__)


class JobOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client_09_2020_preview: ServiceClient092020Preview,
        service_client_03_2021_preview: ServiceClient032021Preview,
        all_operations: OperationsContainer,
        credential: ChainedTokenCredential,
        **kwargs: Any,
    ):
        super(JobOperations, self).__init__(workspace_scope)
        self._operation_2020_09_preview = service_client_09_2020_preview.jobs
        self._operation_2021_03_preview = service_client_03_2021_preview.jobs
        self._all_operations = all_operations
        self._kwargs = kwargs
        self._runs = RunOperations(workspace_scope, service_client_03_2021_preview)
        self._stream_logs_until_completion = stream_logs_until_completion
        self._container = "azureml"
        self._credential = credential
        self._orchestrators = OperationOrchestrator(self._all_operations, self._workspace_scope)

    def list(self) -> Iterable[Job]:
        """List jobs of the workspace.

        :return: a list of jobs.
        :rtype: Iterable[Job]
        """
        if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR):
            rest_list = self._operation_2020_09_preview.list(
                self._workspace_scope.subscription_id,
                self._workspace_scope.resource_group_name,
                self._workspace_name,
                api_version=API_VERSION_2020_09_01_PREVIEW,
            )
        else:
            rest_list = self._operation_2021_03_preview.list(
                self._workspace_scope.subscription_id,
                self._workspace_scope.resource_group_name,
                self._workspace_name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
            )
        return map(lambda x: self._resolve_AzureML_id(Job._from_rest_object(x)), rest_list)

    def get(self, name: str, include_logs: bool = False) -> Job:
        """Get a job resource.

        :param str name: Name of the job.
        :return: Job object retrieved from the service.
        :rtype: Job
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        job_object = self._get_job(name)
        job = self._resolve_AzureML_id(Job._from_rest_object(job_object))
        if include_logs:
            # TODO: Remove when we move off of run history
            original_base_url = self._operation._client._base_url
            try:
                self._runs._operation._client._base_url = self._get_workspace_url()
                job.log_files = list_logs(self._runs, job_object)
            except Exception:
                raise
            finally:  # This is required else the _base_url is set to run history base uri
                self._operation._client._base_url = original_base_url
        return job

    def cancel(self, name: str) -> None:
        """Cancel job resource.

        :param str name: Name of the job.
        :return: None, or the result of cls(response)
        :rtype: None
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR):
            return self._operation_2020_09_preview.cancel(
                id=name,
                subscription_id=self._workspace_scope.subscription_id,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._kwargs,
            )
        else:
            return self._operation_2021_03_preview.cancel(
                id=name,
                subscription_id=self._workspace_scope.subscription_id,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._kwargs,
            )

    def create_or_update(self, job: Job) -> Job:
        """Create or update a job, if there're inline defined entities, e.g. Environment, Code, they'll be created together with the job.

        :param Job job: Job definition.
        :return: Created or updated job.
        :rtype: Job
        """

        # Create all dependent resources
        self._resolve_arm_id_or_upload_dependencies(job)
        git_props = get_git_properties()
        # Do not add git props if they already exist in job properties.
        # This is for update specifically-- if the user switches branches and tries to update their job, the request will fail since the git props will be repopulated.
        # MFE does not allow existing properties to be updated, only for new props to be added
        if not any(prop_name in job.properties for prop_name in git_props.keys()):
            job.properties = {**job.properties, **git_props}

        rest_job_resource = job._to_rest_object()
        if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR):
            result = self._operation_2020_09_preview.create_or_update(
                id=rest_job_resource.name,  # type: ignore
                subscription_id=self._workspace_scope.subscription_id,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                body=rest_job_resource,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._kwargs,
            )  # TODO: set default api_version to this
        else:
            result = self._operation_2021_03_preview.create_or_update(
                id=rest_job_resource.name,  # type: ignore
                subscription_id=self._workspace_scope.subscription_id,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                body=rest_job_resource,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._kwargs,
            )
        if is_local_run(result):
            ws_base_url = self._all_operations.all_operations[
                AzureMLResourceType.WORKSPACE
            ]._operation._client._base_url
            snapshot_id = start_run_if_local(result, self._credential, ws_base_url)
            # in case of local run, the first creat/update call to MFE returns the
            # request for submitting to ES. Once we request to ES and start the run, we
            # need to put the same body to MFE to append user tags etc.
            job_object = self._get_job(rest_job_resource.name)
            if result.properties.tags is not None:
                for tag_name, tag_value in rest_job_resource.properties.tags.items():
                    job_object.properties.tags[tag_name] = tag_value
            if result.properties.properties is not None:
                for prop_name, prop_value in rest_job_resource.properties.properties.items():
                    job_object.properties.properties[prop_name] = prop_value
            if snapshot_id is not None:
                job_object.properties.properties["ContentSnapshotId"] = snapshot_id
            if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR):
                result = self._operation_2020_09_preview.create_or_update(
                    id=rest_job_resource.name,  # type: ignore
                    subscription_id=self._workspace_scope.subscription_id,
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    body=job_object,
                    api_version=API_VERSION_2020_09_01_PREVIEW,
                    **self._kwargs,
                )
            else:
                result = self._operation_2021_03_preview.create_or_update(
                    id=rest_job_resource.name,  # type: ignore
                    subscription_id=self._workspace_scope.subscription_id,
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    body=job_object,
                    api_version=API_VERSION_2021_03_01_PREVIEW,
                    **self._kwargs,
                )
        return self._resolve_AzureML_id(Job._from_rest_object(result))

    def stream(self, name: str) -> None:
        """Stream logs of a job.

        :param str name: Name of the job.
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        job_object = self._get_job(name)

        # This should be done lazily on the workspaceSScope and cached
        original_base_url = self._operation_2021_03_preview._client._base_url
        try:
            self._runs._operation._client._base_url = self._get_workspace_url()
            self._stream_logs_until_completion(self._runs, job_object)
        except Exception:
            raise
        finally:  # This is required else the _base_url is set to run history base uri
            self._operation_2021_03_preview._client._base_url = original_base_url

    def download(self, name: str, logs_only: bool = False, download_path: Union[PathLike, str] = Path.home()) -> None:
        """Download logs and output of a job.

        :param str name: Name of the job.
        :param bool logs_only: Download logs only or logs and output.
        :param Union[PathLike, str] download_path: Local path as download destination, defaults to home directory of the current user.
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """

        job_details = self.get(name)
        job_status = job_details.status
        if job_status not in RunHistoryConstants.TERMINAL_STATUSES:
            raise Exception(
                "This job is in state {}. Download is allowed only in states {}".format(
                    job_status, RunHistoryConstants.TERMINAL_STATUSES
                )
            )

        if logs_only:
            prefix_list = [
                "ExperimentRun/dcid." + name + "/azureml-logs/",
                "ExperimentRun/dcid." + name + "/logs/",
            ]
        else:
            prefix_list = ["ExperimentRun/dcid." + name + "/"]

        ds = self._all_operations.all_operations[AzureMLResourceType.DATASTORE].get_default(include_secrets=True)
        acc_name = ds.account_name
        acc_key = ds.credential.key
        datastore_type = ds.storage_type

        storage_client = get_storage_client(
            credential=acc_key, container_name=self._container, storage_account=acc_name, storage_type=datastore_type
        )

        for item in prefix_list:
            path_file = "{}{}{}".format(download_path, sep, name)
            module_logger.info(f"Downloading the job logs {item} at {path_file}\n")
            storage_client.download(starts_with=item, destination=download_path)

    def _get_job(self, name: str) -> JobBaseResource:
        if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR):
            return self._operation_2020_09_preview.get(
                id=name,
                subscription_id=self._workspace_scope.subscription_id,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._kwargs,
            )
        else:
            try:
                return self._operation_2021_03_preview.get(
                    id=name,
                    subscription_id=self._workspace_scope.subscription_id,
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    api_version=API_VERSION_2021_03_01_PREVIEW,
                    **self._kwargs,
                )
            except HttpResponseError as e:
                if BATCH_JOB_NOT_SUPPORTED_ERROR_CODE in str(e.error):
                    return self._operation_2020_09_preview.get(
                        id=name,
                        subscription_id=self._workspace_scope.subscription_id,
                        resource_group_name=self._workspace_scope.resource_group_name,
                        workspace_name=self._workspace_name,
                        api_version=API_VERSION_2020_09_01_PREVIEW,
                        **self._kwargs,
                    )
                raise e

    def _get_workspace_url(self):
        discovery_url = (
            self._all_operations.all_operations[AzureMLResourceType.WORKSPACE]
            .get(self._workspace_scope.workspace_name)
            .discovery_url
        )
        all_urls = json.loads(download_text_from_url(discovery_url, create_session_with_retry()))
        return all_urls["history"]

    def _resolve_arm_id_or_upload_dependencies(self, job: Job) -> Job:
        """This method converts name or name:version to ARM id. Or it registers/uploads nested dependencies.

        :param job: the job resource entity
        :type job: Job
        :return: the job resource entity that nested dependencies are resolved
        :rtype: Job
        """
        return self._resolve_arm_id_or_AzureML_id(job, self._orchestrators.get_asset_arm_id)

    def _resolve_AzureML_id(self, job: Job) -> Job:
        """This method converts ARM id to name or name:version for nested entities.

        :param job: the job resource entity
        :type job: Job
        :return: the job resource entity that nested dependencies are resolved
        :rtype: Job
        """
        self._append_tid_to_studio_url(job)
        return self._resolve_arm_id_or_AzureML_id(job, self._orchestrators.resolve_AzureML_id)

    def _resolve_arm_id_or_AzureML_id(self, job: Job, resolver: Callable) -> Job:
        # TODO: this will need to be paralelized when multiple tasks
        # are required. Also consider the implications for dependencies.
        if job.output:
            job.output.datastore_id = resolver(job.output.datastore_id, azureml_type=AzureMLResourceType.DATASTORE)
        if isinstance(job, CommandJob):
            job.code = resolver(job.code, azureml_type=AzureMLResourceType.CODE)
            job.environment = resolver(job.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
            for key, value in job.input_values.items():
                value.data = resolver(value.data, azureml_type=AzureMLResourceType.DATA)
            if job.compute:
                try:
                    job.compute.target = resolver(
                        job.compute.target,
                        azureml_type=AzureMLResourceType.VIRTUALCLUSTER,
                        sub_workspace_resource=False,
                    )
                except Exception:
                    job.compute.target = resolver(job.compute.target, azureml_type=AzureMLResourceType.COMPUTE)
        elif isinstance(job, SweepJob):
            job.trial.code = resolver(job.trial.code, azureml_type=AzureMLResourceType.CODE)
            job.trial.environment = resolver(job.trial.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
            for key, value in job.trial.input_values.items():
                value.data = resolver(value.data, azureml_type=AzureMLResourceType.DATA)
            if job.trial.compute:
                job.trial.compute.target = resolver(job.trial.compute.target, azureml_type=AzureMLResourceType.COMPUTE)
        elif isinstance(job, AutoMLJob):
            # AutoML does not have dependency uploads. Only need to resolve reference to arm id.
            if job.compute:
                job.compute.target = resolver(job.compute.target, azureml_type=AzureMLResourceType.COMPUTE)
            try:  # None handling
                training_data = job.data_settings.training_data
                training_data.dataset_arm_id = resolver(
                    training_data.dataset_arm_id, azureml_type=AzureMLResourceType.DATA
                )
            except AttributeError as e:
                module_logger.debug(f"error while resolving training_data.dataset_arm_id to arm id. error: {e}\n")
            try:
                validation_data = job.data_settings.validation_data
                validation_data.dataset_arm_id = resolver(
                    validation_data.dataset_arm_id, azureml_type=AzureMLResourceType.DATA
                )
            except AttributeError as e:
                module_logger.debug(f"error while resolving validation_data.dataset_arm_id to arm id. error: {e}\n")
        elif isinstance(job, PipelineJob):
            # Get top-level job compute
            self._get_job_compute_id(job, resolver)
            # Process top-level job inputs
            self._get_pipeline_component_job_dataset_ids(job.inputs, resolver)
            # Process top-level job outputs
            self._get_pipeline_component_job_output_datastore_ids(job.outputs, resolver)
            # Process job defaults:
            if job.defaults:
                for default in job.defaults.values():
                    if default.compute:
                        default.compute.target = resolver(
                            default.compute.target, azureml_type=AzureMLResourceType.COMPUTE
                        )
                    default.datastore = resolver(default.datastore, azureml_type=AzureMLResourceType.DATASTORE)
                    default.code = resolver(default.code, azureml_type=AzureMLResourceType.CODE)
                    default.environment = resolver(default.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
            # Process each component job
            if job.jobs:
                for j in job.jobs.values():
                    # Get the default for the specific job type
                    default = job.defaults.get(j.type.lower(), None)

                    # Get compute for each job
                    self._get_job_compute_id(j, resolver)

                    # Process component job outputs:
                    self._get_pipeline_component_job_output_datastore_ids(
                        j.outputs,
                        resolver,
                    )

                    # set default code & environment for component
                    self._set_defaults_to_component(j.component, default)

                    # Get the component id for each job's component
                    j.component = resolver(j.component, azureml_type=AzureMLResourceType.COMPONENT)
        else:
            raise Exception(f"Non supported job type: {type(job)}")
        return job

    def _get_pipeline_component_job_dataset_ids(
        self, inputs: Dict[str, Union[str, float, bool, int, InputOutputEntry]], resolver: Callable
    ) -> None:
        """Processes dataset inputs for both PipelineJob and ComponentJob"""
        if inputs:
            for input_value in inputs.values():
                # Get the dataset ARM ID for any dataset inputs
                if isinstance(input_value, InputOutputEntry):
                    input_value.data = resolver(input_value.data, azureml_type=AzureMLResourceType.DATA)

    def _get_job_compute_id(self, job: Union[Job, ComponentJob], resolver: Callable) -> None:
        if job.compute:
            job.compute.target = resolver(job.compute.target, azureml_type=AzureMLResourceType.COMPUTE)

    def _append_tid_to_studio_url(self, job: Job) -> None:
        """Appends the user's tenant ID to the end of the studio URL so the UI knows against which tenant to authenticate"""
        try:
            studio_endpoint = job.interaction_endpoints.get("Studio", None)
            studio_url = studio_endpoint.endpoint
            # Extract the tenant id from the credential using PyJWT
            decode = jwt.decode(
                self._credential.get_token(*DEFAULT_SCOPES).token,
                options={"verify_signature": False, "verify_aud": False},
            )
            tid = decode["tid"]
            formatted_tid = TID_FMT.format(tid)
            studio_endpoint.endpoint = studio_url + formatted_tid
        except Exception:
            module_logger.info("Proceeding with no tenant id appended to studio URL\n")

    def _get_pipeline_component_job_output_datastore_ids(
        self,
        outputs: Dict[str, Union[str, InputOutputEntry]],
        resolver: Callable,
    ) -> None:
        """Processes the datastore for PipelineJob and ComponentJob outputs"""
        if outputs:
            for output_value in outputs.values():
                if isinstance(output_value, InputOutputEntry):
                    output_value.data._datastore = resolver(
                        output_value.data.datastore, azureml_type=AzureMLResourceType.DATASTORE
                    )

    def _set_defaults_to_component(self, component: Union[str, Component], default: PipelineJobDefaults):
        """Set default code&environment to component if not specified."""
        if isinstance(component, CommandComponent):
            if not component.code:
                component.code = default.code
            if not component.environment:
                component.environment = default.environment
