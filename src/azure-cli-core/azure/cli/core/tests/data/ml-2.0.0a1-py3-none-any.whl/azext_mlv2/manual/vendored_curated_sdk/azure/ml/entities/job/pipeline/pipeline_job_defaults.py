# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets.artifacts.code import Code
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets.environment import Environment


class PipelineJobDefaults(object):
    def __init__(
        self,
        code: Union[str, Code] = None,
        compute: InternalComputeConfiguration = None,
        environment: Union[str, Environment] = None,
        datastore: str = None,
    ):
        self.code = code
        self.compute = compute
        self.environment = environment
        self.datastore = datastore
