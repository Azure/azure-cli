# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import ComponentInput as RestComponentInput
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.component.input_output import ComponentInput, ComponentOutput


def component_io_to_rest_obj(io_dict: Dict):
    """Component inputs/outputs entity to rest object."""
    rest_component_io = {}
    for name, port in io_dict.items():
        rest_component_io[name] = port._to_rest_object()
    return rest_component_io


def component_io_from_rest_obj(component_io: Dict):
    """Rest component inputs/outputs to dictionary."""
    component_io_dict = {}
    for name, rest_obj in component_io.items():
        if isinstance(rest_obj, RestComponentInput):
            io = ComponentInput._from_rest_object(rest_obj)
        else:
            io = ComponentOutput._from_rest_object(rest_obj)
        component_io_dict[name] = io
    return component_io_dict
