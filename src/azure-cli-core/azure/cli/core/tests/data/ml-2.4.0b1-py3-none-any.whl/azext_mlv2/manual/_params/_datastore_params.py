# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_max_results_params, add_file_param
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.constants import YAMLRefDocLinks


def load_datastore_params(self):
    with self.argument_context("ml datastore delete") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the datastore.")

    with self.argument_context("ml datastore show") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the datastore.")

    with self.argument_context("ml datastore list") as c:
        add_common_params(c)
        add_max_results_params(c)

    with self.argument_context("ml datastore create") as c:
        add_common_params(c)
        add_override_param(c)
        add_file_param(
            c,
            "datastore",
            [
                YAMLRefDocLinks.DATASTORE_BLOB,
                YAMLRefDocLinks.DATASTORE_FILE,
                YAMLRefDocLinks.DATASTORE_DATA_LAKE_GEN_1,
                YAMLRefDocLinks.DATASTORE_DATA_LAKE_GEN_2,
            ],
        )
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the datastore. This overwrites the 'name' field in the YAML file provided to --file/-f.",
        )

    with self.argument_context("ml datastore update") as c:
        add_common_params(c)
        add_override_param(c)
        add_file_param(
            c,
            "datastore",
            [
                YAMLRefDocLinks.DATASTORE_BLOB,
                YAMLRefDocLinks.DATASTORE_FILE,
                YAMLRefDocLinks.DATASTORE_DATA_LAKE_GEN_1,
                YAMLRefDocLinks.DATASTORE_DATA_LAKE_GEN_2,
            ],
        )
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the datastore. This overwrites the 'name' field in the YAML file provided to --file/-f.",
        )
