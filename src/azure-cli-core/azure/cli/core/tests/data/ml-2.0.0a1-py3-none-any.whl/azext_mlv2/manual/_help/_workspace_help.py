# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_workspace_help():
    helps[
        "ml workspace"
    ] = """
        type: group
        short-summary: Manage Azure ML workspaces.
        long-summary: >
            An Azure ML workspace is the top-level resource for Azure Machine Learning. It provides
            a centralized place to track the assets and resources used in your ML workflows, along
            with the logs and artifacts produced from your training jobs.
    """
    helps[
        "ml workspace list"
    ] = """
        type: command
        short-summary: List all the workspaces in a subscription.
        long-summary: >
            The list of workspaces can be filtered by resource group.
    """
    helps[
        "ml workspace show"
    ] = """
        type: command
        short-summary: Show details for a workspace.
    """
    helps[
        "ml workspace delete"
    ] = """
        type: command
        short-summary: Delete a workspace.
        long-summary: >
            By default the dependent resources associated with the workspace (Azure Storage,
            Azure Container Registry, Azure Key Vault, Azure Application Insights) are not deleted.
            To delete those as well, include --all-resources.
    """
    helps[
        "ml workspace create"
    ] = """
        type: command
        short-summary: Create a workspace.
        long-summary: >
            When a workspace is created, several Azure resources that will be used by Azure ML
            also get created by default: Azure Storage, Azure Container Registry, Azure Key Vault, and Azure Application
            Insights. You can instead use existing Azure resource instances for those when creating the workspace
            by specifying the resource IDs in the workspace configuration YAML file.
        examples:
        - name: Create a workspace from a YAML specification file.
          text: az ml workspace create --file workspace.yml --resource-group my-resource-group
    """
    helps[
        "ml workspace list-keys"
    ] = """
        type: command
        short-summary: List workspace keys for dependent resources such as Azure Storage, Azure Container Registry,
            and Azure Application Insights.
    """
    helps[
        "ml workspace sync-keys"
    ] = """
        type: command
        short-summary: Sync workspace keys for dependent resources such as Azure Storage, Azure Container Registry,
            and Azure Application Insights.
        long-summary: >
            If the keys for any resource in the workspace are changed, it can take around an hour for them to automatically
            be updated. This command triggers the workspace to immediately synchronize keys. A possible scenario is
            needing immediate access to storage after regenerating the storage keys.
     """
    helps[
        "ml workspace update"
    ] = """
        type: command
        short-summary: Update a workspace.
        long-summary: >
            The 'description', 'tags', 'friendly_name', and 'container_registry' properties can be updated.
    """
