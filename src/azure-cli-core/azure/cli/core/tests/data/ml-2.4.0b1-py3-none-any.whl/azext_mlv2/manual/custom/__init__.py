# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# flake8: noqa

from azure.cli.core.extension import ExtensionNotInstalledException
from azure.cli.core.extension.operations import add_extension_to_path
import logging

try:
    add_extension_to_path("ml")
except ExtensionNotInstalledException:
    logging.warning("Either ml extension is not installed or you are running ml extension in dev mode")

# set caller info to current telemetry session
from azure.cli.core import telemetry
from azext_mlv2.manual.custom import utils

telemetry.set_debug_info("SystemInvoker", utils.get_cli_system_executed())

from .job import *
from .datastore import *
from .online_endpoint import *
from .batch_endpoint import *
from .online_deployment import *
from .batch_deployment import *
from .model import *
from .data import *
from .dataset import *
from .environment import *
from .compute import *
from .workspace import *
from .workspace_connection import *
from .component import *

# nopycln: file
