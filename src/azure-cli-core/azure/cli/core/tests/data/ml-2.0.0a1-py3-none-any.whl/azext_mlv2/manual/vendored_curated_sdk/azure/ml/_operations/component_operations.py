# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import hashlib
import logging
import os
from uuid import UUID
from pathlib import Path
from typing import Dict, Iterable, Union, cast

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import OperationOrchestrator
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    ComponentVersionResource,
    ComponentContainer,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import _WorkspaceDependentOperations, WorkspaceScope, OperationsContainer
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import API_VERSION_2020_09_01_PREVIEW, OrderString, AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Component, CommandComponent, Code

module_logger = logging.getLogger(__name__)
CODE_IMMUTABLE_ERROR = "The field SnapshotId is immutable."
CHANGE_CODE_IMMUTABLE_ERROR = (
    "Component {} already exists with a different component code. "
    "The component code field is immutable, try specifying a new version."
)


class ComponentOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: AzureMachineLearningWorkspaces,
        all_operations: OperationsContainer,
        **kwargs: Dict,
    ):
        super(ComponentOperations, self).__init__(workspace_scope)
        self._version_operation = service_client.component_versions
        self._container_operation = service_client.component_containers
        self._all_operations = all_operations
        self._init_args = kwargs

    def list(self, name: Union[str, None] = None) -> Iterable[Union[Component, ComponentContainer]]:
        if name:
            component_iter = self._version_operation.list(
                name,
                self._subscription_id,
                self._resource_group_name,
                self._workspace_name,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._init_args,
            )
            return map(lambda x: Component._from_rest_object(x), component_iter)

        else:
            component_container_iter = self._container_operation.list(
                self._subscription_id,
                self._resource_group_name,
                self._workspace_name,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._init_args,
            )
            return component_container_iter

    def get(self, name: str, version: int = None) -> Component:

        if version is None:
            return self.get_latest_version(name)

        result = self._version_operation.get(
            name=name,
            version=version,
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            api_version=API_VERSION_2020_09_01_PREVIEW,
            **self._init_args,
        )
        component = Component._from_rest_object(result)
        return component

    def create_or_update(self, component: Component) -> Component:
        # Create all dependent resources
        self._upload_dependencies(component)

        rest_component_resource = component._to_rest_object()
        try:
            result = self._version_operation.create_or_update(
                name=rest_component_resource.name,
                version=component.version,
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                body=rest_component_resource,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._init_args,
            )
        except Exception as e:
            # If user tries to create same component with different code, raise exception with meaningful error msg.
            if CODE_IMMUTABLE_ERROR in str(e):
                # TODO: the exception type might be user error.
                raise Exception(CHANGE_CODE_IMMUTABLE_ERROR.format(rest_component_resource.name))
            raise e
        return Component._from_rest_object(result)

    def delete(self, name: str, version: int = None):

        if version:
            result = self._version_operation.delete(
                name=name,
                version=version,
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._init_args,
            )
        else:
            result = self._container_operation.delete(
                name=name,
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2020_09_01_PREVIEW,
                **self._init_args,
            )
        return result

    def get_latest_version(self, component_name: str) -> Component:
        """
        Gets the latest version of the component
        """

        for component in self._version_operation.list(
            component_name,
            self._subscription_id,
            self._resource_group_name,
            self._workspace_name,
            api_version=API_VERSION_2020_09_01_PREVIEW,
            order_by=OrderString.CREATED_AT_DESC,
            top=1,
            **self._init_args,
        ):
            result = cast(ComponentVersionResource, component)
            return Component._from_rest_object(result)

    def _upload_dependencies(self, component: Component) -> None:
        orchestrators = OperationOrchestrator(self._all_operations, self._workspace_scope)
        resolver = orchestrators.get_asset_arm_id

        if type(component) is CommandComponent:
            if component.code:
                component.code = resolver(component.code, azureml_type=AzureMLResourceType.CODE)
            if component.environment:
                component.environment = resolver(component.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
        else:
            raise Exception(f"Non supported component type: {type(component)}")
