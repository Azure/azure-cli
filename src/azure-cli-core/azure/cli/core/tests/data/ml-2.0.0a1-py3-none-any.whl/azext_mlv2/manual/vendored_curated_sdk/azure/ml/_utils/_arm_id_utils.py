# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import re
from typing import Any, Optional, Tuple

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    ARM_ID_FULL_PREFIX,
    ARM_ID_PREFIX,
    DATA_ARM_TYPE,
    DATASTORE_RESOURCE_ID,
    PROVIDER_RESOURCE_ID_WITH_VERSION,
    RESOURCE_ID_FORMAT,
    NAMED_RESOURCE_ID_FORMAT,
    AZUREML_RESOURCE_PROVIDER,
    LEVEL_ONE_NAMED_RESOURCE_ID_FORMAT,
)

module_logger = logging.getLogger(__name__)


class AMLVersionedArmId(object):
    """Parser for versioned arm id: e.g. /subscription/.../code/my-code/versions/1

    :param arm_id: the versioned arm id
    :type arm_id: str
    :raises ValueError: the arm id is incorrectly formatted
    """

    REGEX_PATTERN = (
        "^/?subscriptions/([^/]+)/resourceGroups/(["
        "^/]+)/providers/Microsoft.MachineLearningServices/workspaces/([^/]+)/([^/]+)/([^/]+)/([^/]+)/(["
        "^/]+)"
    )

    def __init__(self, arm_id=None):
        if arm_id:
            match = re.match(AMLVersionedArmId.REGEX_PATTERN, arm_id)
            if match is None:
                raise ValueError(f"Invalid AzureML ARM versioned Id {arm_id}")

            self.subscription_id = match.group(1)
            self.resource_group_name = match.group(2)
            self.workspace_name = match.group(3)
            self.azureml_type = match.group(4)
            self.asset_name = match.group(5)
            self.asset_version = match.group(7)


def get_datastore_arm_id(datastore_name: str = None, workspace_scope: WorkspaceScope = None) -> Optional[str]:
    return (
        DATASTORE_RESOURCE_ID.format(
            workspace_scope.subscription_id,
            workspace_scope.resource_group_name,
            workspace_scope.workspace_name,
            datastore_name,
        )
        if datastore_name
        else None
    )


class AMLNamedArmId:
    """Parser for named arm id (no version): e.g. /subscription/.../compute/goazurego

    :param arm_id: the named arm id
    :type arm_id: str
    :raises ValueError: the arm id is incorrectly formatted
    """

    REGEX_PATTERN = (
        "^/?subscriptions/([^/]+)/resourceGroups/(["
        "^/]+)/providers/Microsoft.MachineLearningServices/workspaces/([^/]+)/([^/]+)/([^/]+)"
    )

    def __init__(self, arm_id=None):
        if arm_id:
            match = re.match(AMLNamedArmId.REGEX_PATTERN, arm_id)
            if match is None:
                raise ValueError("Invalid AzureML ARM named Id {arm_id}")

            self.subscription_id = match.group(1)
            self.resource_group_name = match.group(2)
            self.workspace_name = match.group(3)
            self.azureml_type = match.group(4)
            self.asset_name = match.group(5)


def parse_prefixed_name_version(name: str) -> Tuple[str, Optional[str]]:
    if name.startswith(ARM_ID_PREFIX):
        return parse_name_version(name[len(ARM_ID_PREFIX) :])
    return parse_name_version(name)


def parse_name_version(name: str) -> Tuple[str, Optional[str]]:
    token_list = name.split(":")
    if len(token_list) == 1:
        return name, None
    else:
        *name, version = token_list  # type: ignore
        return ":".join(name), version


def is_ARM_id_for_resource(name: Any, resource_type: str = ".*", sub_workspace_resource: bool = True) -> bool:
    if sub_workspace_resource:
        resource_regex = NAMED_RESOURCE_ID_FORMAT.format(
            ".*", ".*", AZUREML_RESOURCE_PROVIDER, ".*", resource_type, ".*"
        )
    else:
        resource_regex = LEVEL_ONE_NAMED_RESOURCE_ID_FORMAT.format(
            ".*", ".*", AZUREML_RESOURCE_PROVIDER, resource_type, ".*"
        )
    if isinstance(name, str) and re.match(resource_regex, name, re.IGNORECASE):
        return True
    return False


def get_arm_id_with_version(
    workspace_scope: WorkspaceScope, provider_name: str, provider_value: str, provider_version: str
):
    return PROVIDER_RESOURCE_ID_WITH_VERSION.format(
        workspace_scope.subscription_id,
        workspace_scope.resource_group_name,
        workspace_scope.workspace_name,
        provider_name,
        provider_value,
        provider_version,
    )


def generate_data_arm_id(workspace_scope: WorkspaceScope, name: str, version: int):
    return get_arm_id_with_version(workspace_scope, DATA_ARM_TYPE, name, str(version))


def remove_aml_prefix(id: Optional[str]) -> Optional[str]:
    if not id:
        return None

    if id.startswith(ARM_ID_PREFIX):
        return id[len(ARM_ID_PREFIX) :]
    else:
        return id
