Microsoft Azure CLI 'cosmosdb' Command Module
=============================================

This package is for the 'cosmosdb' module.
i.e. 'az cosmosdb'


