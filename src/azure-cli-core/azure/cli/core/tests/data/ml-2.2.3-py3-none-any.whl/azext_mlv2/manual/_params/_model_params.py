# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import (
    add_common_params,
    add_override_param,
    add_max_results_params,
    add_tags_param,
    add_description_param,
    add_include_archived_param,
)


def add_version_param(c):
    c.argument("version", options_list=["--version", "-v"], type=str, help="Version of the model.")


def add_name_param(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the model.")


def add_label_param(c):
    c.argument("label", options_list=["--label", "-l"], help="Label of the model.")


def load_model_params(self):
    with self.argument_context("ml model create") as c:
        add_common_params(c)
        add_override_param(c)
        add_tags_param(c)
        add_name_param(c)
        add_version_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML model specification. --name/-n and --version/-v must be provided if YAML file does not have name and version.",
        )
        c.argument(
            "path",
            options_list=["--path", "-p"],
            help="Path to the model file(s). This can be either a local or a remote location. If specified, --name/-n and --version/-v must also be provided.",
        )
        c.argument(
            "type",
            options_list=["--type", "-t"],
            help="Type of the model, allowed values are custom_model, mlflow_model and triton_model. The default type is custom_model.",
        )
        add_description_param(c, help_message="Description of the model.")

    with self.argument_context("ml model show") as c:
        add_common_params(c)
        add_name_param(c)
        add_version_param(c)
        add_label_param(c)

    with self.argument_context("ml model download") as c:
        add_common_params(c)
        add_name_param(c)
        add_version_param(c)
        c.argument(
            "download_path",
            options_list=["--download-path", "-p"],
            help="Path to download the model files, defaults to the current working directory.",
        )

    with self.argument_context("ml model list") as c:
        add_common_params(c)
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the model. If provided, all the model versions under this name will be returned.",
        )
        add_max_results_params(c)
        add_include_archived_param(c, help_message="List archived models and active models.")

    with self.argument_context("ml model update") as c:
        add_common_params(c)
        add_override_param(c)
        add_name_param(c)
        add_version_param(c)
        add_label_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML model specification.",
        )
        add_description_param(c, help_message="Description of the model.")

    with self.argument_context("ml model archive") as c:
        add_common_params(c)
        add_name_param(c)
        add_version_param(c)
        add_label_param(c)

    with self.argument_context("ml model restore") as c:
        add_common_params(c)
        add_name_param(c)
        add_version_param(c)
        add_label_param(c)
