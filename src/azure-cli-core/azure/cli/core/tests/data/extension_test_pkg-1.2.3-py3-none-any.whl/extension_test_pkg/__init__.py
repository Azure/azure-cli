def diff_abc(ll=False):
    if ll:
        print("true from test pkg 2")
    else:
        print("false from test pkg 2")
