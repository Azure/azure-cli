﻿using ClassLibrary1;

namespace ClassLibrary2.Interfaces
{
    public interface IWeatherForecastService
    {
        IEnumerable<WeatherForecast> Get();
    }
}