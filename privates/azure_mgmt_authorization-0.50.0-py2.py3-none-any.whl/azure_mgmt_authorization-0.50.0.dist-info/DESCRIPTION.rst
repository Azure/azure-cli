Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Authorization Management Client Library.

Azure Resource Manager (ARM) is the next generation of management APIs that
replace the old Azure Service Management (ASM).

This package has been tested with Python 2.7, 3.4, 3.5 and 3.6.

For the older Azure Service Management (ASM) libraries, see
`azure-servicemanagement-legacy <https://pypi.python.org/pypi/azure-servicemanagement-legacy>`__ library.

For a more complete set of Azure libraries, see the `azure <https://pypi.python.org/pypi/azure>`__ bundle package.


Compatibility
=============

**IMPORTANT**: If you have an earlier version of the azure package
(version < 1.0), you should uninstall it before installing this package.

You can check the version using pip:

.. code:: shell

    pip freeze

If you see azure==0.11.0 (or any version below 1.0), uninstall it first:

.. code:: shell

    pip uninstall azure


Usage
=====

For code examples, see `Authorization Management
<https://docs.microsoft.com/python/api/overview/azure/authorization>`__
on docs.microsoft.com.


Provide Feedback
================

If you encounter any bugs or have suggestions, please file an issue in the
`Issues <https://github.com/Azure/azure-sdk-for-python/issues>`__
section of the project.


.. :changelog:

Release History
===============

0.50.0 (2018-05-29)
+++++++++++++++++++

**Features**

- Support Azure Stack (multi API versionning)
- Client class can be used as a context manager to keep the underlying HTTP session open for performance

**Breaking changes**

- Classic Administrators is back to 2015-07-01 API version (from 2015-06-01) which creates some breaking changes for this API.

**Bugfixes**

- Compatibility of the sdist with wheel 0.31.0

0.40.0 (2018-03-13)
+++++++++++++++++++

**Breaking changes**

- Several properties have been flattened and "properties" attribute is not needed anymore
  (e.g. properties.email_address => email_address)
- Some method signature change (e.g. create_by_id)

**Features**

- Adding attributes data_actions / not_data_actions / is_data_actions

API version is now 2018-01-01-preview

0.30.0 (2017-04-28)
+++++++++++++++++++

* Initial Release
* This wheel package is built with the azure wheel extension


