# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta
from marshmallow import fields, post_load

module_logger = logging.getLogger(__name__)


class ResourceRequirementsSchema(metaclass=PatchedSchemaMeta):
    cpu = fields.Float()
    memory_in_gb = fields.Float()
    gpu = fields.Int()
    cpu_limit = fields.Float(data_key="cpu_cores_limit")
    memory_in_gb_limit = fields.Float()

    @post_load
    def make(self, data: Any, **kwargs: Any) -> "ResourceRequirementsSettings":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ResourceRequirementsSettings

        return ResourceRequirementsSettings(**data)
