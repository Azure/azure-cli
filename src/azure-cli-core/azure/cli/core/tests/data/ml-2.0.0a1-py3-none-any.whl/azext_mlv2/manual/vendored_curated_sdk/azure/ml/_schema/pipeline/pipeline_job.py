# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from typing import Any, Dict
import json

from marshmallow import fields, pre_load, ValidationError
from pydash import objects
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import JobType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import ComputeBindingSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import BaseJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import InputEntrySchema, OutputEntrySchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.pipeline.component_job import ComponentJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.pipeline.defaults import PipelineJobDefaultsSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.pipeline.pipeline_job_io import PipelineJobValueInputSchema

module_logger = logging.getLogger(__name__)


class PipelineJobSchema(BaseJobSchema):
    type = StringTransformedEnum(allowed_values=[JobType.PIPELINE])
    inputs = fields.Dict(
        keys=fields.Str(),
        values=UnionField(
            [
                fields.Int(),
                NestedField(InputEntrySchema),
                fields.Str(),
                fields.Bool(),
                fields.Float(),
                NestedField(PipelineJobValueInputSchema),
            ]
        ),
    )
    outputs = fields.Dict(keys=fields.Str(), values=NestedField(OutputEntrySchema))
    jobs = fields.Dict(keys=fields.Str(), values=NestedField(ComponentJobSchema))
    compute = NestedField(ComputeBindingSchema())
    defaults = fields.Dict(
        keys=StringTransformedEnum(allowed_values=[JobType.COMPONENT]), values=NestedField(PipelineJobDefaultsSchema)
    )
