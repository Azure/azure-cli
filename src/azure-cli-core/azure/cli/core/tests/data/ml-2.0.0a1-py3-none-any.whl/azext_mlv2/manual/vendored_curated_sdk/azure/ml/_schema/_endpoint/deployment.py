# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.environment import EnvironmentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmVersionedStr, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.model import ModelSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType
from marshmallow import fields

from .code_configuration_schema import CodeConfigurationSchema

module_logger = logging.getLogger(__name__)


class DeploymentSchema(PathAwareSchema):
    id = fields.Str()
    type = fields.Str()
    tags = fields.Dict()
    properties = fields.Dict()
    model = UnionField([ArmVersionedStr(azureml_type=AzureMLResourceType.MODEL), NestedField(ModelSchema)])
    code_configuration = NestedField(CodeConfigurationSchema)
    environment = UnionField(
        [ArmVersionedStr(azureml_type=AzureMLResourceType.ENVIRONMENT), NestedField(EnvironmentSchema)]
    )
    environment_variables = fields.Dict()
