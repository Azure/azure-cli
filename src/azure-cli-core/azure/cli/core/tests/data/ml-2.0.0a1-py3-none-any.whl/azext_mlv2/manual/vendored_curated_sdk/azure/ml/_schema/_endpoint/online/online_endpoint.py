# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmStr
from marshmallow import fields, post_load, validates_schema, ValidationError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.endpoint import EndpointSchema
from .online_deployment import K8sOnlineDeploymentSchema, ManagedOnlineDeploymentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    AzureMLResourceType,
    BASE_PATH_CONTEXT_KEY,
    EndpointYamlFields,
)

module_logger = logging.getLogger(__name__)


class K8sOnlineEndpointSchema(EndpointSchema):
    deployments = fields.List(NestedField(K8sOnlineDeploymentSchema))
    provisioning_state = fields.Str(metadata={"description": "status of the deployment provisioning operation"})
    target = ArmStr(azureml_type=AzureMLResourceType.COMPUTE)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import K8sOnlineEndpoint

        if EndpointYamlFields.TYPE in data:
            data.pop(EndpointYamlFields.TYPE)

        return K8sOnlineEndpoint(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class ManagedOnlineEndpointSchema(EndpointSchema):
    deployments = fields.List(NestedField(ManagedOnlineDeploymentSchema))
    provisioning_state = fields.Str()

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ManagedOnlineEndpoint

        if EndpointYamlFields.TYPE in data:
            data.pop(EndpointYamlFields.TYPE)

        return ManagedOnlineEndpoint(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
