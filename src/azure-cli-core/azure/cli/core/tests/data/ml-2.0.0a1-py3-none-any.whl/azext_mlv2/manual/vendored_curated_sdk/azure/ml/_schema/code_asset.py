# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import uuid

from .asset import AssetSchema, AnonymousAssetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY
from marshmallow import ValidationError, fields, post_load, pre_load, pre_dump

module_logger = logging.getLogger(__name__)


class CodeAssetSchema(AssetSchema):
    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Code

        return Code(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class AnonymousCodeAssetSchema(AnonymousAssetSchema):
    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Code

        return Code(
            name=str(uuid.uuid4()), version=1, is_anonymous=True, base_path=self.context[BASE_PATH_CONTEXT_KEY], **data
        )

    @pre_dump
    def validate(self, data, **kwargs):
        # AnonymousCodeAssetSchema does not support None or arm string(fall back to ArmVersionedStr)
        if data is None or not hasattr(data, "get"):
            raise ValidationError("Code cannot be None")
        return data
