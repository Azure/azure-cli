# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities import OnlineDeployment as Deployment
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.constants import EndpointGetLogsFields
from azure.core.exceptions import ResourceNotFoundError
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._load_functions import load_online_deployment

import logging


module_logger = logging.getLogger(__name__)
module_logger.propagate = 0


def ml_online_deployment_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    endpoint_name=None,
    name=None,
    local=False,
    vscode_debug=False,
    no_wait=False,
    all_traffic=False,
    params_override=None,
    **kwargs,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []
    try:
        if name:
            params_override.append({"name": name})
        if endpoint_name:
            params_override.append({"endpoint_name": endpoint_name})
        deployment = load_online_deployment(path=file, params_override=params_override)
        try:
            ml_client.online_deployments.get(name=deployment.name, endpoint_name=endpoint_name, local=local)
        except:
            pass
        else:
            raise Exception("Deployment already exists")

        if all_traffic:
            if no_wait:
                module_logger.warning(
                    f"All traffic won't be set to deployment {deployment.name} since no_wait option was provided. You can try to set all the traffic to this deployment once its has completed."
                )
            else:
                module_logger.warning(
                    f"All traffic will be set to deployment {deployment.name} once it has been provisioned.\n"
                    + "If you interrupt this command or it times out while waiting for the provisioning, you can try to set all the traffic to this deployment later once its has been provisioned."
                )

        ml_client.begin_create_or_update(deployment, local=local, vscode_debug=vscode_debug, no_wait=no_wait)

        if all_traffic and not no_wait:
            endpoint = ml_client.online_endpoints.get(deployment.endpoint_name, local=local)
            endpoint.traffic = {deployment.name: 100}
            endpoint = ml_client.begin_create_or_update(endpoint, local=local)
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_update(
    cmd,
    resource_group_name,
    workspace_name,
    local=False,
    vscode_debug=False,
    no_wait=False,
    parameters: Dict = None,
    file=None,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        deployment = Deployment.load_from_dict(data=parameters, path=file)
        if file:
            # Check if deployment exists
            try:
                ml_client.online_deployments.get(
                    name=deployment.name, endpoint_name=deployment.endpoint_name, local=local
                )
            except Exception as err:
                if isinstance(err, ResourceNotFoundError) and err.status_code == 404:
                    raise Exception("Deployment does not exist")
        deployment = ml_client.begin_create_or_update(
            deployment, local=local, vscode_debug=vscode_debug, no_wait=no_wait
        )
        if deployment:  # TODO: https://msdata.visualstudio.com/Vienna/_workitems/edit/1252491/
            return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name, local=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        try:
            deployment = ml_client.online_deployments.get(name, endpoint_name, local)
        except Exception as err:
            if isinstance(err, ResourceNotFoundError) and err.status_code == 404:
                raise Exception("Deployment does not exist.")
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_online_deployment_show(
    cmd, resource_group_name, workspace_name, name=None, endpoint_name=None, file=None, local=False
):
    params_override = []
    if name:
        params_override.append({"name": name})

    if endpoint_name:
        params_override.append({"endpoint_name": endpoint_name})
    if file:
        deployment = load_online_deployment(path=file, params_override=params_override)._to_dict()
        return deployment
    else:
        return ml_online_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name, local)


def ml_online_deployment_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    endpoint_name,
    local: bool = False,
    no_wait=False,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        return ml_client.online_deployments.delete(name, endpoint_name, local)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_list(cmd, resource_group_name, workspace_name, endpoint_name, local: bool = False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        return list(
            map(
                lambda deployment: _dump_entity_with_warnings(deployment),
                ml_client.online_deployments.list(endpoint_name, local),
            )
        )
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_get_logs(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    endpoint_name,
    lines=EndpointGetLogsFields.LINES,
    container=None,
    local: bool = False,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        logs = ml_client.online_deployments.get_logs(name, endpoint_name, lines, container, local=local)
        print(logs.replace("\\n", "\n"))
    except Exception as err:
        log_and_raise_error(err, debug)
