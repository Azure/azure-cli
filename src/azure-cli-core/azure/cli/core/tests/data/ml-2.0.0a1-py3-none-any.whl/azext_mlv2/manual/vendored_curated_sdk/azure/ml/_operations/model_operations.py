# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Iterable

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import _check_and_upload_path
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts.constants import ASSET_PATH_ERROR, CHANGED_ASSET_PATH_MSG
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations.datastore_operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    ModelVersion,
    ModelVersionResource,
    ModelVersionResourceArmPaginatedResult,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import get_datastore_arm_id, is_ARM_id_for_resource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import _get_latest
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Model

module_logger = logging.getLogger(__name__)


class ModelOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: AzureMachineLearningWorkspaces,
        datastore_operations: DatastoreOperations,
    ):
        super(ModelOperations, self).__init__(workspace_scope)
        self._model_versions_operation = service_client.model_versions
        self._model_container_operation = service_client.model_containers
        self._datastore_operation = datastore_operations

    def create_or_update(self, model: Model) -> Model:  # TODO: Are we going to implement job_name?
        name = model.name
        version = model.version

        model = _check_and_upload_path(asset=model, asset_operations=self)

        if model.datastore and not is_ARM_id_for_resource(model.datastore):
            model._datastore = get_datastore_arm_id(model.datastore, self._workspace_scope)
        model_version_resource = model._to_rest_object()
        try:
            result = self._model_versions_operation.create_or_update(
                name=name,
                version=str(version),
                body=model_version_resource,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
            )
        except Exception as e:
            # service side raises an exception if we attempt to update an existing asset's path
            if str(e) == ASSET_PATH_ERROR:
                raise Exception(CHANGED_ASSET_PATH_MSG)
            else:
                raise e

        return Model._from_rest_object(result)

    def _get(self, name: str, version: int) -> ModelVersionResource:  # name:latest
        model_version_resource = self._model_versions_operation.get(
            name=name, version=str(version), workspace_name=self._workspace_name, **self._scope_kwargs
        )
        return model_version_resource

    def get(self, name: str, version: int = None) -> Model:
        """Returns information about the specified model asset.

        :param name: Name of the model.
        :type name: str
        :param version: Version of the model. Default is the most recently created version.
        :type version: int
        """
        if version:
            # TODO: We should consider adding an exception trigger for internal_model=None
            model_version_resource = self._get(name, version)
        else:
            model_version_resource = _get_latest(
                asset_name=name,
                version_operation=self._model_versions_operation,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
            )
        return Model._from_rest_object(model_version_resource)

    def delete(self, name: str, version: int) -> None:
        if version:
            return self._model_versions_operation.delete(
                name=name, version=str(version), workspace_name=self._workspace_name, **self._scope_kwargs
            )
        else:
            raise Exception("Deletion on the whole lineage is not supported yet.")

    def list(self, name: str = None) -> Iterable[Model]:
        if name:
            models_list = self._model_versions_operation.list(
                name=name, workspace_name=self._workspace_name, **self._scope_kwargs
            )
            return map(lambda x: Model._from_rest_object(model_rest_object=x), models_list)
        else:
            models_list = self._model_container_operation.list(
                workspace_name=self._workspace_name, **self._scope_kwargs
            )
            return map(lambda x: Model._from_container_rest_object(model_container_rest_object=x), models_list)
