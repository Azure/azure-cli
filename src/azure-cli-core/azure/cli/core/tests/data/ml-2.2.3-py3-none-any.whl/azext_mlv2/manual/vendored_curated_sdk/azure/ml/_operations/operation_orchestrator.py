# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from os import PathLike
from typing import Any, Optional, Tuple, Union
from azure.core.exceptions import ResourceNotFoundError

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import _check_and_upload_path, _check_and_upload_env_build_context
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._exception_utils import EmptyDirectoryError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Code, Model, Dataset, Environment, Data
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets.asset import Asset
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ComponentVersion
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import (
    AMLNamedArmId,
    AMLVersionedArmId,
    is_ARM_id_for_resource,
    parse_name_version,
    parse_name_label,
    get_arm_id_with_version,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._storage_utils import AzureMLDatastorePathUri
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import _resolve_label_to_asset
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._dependent_operations import OperationsContainer, OperationScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import (
    AZUREML_RESOURCE_PROVIDER,
    NAMED_RESOURCE_ID_FORMAT,
    VERSIONED_RESOURCE_ID_FORMAT,
    VERSIONED_RESOURCE_NAME,
    AzureMLResourceType,
    FILE_PREFIX,
    FOLDER_PREFIX,
    ARM_ID_PREFIX,
    HTTPS_PREFIX,
    MLFLOW_URI_REGEX_FORMAT,
    JOB_URI_REGEX_FORMAT,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import UriReference
import re

module_logger = logging.getLogger(__name__)


class OperationOrchestrator(object):
    AZUREML_TYPE_TO_ASSET_ENTITY = {
        AzureMLResourceType.MODEL: Model,
        AzureMLResourceType.CODE: Code,
        AzureMLResourceType.DATA: Data,
        AzureMLResourceType.DATASET: Dataset,
        AzureMLResourceType.ENVIRONMENT: Environment,
        AzureMLResourceType.COMPONENT: ComponentVersion,
    }

    def __init__(self, operation_container: OperationsContainer, operation_scope: OperationScope):
        self._operation_container = operation_container
        self._operation_scope = operation_scope
        self._datastore_operation = self._operation_container.all_operations[AzureMLResourceType.DATASTORE]
        self._code_assets = self._operation_container.all_operations[AzureMLResourceType.CODE]
        self._environments = self._operation_container.all_operations[AzureMLResourceType.ENVIRONMENT]
        self._model = self._operation_container.all_operations[AzureMLResourceType.MODEL]
        self._dataset = self._operation_container.all_operations[AzureMLResourceType.DATASET]
        self._data = self._operation_container.all_operations[AzureMLResourceType.DATA]
        self._component = self._operation_container.all_operations[AzureMLResourceType.COMPONENT]

    def get_asset_arm_id(
        self,
        asset: Optional[Union[str, Asset]],
        azureml_type: str,
        register_asset: bool = True,
        sub_workspace_resource: bool = True,
    ):
        """This method converts AzureML Id to ARM Id. Or if the given asset is entity object, it tries to register/upload the asset based on register_asset and aszureml_type.

        :param asset: The asset to resolve/register. It can be a ARM id or a entity's object.
        :type asset: Optional[Union[str, InternalAsset]]
        :param azureml_type: The AzureML resource type. Defined in AzureMLResourceType.
        :type azureml_type: str
        :param register_asset: flag to register the asset, defaults to True
        :type register_asset: bool, optional
        :return: The ARM Id or entity object
        :rtype: Optional[Union[str, InternalAsset]]
        """
        if asset is None or is_ARM_id_for_resource(asset, azureml_type, sub_workspace_resource):
            return asset
        if isinstance(asset, str):
            if azureml_type in AzureMLResourceType.NAMED_TYPES:
                return NAMED_RESOURCE_ID_FORMAT.format(
                    self._operation_scope.subscription_id,
                    self._operation_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    self._operation_scope.workspace_name,
                    azureml_type,
                    asset,
                )
            elif azureml_type in AzureMLResourceType.VERSIONED_TYPES:
                name, version = self._resolve_name_version_from_name_label(asset, azureml_type)
                if not version:
                    name, version = parse_name_version(asset)

                if not version:
                    raise Exception(
                        f"Failed to extract version when parsing asset {asset} of type {azureml_type} as arm id. Version must be provided."
                    )
                return VERSIONED_RESOURCE_ID_FORMAT.format(
                    self._operation_scope.subscription_id,
                    self._operation_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    self._operation_scope.workspace_name,
                    azureml_type,
                    name,
                    version,
                )
            else:
                raise Exception(f"Unsupported azureml type {azureml_type} for asset: {asset}")
        elif isinstance(asset, OperationOrchestrator.AZUREML_TYPE_TO_ASSET_ENTITY[azureml_type]):
            try:
                # TODO: once the asset redesign is finished, this logic can be replaced with unified API
                if azureml_type == AzureMLResourceType.CODE:
                    return self._get_code_asset_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.ENVIRONMENT:
                    return self._get_environment_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.MODEL:
                    return self._get_model_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.DATA:
                    return self._get_data_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.DATASET:
                    return self._get_dataset_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.COMPONENT:
                    return self._get_component_arm_id(asset)
                else:
                    raise Exception(f"Unsupported azureml type {azureml_type} for asset: {asset}")
            except EmptyDirectoryError as e:
                raise Exception(f"Error creating {azureml_type} asset : {e.message}")

    def _get_code_asset_arm_id(self, code_asset: Code, register_asset: bool = True) -> Union[Code, str]:
        try:
            self._validate_datastore_name(code_asset.path)
            if register_asset:
                code_asset = self._code_assets.create_or_update(code_asset)
                return code_asset.id
            else:
                uploaded_code_asset, _ = _check_and_upload_path(artifact=code_asset, asset_operations=self._code_assets)
                uploaded_code_asset._id = get_arm_id_with_version(
                    self._operation_scope, AzureMLResourceType.CODE, code_asset.name, code_asset.version
                )
                return uploaded_code_asset
        except Exception as e:
            raise Exception(f"Error with code: {e}")

    def _get_environment_arm_id(self, environment: Environment, register_asset: bool = True) -> Union[str, Environment]:
        if register_asset:
            env_response = self._environments.create_or_update(environment)
            return env_response.id
        else:
            environment = _check_and_upload_env_build_context(environment=environment, operations=self._environments)
            environment._id = get_arm_id_with_version(
                self._operation_scope, AzureMLResourceType.ENVIRONMENT, environment.name, environment.version
            )
            return environment

    def _get_model_arm_id(self, model: Model, register_asset: bool = True) -> Union[str, Model]:
        try:
            self._validate_datastore_name(model.path)

            if register_asset:
                return self._model.create_or_update(model).id
            else:
                uploaded_model, _ = _check_and_upload_path(artifact=model, asset_operations=self._model)
                uploaded_model._id = get_arm_id_with_version(
                    self._operation_scope, AzureMLResourceType.MODEL, model.name, model.version
                )
                return uploaded_model
        except Exception as e:
            raise Exception(f"Error with model: {e}")

    def _get_dataset_arm_id(self, data_asset: Dataset, register_asset: bool = True) -> Union[str, Dataset]:
        for path in data_asset.paths:
            self._validate_datastore_name(path)

        if register_asset:
            return self._dataset.create_or_update(data_asset).id
        else:
            data_asset, _ = _check_and_upload_path(artifact=data_asset, asset_operations=self._dataset)
            return data_asset

    def _get_data_arm_id(self, data_asset: Data, register_asset: bool = True) -> Union[str, Data]:
        self._validate_datastore_name(data_asset.path)

        if register_asset:
            return self._data.create_or_update(data_asset).id
        else:
            data_asset, _ = _check_and_upload_path(artifact=data_asset, asset_operations=self._data)
            return data_asset

    def _get_component_arm_id(self, component: ComponentVersion) -> str:
        """Register component and get arm id."""
        return component.id if component.id else self._component.create_or_update(component).id

    def _resolve_name_version_from_name_label(self, aml_id: str, azureml_type: str) -> Tuple[str, Optional[str]]:
        """Given an AzureML id of the form name@label, resolves the label to the actual ID

        :param aml_id: AzureML id of the form name@label
        :type aml_id: str
        :param azureml_type: The AzureML resource type. Defined in AzureMLResourceType.
        :type azureml_type: str
        :returns: Returns tuple (name, version) on success, (name@label, None) if resolution fails
        """
        name, label = parse_name_label(aml_id)
        if (
            azureml_type not in AzureMLResourceType.VERSIONED_TYPES
            or azureml_type == AzureMLResourceType.CODE
            or not label
        ):
            return aml_id, None

        return (
            name,
            _resolve_label_to_asset(self._operation_container.all_operations[azureml_type], name, label=label).version,
        )

    def resolve_azureml_id(self, arm_id: str = None, **kwargs) -> str:
        """Thie function converts ARM id to name or name:version AzureML id. It parses the ARM id and matches the
        subscription Id, resource group name and worksapce_name.

        TODO: It is detable whether this method should be in operation_orchestrator.

        :param arm_id: entity's ARM id, defaults to None
        :type arm_id: str, optional
        :return: AzureML id
        :rtype: str
        """

        if arm_id and isinstance(arm_id, str):
            try:
                id = AMLVersionedArmId(arm_id)
                if self._match(id):
                    return VERSIONED_RESOURCE_NAME.format(id.asset_name, id.asset_version)
            except ValueError:
                pass  # fall back to named arm id
            try:
                id = AMLNamedArmId(arm_id)
                if self._match(id):
                    return id.asset_name
            except ValueError:
                pass  # fall back to be not a ARM_id
        return arm_id

    def _match(self, id: Any) -> bool:
        return (
            id.subscription_id == self._operation_scope.subscription_id
            and id.resource_group_name == self._operation_scope.resource_group_name
            and id.workspace_name == self._operation_scope.workspace_name
        )

    def _validate_datastore_name(self, datastore_uri: Optional[Union[UriReference, str, PathLike]]) -> None:
        if datastore_uri:
            try:
                if isinstance(datastore_uri, UriReference):
                    if datastore_uri.file:
                        datastore_uri = datastore_uri.file
                    else:
                        datastore_uri = datastore_uri.folder
                elif isinstance(datastore_uri, str):
                    if datastore_uri.startswith(FILE_PREFIX):
                        datastore_uri = datastore_uri[len(FILE_PREFIX) :]
                    elif datastore_uri.startswith(FOLDER_PREFIX):
                        datastore_uri = datastore_uri[len(FOLDER_PREFIX) :]
                elif isinstance(datastore_uri, PathLike):
                    return

                if (
                    datastore_uri.startswith(HTTPS_PREFIX) and datastore_uri.count("/") == 7
                ):  # only long-form (i.e. "https://x.blob.core.windows.net/datastore/LocalUpload/guid/x/x") format includes datastore
                    datastore_name = datastore_uri.split("/")[3]
                elif datastore_uri.startswith(ARM_ID_PREFIX) and not (
                    re.match(MLFLOW_URI_REGEX_FORMAT, datastore_uri) or re.match(JOB_URI_REGEX_FORMAT, datastore_uri)
                ):
                    datastore_name = AzureMLDatastorePathUri(datastore_uri).datastore
                else:
                    # local path
                    return

                if datastore_name.startswith(ARM_ID_PREFIX):
                    datastore_name[len(ARM_ID_PREFIX) :]

                self._datastore_operation.get(datastore_name)
            except ResourceNotFoundError:
                raise Exception(f"The datastore {datastore_name} could not be found in this workspace.")
