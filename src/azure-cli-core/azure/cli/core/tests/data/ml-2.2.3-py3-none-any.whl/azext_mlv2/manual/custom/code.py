# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings


def ml_code_show(cmd, resource_group_name, workspace_name, name, version):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        code = ml_client._code.get(name=name, version=version)
        return _dump_entity_with_warnings(code)
    except Exception as err:
        log_and_raise_error(err, debug)
