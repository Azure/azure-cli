# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from marshmallow import fields, post_load

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    BanditPolicy,
    MedianStoppingPolicy,
    TruncationSelectionPolicy,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    EarlyTerminationPolicyType,
)

module_logger = logging.getLogger(__name__)


class EarlyTerminationSchema(metaclass=PatchedSchemaMeta):
    evaluation_interval = fields.Int()
    delay_evaluation = fields.Int()


class BanditPolicySchema(EarlyTerminationSchema):
    policy_type = StringTransformedEnum(
        required=True, allowed_values=EarlyTerminationPolicyType.BANDIT, casing_transform=camel_to_snake
    )
    slack_factor = fields.Float()
    slack_amount = fields.Float()

    @post_load
    def make(self, data, **kwargs):
        return BanditPolicy(**data)


class MedianStoppingPolicySchema(EarlyTerminationSchema):
    policy_type = StringTransformedEnum(
        required=True, allowed_values=EarlyTerminationPolicyType.MEDIAN_STOPPING, casing_transform=camel_to_snake
    )

    @post_load
    def make(self, data, **kwargs):
        return MedianStoppingPolicy(**data)


class TruncationSelectionPolicySchema(EarlyTerminationSchema):
    policy_type = StringTransformedEnum(
        required=True, allowed_values=EarlyTerminationPolicyType.TRUNCATION_SELECTION, casing_transform=camel_to_snake
    )
    truncation_percentage = fields.Int(required=True)
    exclude_finished_jobs = fields.Bool()

    @post_load
    def make(self, data, **kwargs):
        return TruncationSelectionPolicy(**data)
