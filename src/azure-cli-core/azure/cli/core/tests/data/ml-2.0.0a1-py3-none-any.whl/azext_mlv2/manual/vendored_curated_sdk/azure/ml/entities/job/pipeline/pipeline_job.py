# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from os import PathLike
from typing import Any, Dict, Union
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    JobBaseResource,
    PipelineJob as RestPipelineJob,
    Pipeline as RestPipeline,
    PipelineInput,
    PipelineOutput,
    InputData,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    TYPE,
    JobType,
    BASE_PATH_CONTEXT_KEY,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Job
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.pipeline.component_job import ComponentJob
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.pipeline.pipeline_job_defaults import PipelineJobDefaults
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.pipeline.pipeline_job import PipelineJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import InputOutputEntry
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.pipeline._pipeline_job_helpers import (
    to_rest_dataset_literal_inputs,
    from_rest_dataset_literal_inputs,
    to_rest_data_outputs,
    from_rest_data_outputs,
)

module_logger = logging.getLogger(__name__)


class PipelineJob(Job):
    """PipelineJob

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param type:  Type of the job, supported are 'command' and 'sweep'.
    :type type: str
    :param description: Description of the resource.
    :type description: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param base_path: TBD.
    :type base_path: str
    :param experiment_name:  Name of the experiment the job will be created under, if None is provided, job will be created under experiment 'Default'.
    :type experiment_name: str
    :param status: Status of the job.
    :type status: str
    :param creation_context: Creation metadata of the job.
    :type creation_context: SystemData
    :param interaction_endpoints: Infomation on how to interact with the job.
    :type interaction_endpoints: dict[str, JobEndpoint]
    :param compute: Compute defintion containing the compute information for the job
    :type compute: InternalComputeConfiguration
    :param inputs: Inputs to the Pipeline
    :type inputs: Dict[str, Any]
    :param jobs: Jobs to run in the pipeline
    :type jobs: Dict[str, ComponentJob]
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    def __init__(
        self,
        compute: InternalComputeConfiguration = None,
        inputs: Dict[str, Any] = None,
        jobs: Dict[str, ComponentJob] = None,
        outputs: Dict[str, InputOutputEntry] = None,
        defaults: Dict[str, PipelineJobDefaults] = None,
        **kwargs,
    ):
        kwargs[TYPE] = JobType.PIPELINE
        super().__init__(**kwargs)
        self.compute = compute
        self.inputs = dict(inputs) if inputs else {}
        self.jobs = dict(jobs) if jobs else {}
        self.outputs = dict(outputs) if outputs else {}
        self.defaults = dict(defaults) if defaults else {}

    def _to_rest_object(self) -> JobBaseResource:
        component_jobs = {job_name: job._to_rest_object() for job_name, job in self.jobs.items()}
        # Turn dataset and literal inputs into InputData
        rest_inputs = to_rest_dataset_literal_inputs(self.inputs, PipelineInput)
        rest_outputs = to_rest_data_outputs(self.outputs, PipelineOutput)
        component_job_defaults = self.defaults.get("component_job", None)
        rest_compute = None
        # TODO: Revisit this logic when multiple types of component jobs are supported
        # First assume that the default compute will be the component_job default compute
        if component_job_defaults and component_job_defaults.compute:
            rest_compute = component_job_defaults.compute.dump_to_rest()
        # If there is a compute defined in the top-level PipelineJob entity, it will override the default component_job compute
        if self.compute:
            if rest_compute:
                module_logger.info(
                    "A pipeline job compute and a default component_job compute were both provided. Proceeding with the pipeline job compute as the default compute."
                )
            rest_compute = self.compute.dump_to_rest()
        pipeline = RestPipeline(
            component_jobs=component_jobs,
            inputs=rest_inputs,
            outputs=rest_outputs,
            default_datastore_name=component_job_defaults.datastore if component_job_defaults else None,
        )
        # Current PipelineJob only supports one default compute,
        # and only component_jobs are supported.
        # Eventually, the contract will evolve to support different default compute
        pipeline_job = RestPipelineJob(
            tags=self.tags,
            description=self.description,
            properties=self.properties,
            experiment_name=self.experiment_name,
            compute=rest_compute,
            pipeline=pipeline,
        )
        rest_job = JobBaseResource(properties=pipeline_job)
        rest_job.name = self.name
        return rest_job

    @classmethod
    def _load_from_rest(cls, obj: JobBaseResource) -> "PipelineJob":
        properties: RestPipelineJob = obj.properties
        pipeline: RestPipeline = properties.pipeline
        compute = properties.compute
        compute_binding = (
            InternalComputeConfiguration(
                target=compute.target, is_local=compute.is_local, instance_count=compute.instance_count
            )
            if compute
            else None
        )
        # Workaround for BatchEndpoint as these fields are not filled in
        if pipeline:
            # Unpack the inputs
            from_rest_inputs = from_rest_dataset_literal_inputs(pipeline.inputs)
            # Unpack the outputs
            outputs = from_rest_data_outputs(pipeline.outputs)
            # Unpack the component jobs
            jobs = {job_name: ComponentJob._from_rest_object(job) for job_name, job in pipeline.component_jobs.items()}
            defaults = {}
            defaults[JobType.COMPONENT] = PipelineJobDefaults(datastore=pipeline.default_datastore_name)
        else:
            from_rest_inputs, outputs, jobs, defaults = None, None, None, None
        return PipelineJob(
            name=obj.name,
            id=obj.id,
            description=properties.description,
            tags=properties.tags,
            properties=properties.properties,
            experiment_name=properties.experiment_name,
            status=properties.status,
            creation_context=obj.system_data,
            interaction_endpoints=properties.interaction_endpoints,
            compute=compute_binding,
            inputs=from_rest_inputs,
            outputs=outputs,
            jobs=jobs,
            defaults=defaults,
        )

    def _dump_yaml(self) -> Dict:
        return PipelineJobSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    @classmethod
    def _load_from_dict(cls, data: Dict, context: Dict, additional_message: str, **kwargs) -> "PipelineJob":
        loaded_schema = load_from_dict(PipelineJobSchema, data, context, additional_message, **kwargs)
        return PipelineJob(**loaded_schema)
