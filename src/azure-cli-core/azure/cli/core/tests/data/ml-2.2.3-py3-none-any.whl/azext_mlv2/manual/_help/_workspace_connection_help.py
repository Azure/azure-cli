# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_workspace_connection_help():
    helps[
        "ml connection"
    ] = """
        type: group
        short-summary: Manage Azure ML workspace connection.
        long-summary: >
            Azure ML workspace
            connection provides a secure way to store authentication and configuration information needed to connect and
            interact with the external resources.
    """
    helps[
        "ml connection list"
    ] = """
        type: command
        short-summary: List all the workspaces connection.
        long-summary: >
            The list of connections in a workspace.
        examples:
        - name: List all connections in a workspace
          text: az ml connection list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the connections in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml connections list --query \"[].{Name:name}\"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml connection show"
    ] = """
        type: command
        short-summary: Show details of a workspace connection.
    """
    helps[
        "ml connection delete"
    ] = """
        type: command
        short-summary: Delete a workspace connection.
    """
    helps[
        "ml connection create"
    ] = """
        type: command
        short-summary: Create a workspace connection.
        long-summary: >
            Workspace connection allow to store authentication and configuration information needed to connect and interact
            with the external resources
        examples:
        - name: Create a workspace connection from a YAML specification file.
          text: az ml connection create --file connection.yml --resource-group my-resource-group
    """

    helps[
        "ml connection update"
    ] = """
        type: command
        short-summary: Update a workspace connection.
        examples:
        - name: update a workspace connection from a YAML specification file.
          text: az ml connection update --resource-group my-resource-group --name my-workspace-name --file workspace.yml
    """
