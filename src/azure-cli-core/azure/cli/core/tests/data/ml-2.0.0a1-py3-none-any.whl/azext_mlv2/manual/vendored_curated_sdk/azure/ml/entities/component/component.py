# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from os import PathLike
from pathlib import Path
from typing import Dict, Union
from abc import abstractmethod
from collections import OrderedDict
from marshmallow.exceptions import ValidationError


from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Asset
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.component.input_output import ComponentInput, ComponentOutput
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import ComponentVersionResource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    CommonYamlFields,
    ComponentType,
    BASE_PATH_CONTEXT_KEY,
    PARAMS_OVERRIDE_KEY,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml, dump_yaml_to_file
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import find_type_in_override


class Component(Asset, RestTranslatableMixin):
    """Base class for component, can't be instantiated directly.

    :param name: Name of the resource.
    :type name: str
    :param version: Version of the resource.
    :type version: int
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param type:  Type of the command, supported is 'command_component'.
    :type type: str
    :param description: Description of the resource.
    :type description: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param display_name: Display name of the component.
    :type display_name: str
    :param is_deterministic: Whether the component is deterministic.
    :type is_deterministic: bool
    :param inputs: Inputs of the component.
    :type inputs: ComponentInputs
    :param outputs: Outputs of the component.
    :type outputs: ComponentOutputs
    :param is_anonymous: If the name version are system generated (anonymous registration).
    :type is_anonymous: bool
    """

    def __init__(
        self,
        name: str = None,
        version: int = None,
        id: str = None,
        type: str = None,
        description: str = None,
        tags: Dict = None,
        properties: Dict = None,
        display_name: str = None,
        is_deterministic: bool = True,
        inputs: Dict = {},
        outputs: Dict = {},
        is_anonymous: bool = False,
        **kwargs,
    ):
        super().__init__(
            name=name, id=id, version=version, description=description, tags=tags, properties=properties, **kwargs
        )
        self._type = type
        self._display_name = display_name
        self._is_deterministic = is_deterministic
        self._inputs = {name: ComponentInput(port) for name, port in inputs.items()}
        self._outputs = {name: ComponentOutput(port) for name, port in outputs.items()}
        self._is_anonymous = is_anonymous

    @property
    def type(self) -> str:
        """Type of the component, supported is 'command_component'.

        :return: Type of the component.
        :rtype: str
        """
        return self._type

    @property
    def display_name(self) -> str:
        """Display name of the component.

        :return: Display name of the component.
        :rtype: str
        """
        return self._display_name

    @property
    def is_deterministic(self) -> bool:
        """Whether the component is deterministic.

        :return: Whether the component is deterministic
        :rtype: bool
        """
        return self._is_deterministic

    @property
    def inputs(self) -> Dict:
        """Inputs of the component.

        :return: Inputs of the component.
        :rtype: dict
        """
        return self._inputs

    @property
    def outputs(self) -> Dict:
        """Outputs of the component.

        :return: Outputs of the component.
        :rtype: dict
        """
        return self._outputs

    @property
    def is_anonymous(self) -> bool:
        """If the name version are system generated (anonymous registration).

        :return: If the component is anonymous.
        :rtype: bool
        """
        return self._is_anonymous

    def dump(self, path: Union[PathLike, str]) -> None:
        """Dump the component content into a file in yaml format.

        :param path: Path to a local file as the target, new file will be created, raises exception if the file exists.
        :type path: str
        """

        yaml_serialized = self.dump_to_dict()
        dump_yaml_to_file(path, yaml_serialized, default_flow_style=False)

    def _dump_yaml(self) -> Dict:
        return self.dump_to_dict()

    @abstractmethod
    def dump_to_dict(self) -> Dict:
        """Dump the component content into a dictionary."""
        pass

    @classmethod
    def load(
        cls,
        path: Union[PathLike, str],
        params_override: list = [],
        **kwargs,
    ) -> "component":
        """Construct a component object from a yaml file.

        :param path: Path to a local file as the source.
        :type path: str
        :param params_override: Fields to overwrite on top of the yaml file. Format is [{"field1": "value1"}, {"field2": "value2"}]
        :type params_override: list

        :return: Loaded component object.
        :rtype: component
        """

        yaml_dict = load_yaml(path)
        return cls._load(data=yaml_dict, yaml_path=path, params_override=params_override, **kwargs)

    @classmethod
    def _load(
        cls,
        data: Dict = {},
        yaml_path: Union[PathLike, str] = None,
        params_override: list = [],
        **kwargs,
    ) -> "Component":

        context = {
            BASE_PATH_CONTEXT_KEY: Path(yaml_path).parent if yaml_path else Path("./"),
            PARAMS_OVERRIDE_KEY: params_override,
        }

        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CommandComponent

        component_type = None
        type_in_override = find_type_in_override(params_override)
        # override takes the priority
        type = type_in_override or data.get(CommonYamlFields.TYPE, ComponentType.COMMAND)
        if type == ComponentType.COMMAND:
            component_type = CommandComponent
        else:
            raise Exception(f"Unsupported component type: {type}.")
        try:
            return component_type._load_from_dict(data=data, context=context, **kwargs)
        except ValidationError as e:
            raise ValidationError(
                f"Validation for {component_type.__name__} failed:\n\n "
                f"{e.normalized_messages()} \n\n If the component type is incorrect, change the 'type' property."
            )

    @classmethod
    def _from_rest_object(cls, component_rest_object: ComponentVersionResource) -> "Component":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CommandComponent

        # TODO: should be RestComponentType.CommandComponent, but it did not get generated
        if component_rest_object.properties.component.component_type == "CommandComponent":
            return CommandComponent._load_from_rest(component_rest_object)
        else:
            raise Exception(f"Unsupported component type {component_rest_object.properties.component.component_type}")

    @classmethod
    @abstractmethod
    def _load_from_dict(cls, data: Dict, context: Dict, **kwargs) -> "Component":
        pass
