# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import re
from typing import Any, Optional, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import _check_and_upload_path
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts.constants import EMPTY_DIRECTORY_ERROR
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._exception_utils import EmptyDirectoryError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Code, Model, Data, Environment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CodeConfiguration, OnlineEndpoint, Component
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import AMLNamedArmId, AMLVersionedArmId, is_ARM_id_for_resource, parse_name_version
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    AZUREML_RESOURCE_PROVIDER,
    NAMED_RESOURCE_ID_FORMAT,
    VERSIONED_RESOURCE_ID_FORMAT,
    VERSIONED_RESOURCE_NAME,
    AzureMLResourceType,
)

module_logger = logging.getLogger(__name__)


class OperationOrchestrator(object):
    AZUREML_TYPE_TO_ASSET_ENTITY = {
        AzureMLResourceType.MODEL: Model,
        AzureMLResourceType.CODE: Code,
        AzureMLResourceType.DATA: Data,
        AzureMLResourceType.ENVIRONMENT: Environment,
        AzureMLResourceType.COMPONENT: Component,
    }

    def __init__(self, operation_container: OperationsContainer, workspace_scope: WorkspaceScope):
        self._operation_container = operation_container
        self._workspace_scope = workspace_scope
        self._datastore_operation = self._operation_container.all_operations[AzureMLResourceType.DATASTORE]
        self._code_assets = self._operation_container.all_operations[AzureMLResourceType.CODE]
        self._environments = self._operation_container.all_operations[AzureMLResourceType.ENVIRONMENT]
        self._model = self._operation_container.all_operations[AzureMLResourceType.MODEL]
        self._data = self._operation_container.all_operations[AzureMLResourceType.DATA]
        self._component = self._operation_container.all_operations[AzureMLResourceType.COMPONENT]

    def get_asset_arm_id(
        self,
        asset: Optional[Union[str, Data]],
        azureml_type: str,
        register_asset: bool = True,
        sub_workspace_resource: bool = True,
    ):
        """This method converts AzureML Id to ARM Id. Or if the given asset is entity object, it tries to register/upload the asset based on register_asset and aszureml_type.

        :param asset: The asset to resolve/register. It can be a ARM id or a entity's object.
        :type asset: Optional[Union[str, InternalAsset]]
        :param azureml_type: The AzureML resource type. Defined in AzureMLResourceType.
        :type azureml_type: str
        :param register_asset: flag to register the asset, defaults to True
        :type register_asset: bool, optional
        :return: The ARM Id or entity object
        :rtype: Optional[Union[str, InternalAsset]]
        """
        if asset is None or is_ARM_id_for_resource(asset, azureml_type, sub_workspace_resource):
            return asset
        if isinstance(asset, str):
            if azureml_type in AzureMLResourceType.NAMED_TYPES:
                return NAMED_RESOURCE_ID_FORMAT.format(
                    self._workspace_scope.subscription_id,
                    self._workspace_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    self._workspace_scope.workspace_name,
                    azureml_type,
                    asset,
                )
            elif azureml_type in AzureMLResourceType.VERSIONED_TYPES:
                name, version = parse_name_version(asset)
                if not version:
                    if azureml_type == AzureMLResourceType.ENVIRONMENT:
                        return self._environments.get(asset)
                    raise Exception("Version is not provided for codes.")
                return VERSIONED_RESOURCE_ID_FORMAT.format(
                    self._workspace_scope.subscription_id,
                    self._workspace_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    self._workspace_scope.workspace_name,
                    azureml_type,
                    name,
                    version,
                )
            else:
                raise Exception(f"Unsupported azureml type {azureml_type} for asset: {asset}")
        elif isinstance(asset, OperationOrchestrator.AZUREML_TYPE_TO_ASSET_ENTITY[azureml_type]):
            try:
                # TODO: once the asset redesign is finished, this logic can be replaced with unified API
                if azureml_type == AzureMLResourceType.CODE:
                    return self._get_code_asset_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.ENVIRONMENT:
                    return self._get_environment_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.MODEL:
                    return self._get_model_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.DATA:
                    return self._get_data_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.COMPONENT:
                    return self._get_component_arm_id(asset)
                else:
                    raise Exception(f"Unsupported azureml type {azureml_type} for asset: {asset}")
            except EmptyDirectoryError as e:
                raise Exception(f"Error creating {azureml_type} asset : {e.message}")

    def _get_code_asset_arm_id(self, code_asset: Code, register_asset: bool = True) -> Union[Code, str]:
        if register_asset:
            code_asset = self._code_assets.create_or_update(code_asset)
            return code_asset.id
        else:
            uploaded_code_asset = _check_and_upload_path(asset=code_asset, asset_operations=self._code_assets)
            uploaded_code_asset.name = code_asset.name
            uploaded_code_asset.version = code_asset.version
            return uploaded_code_asset

    def _get_environment_arm_id(self, environment: Environment, register_asset: bool = True) -> Union[str, Environment]:
        if register_asset:
            env_response = self._environments.create_or_update(environment)
            return env_response.id
        else:
            return environment

    def _get_model_arm_id(self, model: Model, register_asset: bool = True) -> Union[str, Model]:
        if register_asset:
            return self._model.create_or_update(model).id
        else:
            uploaded_model = _check_and_upload_path(asset=model, asset_operations=self._model)
            uploaded_model.name = model.name
            uploaded_model.version = model.version
            return uploaded_model

    def _get_data_arm_id(self, data_asset: Data, register_asset: bool = True) -> Union[str, Data]:
        if register_asset:
            return self._data.create_or_update(data_asset).id
        else:
            data_asset = _check_and_upload_path(asset=data_asset, asset_operations=self._data)
            return data_asset

    def _get_component_arm_id(self, component: Component) -> str:
        """Register component and get arm id."""
        return self._component.create_or_update(component).id

    def resolve_AzureML_id(self, arm_id: str = None, **kwargs) -> str:
        """Thie function converts ARM id to name or name:version AzureML id. It parses the ARM id and matches the
        subscription Id, resource group name and worksapce_name.

        TODO: It is detable whether this method should be in operation_orchestrator.

        :param arm_id: entity's ARM id, defaults to None
        :type arm_id: str, optional
        :return: AzureML id
        :rtype: str
        """

        def _match(id: Any):
            return (
                id.subscription_id == self._workspace_scope.subscription_id
                and id.resource_group_name == self._workspace_scope.resource_group_name
                and id.workspace_name == self._workspace_scope.workspace_name
            )

        if arm_id and isinstance(arm_id, str):
            try:
                id = AMLVersionedArmId(arm_id)
                if _match(id):
                    return VERSIONED_RESOURCE_NAME.format(id.asset_name, id.asset_version)
            except ValueError:
                pass  # fall back to named arm id
            try:
                id = AMLNamedArmId(arm_id)
                if _match(id):
                    return id.asset_name
            except ValueError:
                pass  # fall back to be not a ARM_id
        return arm_id

    def reset_duplicate_resources(self, old_endpoint: OnlineEndpoint, new_endpoint: OnlineEndpoint) -> None:
        """Retrieves the asset_path and datastore_id from the ARM ID of existing code and model resources and updates the code and model
        of the new_endpoint deployment if they are equal"""
        for new_deployment in new_endpoint.deployments:
            old_deployment = next((d for d in old_endpoint.deployments if d.name == new_deployment.name), None)
            if old_deployment:
                if new_deployment.code_configuration and isinstance(new_deployment.code_configuration.code, Code):
                    # Update code with name and version of old deployment if the assets are the same
                    new_deployment.code_configuration.code = self._reset_duplicate_code_resource(
                        old_deployment.code_configuration.code, new_deployment.code_configuration.code
                    )
                if new_deployment.model and isinstance(new_deployment.model, Model):
                    # Update model with name and version of old deployment if the assets are the same
                    new_deployment.model = self._reset_duplicate_model_resource(
                        old_deployment.model, new_deployment.model
                    )
                if new_deployment.environment and isinstance(new_deployment.environment, Environment):
                    environment_arm_id = self.get_asset_arm_id(
                        new_deployment.environment, azureml_type=AzureMLResourceType.ENVIRONMENT, register_asset=True
                    )
                    new_deployment.environment = environment_arm_id

    def _reset_duplicate_code_resource(self, old_code_arm_id: str, new_code: Code) -> Union[str, Code]:
        code_name = re.findall(r"/codes/(.+?)/", old_code_arm_id)[0]
        code_version = re.findall(r"/versions/(.+?)$", old_code_arm_id)[0]
        old_code = self._code_assets.get(name=code_name, version=code_version)
        if old_code.datastore == new_code.datastore and old_code.path == new_code.path:
            return old_code_arm_id
        else:
            return new_code

    def _reset_duplicate_model_resource(self, old_model_arm_id: str, new_model: Model) -> Union[str, Model]:
        model_name = re.findall(r"/models/(.+?)/", old_model_arm_id)[0]
        model_version = re.findall(r"/versions/(.+?)$", old_model_arm_id)[0]
        old_model = self._model.get(name=model_name, version=model_version)
        if old_model.datastore == new_model.datastore and old_model.path == new_model.path:
            return old_model_arm_id
        else:
            return new_model
