# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


class EmptyDirectoryError(Exception):
    def __init__(self, message):
        self.message = message
        super(EmptyDirectoryError, self).__init__(self.message)
