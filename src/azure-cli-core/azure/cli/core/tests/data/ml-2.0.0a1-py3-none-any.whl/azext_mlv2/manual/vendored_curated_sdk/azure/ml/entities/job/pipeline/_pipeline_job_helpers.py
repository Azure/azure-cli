# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict, Any, Union, Tuple, List
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Data
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import InputOutputEntry
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    InputData,
    OutputData,
    ComponentJobInput,
    ComponentJobOutput,
    PipelineInput,
    PipelineOutput,
)


def to_rest_dataset_literal_inputs(
    inputs: Dict[str, Union[int, str, float, bool, InputOutputEntry]], cls: Union[ComponentJobInput, PipelineInput]
) -> Dict[str, Union[PipelineInput, ComponentJobInput]]:
    """Turns dataset and literal inputs into REST format

    :param inputs: Dictionary of dataset and literal inputs to job
    :type inputs: Dict[str, Union[int, str, float, bool, InputOutputEntry]]
    :param cls: The wrapper class for the InputData
    :type cls: Union[ComponentJobInput, PipelineJobInput]
    :return: A dictionary mapping input name to a ComponentJobInput or PipelineInput
    :rtype: Dict[str, Union[ComponentJobInput, PipelineInput]]
    """
    rest_inputs = {}
    # Pack up the inputs into REST format
    for input_name, input_value in inputs.items():
        if isinstance(input_value, InputOutputEntry):
            # If the input is a dataset input, set the mode and dataset id
            input_data = InputData(dataset_id=input_value.data, mode=input_value.mode)
        else:
            # otherwise, the input is a literal input
            input_data = InputData(value=str(input_value))
        # Pack up inputs into PipelineInputs or ComponentJobInputs depending on caller
        rest_inputs[input_name] = cls(data=input_data)
    return rest_inputs


def from_rest_dataset_literal_inputs(
    inputs: Dict[str, Union[ComponentJobInput, PipelineInput]]
) -> Dict[str, Union[int, str, float, bool, InputOutputEntry]]:
    """Turns REST dataset and literal inputs into the SDK format

    :param inputs: Dictionary mapping input name to ComponentJobInput or PipelineInput
    :type inputs: Dict[str, Union[ComponentJobInput, PipelineInput]]
    :return: A dictionary mapping input name to a literal value or InputOutputEntry
    :rtype: Dict[str, Union[int, str, float, bool, InputOutputEntry]]
    """
    from_rest_inputs = {}
    # Unpack the inputs
    for input_name, input_value in inputs.items():
        if input_value.data.dataset_id:
            # if the input is a dataset_id, unpack the dataset id and mode into InputOutputEntry
            input_data = InputOutputEntry(data=input_value.data.dataset_id, mode=input_value.data.mode)
        else:
            # otherwise, the input is a literal, so just unpack the InputData value field
            input_data = input_value.data.value
        from_rest_inputs[input_name] = input_data
    return from_rest_inputs


def to_rest_data_outputs(
    outputs: Dict[str, InputOutputEntry], cls: Union[PipelineOutput, ComponentJobOutput]
) -> Dict[str, Union[PipelineOutput, ComponentJobOutput]]:
    """Turns job outputs into REST format

    :param inputs: Dictionary of dataset and literal inputs to job
    :type inputs: Dict[str, InputOutputEntry]
    :param cls: The wrapper class for the OutputData
    :type cls: Union[ComponentJobOutput, PipelineJobOutput]
    :return: A dictionary mapping input name to a ComponentJobInput or PipelineInput
    :rtype: Dict[str, Union[ComponentJobOutput, PipelineOutput]]
    """
    rest_outputs = {}
    for input_name, input_value in outputs.items():
        data = input_value.data
        # We only populate dataset_name if the given output data is not anonymous (i.e. the data specified a name). If we don't do this, a GUID dataset name will get set
        # for every nameless output, which will flood the workspace with a lot of datasets from the job's outputs.
        output = OutputData(
            dataset_name=data.name if not data._is_anonymous else None,
            datastore=data.datastore,
            datapath=data.path,
            mode=input_value.mode,
        )
        rest_outputs[input_name] = cls(data=output)
    return rest_outputs


def from_rest_data_outputs(
    outputs: Dict[str, Union[ComponentJobOutput, PipelineOutput]]
) -> Dict[str, InputOutputEntry]:
    """Turns REST outputs into the SDK format

    :param inputs: Dictionary of dataset and literal inputs to job
    :type inputs: Dict[str, Union[ComponentJobOutput, PipelineOutput]]
    :return: A dictionary mapping input name to a ComponentJobInput or PipelineInput
    :rtype: Dict[str, InputOutputEntry]
    """

    from_rest_outputs = {}
    for input_name, input_value in outputs.items():
        rest_output_data = input_value.data

        from_rest_output_data = (
            Data(
                name=rest_output_data.dataset_name, datastore=rest_output_data.datastore, path=rest_output_data.datapath
            )
            if rest_output_data
            else Data()
        )

        # Null out the name/version of the from_rest_output_data if it was not present in rest_output_data
        # The Asset base class autogenerates the name/version of the asset if no name/version are given,
        # so we need to override that behavior here in the case of no output dataset name.
        if not rest_output_data.dataset_name:
            from_rest_output_data.name = None
            from_rest_output_data.version = None

        # tags show up in the dumped yaml dict, so null them out since they don't make sense in this context
        from_rest_output_data.tags = None

        from_rest_output = InputOutputEntry(
            data=from_rest_output_data, mode=rest_output_data.mode if rest_output_data else None
        )
        from_rest_outputs[input_name] = from_rest_output
    return from_rest_outputs


def process_sdk_component_job_io(
    io: Dict[str, Union[str, float, bool, str, InputOutputEntry]],
    io_binding_prefix_list: List[str],
    cls: Union[ComponentJobInput, ComponentJobOutput],
) -> Tuple[
    Dict[str, Union[str, float, bool, str, InputOutputEntry]], Dict[str, Union[ComponentJobInput, ComponentJobOutput]]
]:
    """Separates SDK ComponentJob inputs that are data bindings (i.e. string inputs prefixed with 'inputs.' or 'outputs.') and dataset and literal inputs/outputs

    :param io: Input or output dictionary of an SDK ComponentJob
    :type io:  Dict[str, Union[str, float, bool, str, InputOutputEntry]]
    :return: A tuple of dictionaries: One mapping inputs to REST formatted ComponentJobInput/ComponentJobOutput for data binding io.
             The other dictionary contains any IO that is not a databinding that is yet to be turned into REST form
    :rtype: Tuple[Dict[str, Union[str, float, bool, str, InputOutputEntry]], Dict[str, Union[ComponentJobInput, ComponentJobOutput]]]
    """
    rest_io = {}
    dataset_literal_io = {}
    for io_name, io_value in io.items():
        if isinstance(io_value, str) and any([io_value.startswith(item) for item in io_binding_prefix_list]):
            if cls == ComponentJobInput:
                rest_io[io_name] = cls(input_binding=io_value)
            else:
                rest_io[io_name] = cls(output_binding=io_value)
        else:
            # Collect non-input data inputs
            dataset_literal_io[io_name] = io_value
    return rest_io, dataset_literal_io


def process_rest_component_job_io(
    io: Dict[str, Union[ComponentJobInput, ComponentJobOutput]]
) -> Tuple[Dict[str, str], Dict[str, Union[str, ComponentJobInput, ComponentJobOutput]]]:
    """Separates REST ComponentJob inputs that are data bindings (i.e. string inputs prefixed with 'inputs.' or 'outputs.') and dataset and literal inputs/outputs

    :param io: Input or output dictionary of a REST ComponentJob
    :type io:  Dict[str, Union[str, float, bool, str, InputOutputEntry]]
    :return: A tuple of dictionaries: One mapping data binding inputs to their literal string value.
             The other dictionary contains any REST IO that is not a data binding that is yet to be turned into SDK form
    :rtype: Tuple[Dict[str, str], Dict[str, Union[ComponentJobInput, ComponentJobOutput]]]
    """
    from_rest_io = {}
    rest_data_literal_io = {}
    for io_name, io_value in io.items():
        io_bindng = io_value.input_binding if isinstance(io_value, ComponentJobInput) else io_value.output_binding
        if io_bindng:
            from_rest_io[io_name] = io_bindng
        else:
            rest_data_literal_io[io_name] = io_value
    return from_rest_io, rest_data_literal_io
