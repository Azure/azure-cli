# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict, List
from azure_devtools.scenario_tests import (
    RecordingProcessor,
)
from urllib.parse import urlparse
from itertools import product
import re

from azure_devtools.scenario_tests.utilities import is_text_payload

# Pop a key from a dictionary, supporting constructions such as: key.subkey
def _pop_deep_key(obj: Dict, key: str):
    keys = key.split(".", 1)
    if keys[0] in obj:
        # If not nested key, remove the key at the current level
        if len(keys) == 1:
            obj.pop(keys[0])
        # Else, a nested key, remove from one level down
        else:
            _pop_deep_key(obj[keys[0]], key=keys[1])


def _remove_filtered_fields(*yaml_objs: Dict, filter: List[str] = []):
    for yaml_obj, filter_val in product(yaml_objs, filter):
        _pop_deep_key(yaml_obj, key=filter_val)


def assert_same(*yaml_objs: Dict, filter: List[str] = []):
    if len(yaml_objs) < 2:
        raise ValueError("the length of yaml object to compare should be at least 2")

    _remove_filtered_fields(*yaml_objs, filter=filter)

    base_to_compare = yaml_objs[0]
    for obj in yaml_objs[1:]:
        assert obj == base_to_compare


class PathReplacer(RecordingProcessor):
    def __init__(self, regex_string: str, replacement: str) -> None:
        self.regex_string = regex_string
        self.replacement = replacement

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            regex = re.compile(self.regex_string)

            assert regex.search(u.path)

            u = u._replace(path=regex.sub(self.replacement, u.path))

            request.uri = u.geturl()
            return request
        except Exception:
            return request


class ResponseReplace(RecordingProcessor):
    def __init__(self) -> None:
        self.regex_string = r'/resourceGroups/[^/,?"]+'
        self.replacement = "/resourceGroups/000000000000000"

    def process_response(self, response):  # pylint: disable=no-self-use
        if is_text_payload(response) and response["body"]["string"]:
            try:
                regex = re.compile(self.regex_string)

                assert regex.search(response["body"]["string"])
                response["body"]["string"] = regex.sub(self.replacement, response["body"]["string"])
                return response
            except Exception:
                return response
        return response


class ResourceGroupReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r'/resourceGroups/[^/,?"]+', "/resourceGroups/000000000000000")


class ResourceGroupReplacer_2(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r'/resourcegroups/[^/,?"]+', "/resourcegroups/000000000000000")


class OperationStatusReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"/operationStatuses/[^/,?]+", "/operationStatuses/000000000000000")


class DeploymentNameReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"/deployments/[^/,?]+", "/deployments/deploy-0000000")


class WorkspaceNameReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"/workspaces/[^/]+", "/workspaces/000000000000000")


class DataNameReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"data/.+/versions", "data/000000000000000/versions")


class EnvironmentNameReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"environments/.+/versions", "environments/000000000000000/versions")


class ComponentNameReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"components/.+/versions", "components/000000000000000/versions")


class QueryStringParReplacer(RecordingProcessor):
    def __init__(self, parameter_name: str, replacement: str) -> None:
        self.parameter_name = parameter_name
        self.replacement = replacement

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            assert self.parameter_name in u.query
            u = u._replace(query=re.sub(self.parameter_name + r"=[^&]+", self.parameter_name + "=0000-00-00", u.query))
            request.uri = u.geturl()
            return request
        except Exception:
            return request


class CodeAssetNameReplacer(RecordingProcessor):
    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            assert "/codes/" in u.path
            u = u._replace(path=re.sub(r"/codes/[^/]+", "/codes/000000000000000", u.path))
            request.uri = u.geturl()
            return request
        except Exception:
            return request


class APIVersionReplacer(QueryStringParReplacer):
    def __init__(self) -> None:
        super().__init__("api-version", "0000-00-00")


class HeaderRemover(RecordingProcessor):
    def __init__(self, header: str) -> None:
        self.header = header

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            request.headers.pop(self.header, None)
            return request
        except Exception:
            return request

    def process_response(self, response):  # pylint: disable=no-self-use
        try:
            response["headers"].pop(self.header, None)
            return response
        except Exception:
            return response


class MD5HeaderRemover(HeaderRemover):
    def __init__(self) -> None:
        super().__init__("content-md5")


class UserAgentRemover(HeaderRemover):
    def __init__(self) -> None:
        super().__init__("user-agent")


class AzureBlobReplacer(RecordingProcessor):
    """
    Replace https://storagea5jlura67u2una.blob.core.windows.net/azureml-blobstore-09911d39-adba-4943-950e-1c1540bf2711/az-ml-artifacts/7e05d06d-2462-446d-a683-61aa383be019/python/sample1.csv
    to https://xxxxxxxxxxxxxxxxxxxxxx.blob.core.windows.net/azureml-blobstore-00000000-0000-0000-0000-000000000000/az-ml-artifacts/00000000-0000-0000-0000-00000000000/python/sample1.csv
    """

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            storage_account, *rest = u.netloc.split(".")
            assert ".".join(rest) == "blob.core.windows.net"
            empty, blobstore, container, folder, *path = u.path.split("/")
            assert container == "az-ml-artifacts"
            u = u._replace(netloc="xxxxxxxxxxxxxxxxxxxxxx." + ".".join(rest))
            u = u._replace(
                path="/".join(
                    [
                        empty,
                        "azureml-blobstore-00000000-0000-0000-0000-000000000000",
                        container,
                        "00000000-0000-0000-0000-00000000000",
                    ]
                    + path
                )
            )
            request.uri = u.geturl()
            return request
        except Exception:
            return request
