# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


import concurrent.futures
from concurrent.futures import Future
import logging
import time
from azure.mgmt.core.polling.arm_polling import ARMPolling
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import OnlineEndpointConfigurations, PollerStatus
from typing import Callable, Any, Dict, Iterable, Optional, Union


module_logger = logging.getLogger(__name__)


class AzureMLPolling(ARMPolling):
    """
    A polling class for azure machine learning
    """

    def update_status(self):
        """Update the current status of the LRO."""
        super(ARMPolling, self).update_status()
        print(".", end="", flush=True)
