# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Any, Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    ContentsType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from marshmallow import fields, post_load

from .credentials import CertificateSchema, ServicePrincipalSchema


class AzureDataLakeGen1Schema(PathAwareSchema):
    name = fields.Str()
    storage_type = StringTransformedEnum(
        allowed_values=ContentsType.AZURE_DATA_LAKE_GEN1,
        casing_transform=camel_to_snake,
        data_key="type",
        required=True,
    )
    store_name = fields.Str(required=True)
    credential = UnionField([NestedField(ServicePrincipalSchema), NestedField(CertificateSchema)], required=True)
    description = fields.Str()
    tags = fields.Dict(keys=fields.Str(), values=fields.Dict())

    @post_load
    def make(self, data: Dict[str, Any], **kwargs) -> "AzureDataLakeGen1Datastore":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import AzureDataLakeGen1Datastore

        data.pop("storage_type", None)
        return AzureDataLakeGen1Datastore(**data)
