﻿namespace ClassLibrary3
{
    public class WeatherForecastDTO
    {
        public DateTime Date { get; set; }

        public int TemperatureInCelsius { get; set; }

        public int? SummaryId { get; set; }
    }
}