# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import traceback
from typing import Dict, Union, Tuple
from os import getenv

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AZUREML_PRIVATE_FEATURES_ENV_VAR, AZUREML_CLI_SYSTEM_EXECUTED_ENV_VAR
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import ComponentContainerData
from azext_mlv2.manual.user_agent import USER_AGENT
from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Asset, Job
from .raise_error import log_and_raise_error
from azure.core.polling import LROPoller
from knack.log import get_logger
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._storage_utils import AzureMLDatastorePathUri
from azure.cli.core.commands.client_factory import get_subscription_id

module_logger = get_logger(__name__)


def _dump_entity_with_warnings(entity: "Resource") -> Dict:
    if not entity:
        return
    if isinstance(entity, LROPoller):
        return entity
    try:
        if isinstance(entity, ComponentContainerData):
            return entity.as_dict()
        return entity._to_dict()  # type: ignore
    except Exception as err:
        module_logger.warning("Failed to deserialize response: " + str(err))
        module_logger.warning(str(entity))
        module_logger.debug(traceback.format_exc())


def _is_debug_set(cli_context):
    if "--debug" in cli_context.data["safe_params"]:
        return True
    else:
        return False


def check_private_feature_enabled_and_exit():
    if not private_features_enabled():
        log_and_raise_error("Specified operation is not supported.")


def private_features_enabled():
    return getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR) in ["True", "true", True]


def get_user_agent():
    system_executed = get_cli_system_executed()
    user_agent = "{} {}".format(system_executed, USER_AGENT) if system_executed else USER_AGENT
    return user_agent


def get_cli_system_executed():
    return getenv(AZUREML_CLI_SYSTEM_EXECUTED_ENV_VAR)


def _get_ml_client(
    subscription_id,
    resource_group_name,
    workspace_name=None,
    debug=False,
    cli_ctx=None,
) -> MLClient:
    from azure.cli.core.commands.client_factory import get_mgmt_service_client

    request_id = cli_ctx.data["headers"]["x-ms-client-request-id"] if cli_ctx else None
    kwargs = {
        "user_agent": get_user_agent(),
        "logging_enable": debug,
        "request_id": request_id,
        "workspace_name": workspace_name,
        "resource_group_name": resource_group_name,
    }

    if request_id is not None:
        kwargs.update({"request_id": request_id})

    ml_client = get_mgmt_service_client(cli_ctx, MLClient._ml_client_cli, subscription_id=subscription_id, **kwargs)

    return ml_client


def get_ml_client(cli_ctx, resource_group_name: str, workspace_name: str = None) -> Tuple[MLClient, bool]:
    subscription_id = get_subscription_id(cli_ctx)
    debug = _is_debug_set(cli_ctx)
    ml_client = _get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cli_ctx,
    )
    return ml_client, debug


def reset_anonymous_asset(asset: Union[str, Asset]) -> None:
    if asset and isinstance(asset, Asset) and asset._is_anonymous:
        asset.name = None
        asset.version = None


def validate_and_split_output_path(path: str) -> AzureMLDatastorePathUri:
    if path.startswith("folder:"):
        datastore_path = AzureMLDatastorePathUri(path[7:])
        return datastore_path
    else:
        raise Exception("Not a valid output_path, it should start with  'folder:'")


def convert_str_to_dict(input_str: str) -> Dict[str, str]:
    return dict((x.strip(), y.strip()) for x, y in (ele.split("=") for ele in input_str.split(" ")))


def filter_job_tags(job: Job):
    job.tags = {k: job.tags[k] for k in job.tags if "_aml_system_" not in k and "platform_config" not in k}
    return job


# Get values from nested dictionary safely.
def deep_get(d, keys, default=None):
    """
    Example:
        d = {'meta': {'status': 'OK', 'status_code': 200}}
        deep_get(d, ['meta', 'status_code'])          # => 200
        deep_get(d, ['missingkey', 'status_code'])       # => None
        deep_get(d, ['meta', 'missingkey'], default='-') # => '-'
    """
    assert type(keys) is list
    if d is None:
        return default
    if not keys:
        return d
    return deep_get(d.get(keys[0]), keys[1:], default)
