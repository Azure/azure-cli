.. :changelog:

Release History
===============
0.1.2 (2017-06-21)
++++++++++++++++++
* No changes.

0.1.1 (2017-06-13)
++++++++++++++++++
* Remove useless line-too-long suppression
* Move all existing recording files to latest folder
* Fix various pylint disable rules

0.1.0 (2017-05-30)
++++++++++++++++++

* Initial release
