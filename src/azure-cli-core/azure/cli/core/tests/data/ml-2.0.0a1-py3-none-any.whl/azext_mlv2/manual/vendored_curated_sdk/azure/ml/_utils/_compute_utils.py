# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    ScaleSettings,
    Identity,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import to_iso_duration_format


def make_identity_and_scale_settings(
    max_instances: int,
    min_instances: int,
    idle_time_before_scale_down: int,
    identity_type: str = None,
    user_assigned_identities: str = None,
) -> ():
    if identity_type:
        if identity_type == "SystemAssigned":
            user_assigned_identities = None
        elif identity_type == "UserAssigned":
            id_dict = dict()
            for ARMid in user_assigned_identities.split(","):
                id_dict[ARMid] = {}
            user_assigned_identities = id_dict
        identity = Identity(type=identity_type, user_assigned_identities=user_assigned_identities)
    else:
        identity = None

    scale_settings = ScaleSettings(
        max_node_count=max_instances,
        min_node_count=min_instances,
        node_idle_time_before_scale_down=to_iso_duration_format(int(idle_time_before_scale_down)),
    )
    return scale_settings, identity
