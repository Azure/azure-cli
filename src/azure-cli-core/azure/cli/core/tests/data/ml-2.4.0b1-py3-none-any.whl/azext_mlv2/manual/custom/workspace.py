# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from itertools import islice
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._workspace.workspace import Workspace
from .utils import get_ml_client, _dump_entity_with_warnings
from .raise_error import log_and_raise_error
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml._version import VERSION
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._load_functions import load_workspace


def ml_workspace_list(cmd, resource_group_name=None, max_results=None):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)
    scope = "resource_group" if resource_group_name else "subscription"

    try:
        if max_results:
            results = islice(ml_client.workspaces.list(scope=scope), int(max_results))
        else:
            results = ml_client.workspaces.list(scope=scope)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_show(cmd, resource_group_name, name):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)

    try:
        ws = ml_client.workspaces.get(name)
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_listkeys(cmd, resource_group_name, name):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)

    try:
        return ml_client.workspaces.list_keys(name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_synckeys(cmd, resource_group_name, name, no_wait=False):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)

    try:
        return ml_client.workspaces.begin_sync_keys(name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_create(
    cmd,
    resource_group_name,
    name=None,
    display_name=None,
    description=None,
    tags=None,
    image_build_compute=None,
    public_network_access=None,
    application_insights=None,
    container_registry=None,
    params_override=None,
    file=None,
    no_wait=False,
    location=None,
    update_dependent_resources=False,
):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)

    params_override = params_override or []
    if name:
        params_override.append({"name": name})
    if display_name:
        params_override.append({"display_name": display_name})
    if description:
        params_override.append({"description": description})
    if tags is None:
        tags = {}
    # add tag in the workspace to indicate which cli version the workspace is created from
    if tags.get("createdByToolkit") is None:
        tags["createdByToolkit"] = "cli-v2-{}".format(VERSION)
    params_override.append({"tags": tags})
    if location:
        params_override.append({"location": location})
    if image_build_compute:
        params_override.append({"image_build_compute": image_build_compute})
    if public_network_access is not None:
        params_override.append({"public_network_access": public_network_access})
    if application_insights:
        params_override.append({"application_insights": application_insights})
    if container_registry:
        params_override.append({"container_registry": container_registry})

    try:
        workspace = load_workspace(path=file, params_override=params_override)
        ws = ml_client.workspaces.begin_create(
            workspace=workspace, update_dependent_resources=update_dependent_resources, no_wait=no_wait
        )
        return _dump_entity_with_warnings(ws) if ws else None
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_update(
    cmd,
    resource_group_name,
    name,
    display_name=None,
    image_build_compute=None,
    public_network_access=None,
    description=None,
    application_insights=None,
    container_registry=None,
    parameters: Dict = None,
    file=None,
    no_wait=False,
    update_dependent_resources=False,
):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)

    tags = parameters.pop("tags", None)
    params_override = [{k: v} for k, v in parameters.items()]
    params_override.append({"name": name})
    if display_name:
        params_override.append({"display_name": display_name})
    if image_build_compute:
        params_override.append({"image_build_compute": image_build_compute})
    if public_network_access is not None:
        params_override.append({"public_network_access": public_network_access})
    if description:
        params_override.append({"description": description})
    if application_insights:
        params_override.append({"application_insights": application_insights})
    if container_registry:
        params_override.append({"container_registry": container_registry})

    workspace = load_workspace(path=file, params_override=params_override)
    if tags is not None:
        if workspace.tags:
            workspace.tags.update(tags)
        else:
            workspace.tags = tags
    try:
        ws = ml_client.workspaces.begin_update(
            workspace, no_wait=no_wait, update_dependent_resources=update_dependent_resources
        )
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_delete(cmd, resource_group_name, name, all_resources=False, no_wait=False):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)

    try:
        return ml_client.workspaces.begin_delete(name=name, delete_dependent_resources=all_resources, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_diagnose(cmd, resource_group_name, name, no_wait=False):
    ml_client, debug = get_ml_client(cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name)

    try:
        return ml_client.workspaces.begin_diagnose(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)
