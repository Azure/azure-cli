# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from abc import abstractmethod
import logging
from typing import Any, Dict, Optional, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    CodeConfiguration as RestCodeConfiguration,
    ContainerResourceRequirements,
    IdAssetReference,
    OnlineDeployment,
    OnlineDeploymentTrackedResource,
    OnlineScaleSettings as RestScaleSettings,
    OnlineRequestSettings,
    K8SOnlineDeployment as RestK8SOnlineDeployment,
    ManagedOnlineDeployment as RestManagedOnlineDeployment,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import get_arm_id_with_version
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CodeConfiguration, Environment, Model
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint.deployment_settings import DeploymentProbeSettings, DeploymentRequestSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint.scale_settings import ScaleSettings, ManualScaleSettings, AutoScaleSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint.resource_requirements_settings import ResourceRequirementsSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import dict_eq
from .deployment import Deployment
from ._endpoint_helpers import validate_endpoint_name
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    EndpointComputeType,
)


module_logger = logging.getLogger(__name__)


class OnlineDeployment(Deployment):
    """Online endpoint deployment entity

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param name: Name of the resource.
    :type name: str
    :param type:  Type of the deployment, supported are 'K8S' and 'Managed'.
    :type type: str
    :param tags: Internal use only.
    :type tags: Dict[str, Any], optional
    :param properties: Internal use only.
    :type properties: Dict[str, Any], optional
    :param model: Model entity for the endpoint deployment, defaults to None
    :type model: Union[str, Model], optional
    :param code_configuration: defaults to None
    :type code_configuration: CodeConfiguration, optional
    :param environment: Environment entity for the endpoint deployment., defaults to None
    :type environment: Union[str, Environment], optional
    :param app_insights_enabled: defaults to False
    :type app_insights_enabled: bool, optional
    :param scale_settings: How the online deployment will scale.
    :type scale_settings: ScaleSettings, optional
    :param request_settings:defaults to RequestSettings()
    :type request_settings: DeploymentRequestSettings, optional
    :param liveness_probe: Liveness probe settings.
    :type liveness_probe: DeploymentProbeSettings, optional
    :param environment_variables: Environment variables that will be set in deployment.
    :type environment_variables: dict, optional
    """

    def __init__(
        self,
        name: str,
        id: str = None,
        base_path: Optional[str] = None,
        type: str = None,
        tags: Dict[str, Any] = None,
        properties: Dict[str, Any] = None,
        model: Union[str, "Model"] = None,
        code_configuration: CodeConfiguration = None,
        environment: Union[str, "Environment"] = None,
        app_insights_enabled: bool = False,
        scale_settings: ScaleSettings = None,
        request_settings: DeploymentRequestSettings = None,
        liveness_probe: DeploymentProbeSettings = None,
        environment_variables: Dict[str, str] = None,
    ):
        super(OnlineDeployment, self).__init__(
            base_path=base_path,
            id=id,
            name=name,
            type=type,
            tags=tags,
            properties=properties,
            model=model,
            code_configuration=code_configuration,
            environment=environment,
            environment_variables=environment_variables,
        )

        self.app_insights_enabled = app_insights_enabled
        self.scale_settings = scale_settings
        self.request_settings = request_settings
        self.liveness_probe = liveness_probe

    def _generate_dependencies(self, workspace_scope: WorkspaceScope) -> Any:

        code = None
        model = None
        environment = None

        if self.code_configuration:
            self.code_configuration._validate()
            if isinstance(self.code_configuration.code, str):
                code = RestCodeConfiguration(
                    code_id=self.code_configuration.code, scoring_script=self.code_configuration.scoring_script
                )
            else:
                code = RestCodeConfiguration(
                    code_id=get_arm_id_with_version(
                        workspace_scope,
                        "codes",
                        self.code_configuration.code.name,
                        self.code_configuration.code.version,
                    ),
                    scoring_script=self.code_configuration.scoring_script,
                )

        if self.model:
            if isinstance(self.model, str):
                model = IdAssetReference(asset_id=self.model)
            else:
                model = IdAssetReference(
                    asset_id=get_arm_id_with_version(workspace_scope, "models", self.model.name, self.model.version)
                )

        if self.environment:
            if isinstance(self.environment, str):
                environment = self.environment
            else:
                environment = get_arm_id_with_version(
                    workspace_scope, "environments", self.environment.name, self.environment.version
                )

        return code, environment, model

    @abstractmethod
    def _to_rest_online_deployments(self, workspace_scope: WorkspaceScope) -> OnlineDeploymentTrackedResource:
        pass

    @classmethod
    def _from_rest_online_deployment(self, deployment: OnlineDeploymentTrackedResource) -> OnlineDeployment:

        if deployment.properties.endpoint_compute_type == EndpointComputeType.K8_S:
            return K8sOnlineDeployment._from_rest_online_deployment(deployment)
        elif deployment.properties.endpoint_compute_type == EndpointComputeType.MANAGED:
            return ManagedOnlineDeployment._from_rest_online_deployment(deployment)
        else:
            raise Exception(f"Unsupported online endpont type {deployment.properties.type}.")

    def _validate_name(self) -> None:
        if self.name:
            validate_endpoint_name(self.name)

    def _validate_scale_settings(self) -> None:
        if self.scale_settings:
            if isinstance(self.scale_settings, ManualScaleSettings) and not self.scale_settings.instance_count:
                raise Exception("instance_count is required for manual scale settings.")
            if isinstance(self.scale_settings, ManualScaleSettings) and self.scale_settings.instance_count:
                if (
                    self.scale_settings.min_instances
                    and self.scale_settings.instance_count < self.scale_settings.min_instances
                ):
                    raise Exception("instance_count should not be less than min_instances")
                if (
                    self.scale_settings.max_instances
                    and self.scale_settings.instance_count > self.scale_settings.max_instances
                ):
                    raise Exception("instance_count should not be greater than max_instances")
            if isinstance(self.scale_settings, AutoScaleSettings):
                if not self.scale_settings.min_instances:
                    raise Exception("min_instance is required for auto scale settings.")
                if not self.scale_settings.max_instances:
                    raise Exception("max_instance is required for auto scale settings.")
            if self.scale_settings.min_instances and self.scale_settings.max_instances:
                if self.scale_settings.min_instances > self.scale_settings.max_instances:
                    raise Exception("min_instances should not be greater than max_instances.")

    def _merge_with(self, other: "OnlineDeployment") -> None:
        if other:
            if self.name != other.name:
                raise Exception(f"The deployment name: {self.name} and {other.name} are not matched when combining.")
            super()._merge_with(other)
            self.app_insights_enabled = other.app_insights_enabled or self.app_insights_enabled
            if self.scale_settings:
                self.scale_settings._merge_with(other.scale_settings)
            else:
                self.scale_settings = other.scale_settings
            if self.request_settings:
                self.request_settings._merge_with(other.request_settings)
            else:
                self.request_settings = other.request_settings
            if self.liveness_probe:
                self.liveness_probe._merge_with(other.liveness_probe)
            else:
                self.liveness_probe = other.liveness_probe


class K8sOnlineDeployment(OnlineDeployment):
    """Kubernetes Online endpoint deployment entity

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param name: Name of the resource.
    :type name: str
    :param type:  Type of the deployment, supported are 'K8S' and 'Managed'.
    :type type: str
    :param tags: Internal use only.
    :type tags: Dict[str, Any], optional
    :param properties: Internal use only.
    :type properties: Dict[str, Any], optional
    :param model: Model entity for the endpoint deployment, defaults to None
    :type model: Union[str, Model], optional
    :param code_configuration: defaults to None
    :type code_configuration: CodeConfiguration, optional
    :param environment: Environment entity for the endpoint deployment., defaults to None
    :type environment: Union[str, Environment], optional
    :param app_insights_enabled: defaults to False
    :type app_insights_enabled: bool, optional
    :param scale_settings: How the online deployment will scale.
    :type scale_settings: ScaleSettings, optional
    :param request_settings:defaults to RequestSettings()
    :type request_settings: DeploymentRequestSettings, optional
    :param liveness_probe: Liveness probe settings.
    :type liveness_probe: DeploymentProbeSettings, optional
    :param environment_variables: Environment variables that will be set in deployment.
    :type environment_variables: dict, optional
    :param resource_requirements: defaults to None
    :type resource_requirements: ResourceRequirementsSettings, optional
    """

    def __init__(
        self,
        name: str,
        base_path: Optional[str] = None,
        id: str = None,
        tags: Dict[str, Any] = None,
        properties: Dict[str, Any] = None,
        model: Union[str, "Model"] = None,
        code_configuration: CodeConfiguration = None,
        environment: Union[str, "Environment"] = None,
        app_insights_enabled: bool = False,
        scale_settings: ScaleSettings = None,
        request_settings: OnlineRequestSettings = None,
        liveness_probe: DeploymentProbeSettings = None,
        environment_variables: Dict[str, str] = None,
        resource_requirements: ResourceRequirementsSettings = None,
        **kwargs,
    ):

        super(K8sOnlineDeployment, self).__init__(
            base_path=base_path,
            id=id,
            name=name,
            type=EndpointComputeType.K8_S.value,
            tags=tags,
            properties=properties,
            model=model,
            code_configuration=code_configuration,
            environment=environment,
            environment_variables=environment_variables,
            app_insights_enabled=app_insights_enabled,
            scale_settings=scale_settings,
            request_settings=request_settings,
            liveness_probe=liveness_probe,
        )

        self.resource_requirements = resource_requirements

    def _to_rest_online_deployments(
        self, location: str, workspace_scope: WorkspaceScope
    ) -> OnlineDeploymentTrackedResource:
        self._validate()
        code, environment, model = self._generate_dependencies(workspace_scope)

        properties = RestK8SOnlineDeployment(
            code_configuration=code,
            environment_id=environment,
            model=model,
            scale_settings=self.scale_settings._to_rest_object() if self.scale_settings else None,
            properties=self.properties,
            environment_variables=self.environment_variables,
            app_insights_enabled=self.app_insights_enabled,
            request_settings=self.request_settings._to_rest_object() if self.request_settings else None,
            liveness_probe=self.liveness_probe._to_rest_object() if self.liveness_probe else None,
            container_resource_requirements=self.resource_requirements._to_rest_object()
            if self.resource_requirements
            else None,
        )
        return OnlineDeploymentTrackedResource(location=location, properties=properties, tags=self.tags)

    def _merge_with(self, other: "K8sOnlineDeployment") -> None:
        if other:
            super()._merge_with(other)
            if self.resource_requirements:
                self.resource_requirements._merge_with(other.resource_requirements)
            else:
                self.resource_requirements = other.resource_requirements

    def _validate(self) -> None:
        self._validate_name()
        super()._validate_scale_settings()
        self._validate_k8s_scale_settings()

    def _validate_k8s_scale_settings(self) -> None:
        if self.scale_settings and isinstance(self.scale_settings, ManualScaleSettings):
            if self.scale_settings.min_instances:
                raise Exception(f"K8s deployment {self.name} should not include min_instances")
            if self.scale_settings.max_instances:
                raise Exception(f"K8s deployment {self.name} should not include max_instances")

    @classmethod
    def _from_rest_online_deployment(self, resource: OnlineDeploymentTrackedResource) -> "K8sOnlineDeployment":

        deployment = resource.properties

        code_config = (
            CodeConfiguration(
                code=deployment.code_configuration.code_id,
                scoring_script=deployment.code_configuration.scoring_script,
            )
            if deployment.code_configuration
            else None
        )

        entity = K8sOnlineDeployment(
            id=resource.id,
            name=resource.name,
            tags=resource.tags,
            properties=deployment.properties,
            request_settings=DeploymentRequestSettings._from_rest_object(deployment.request_settings),
            model=deployment.model.asset_id,
            code_configuration=code_config,
            environment=deployment.environment_id,
            resource_requirements=ResourceRequirementsSettings._from_rest_object(
                deployment.container_resource_requirements
            ),
            app_insights_enabled=deployment.app_insights_enabled,
            scale_settings=ScaleSettings._from_rest_object(deployment.scale_settings),
            liveness_probe=DeploymentProbeSettings._from_rest_object(deployment.liveness_probe),
            environment_variables=deployment.environment_variables,
        )

        entity.provisioning_state = deployment.provisioning_state
        return entity

    def __eq__(self, other: "K8sOnlineDeployment") -> bool:
        if not other:
            return False
        # only compare mutable fields
        return (
            self.name.lower() == other.name.lower()
            and self.code_configuration == other.code_configuration
            and dict_eq(self.environment_variables, other.environment_variables)
            and dict_eq(self.tags, other.tags)
            and dict_eq(self.properties, other.properties)
            and (
                isinstance(self.environment, Environment)
                and isinstance(other.environment, Environment)
                or isinstance(self.environment, str)
                and isinstance(other.environment, str)
            )
            and self.environment == other.environment
            and (
                isinstance(self.model, Model)
                and isinstance(other.model, Model)
                or isinstance(self.model, str)
                and isinstance(other.model, str)
            )
            and self.model == other.model
            and self.app_insights_enabled == other.app_insights_enabled
            and self.scale_settings == other.scale_settings
            and self.request_settings == other.request_settings
            and self.liveness_probe == other.liveness_probe
            and self.resource_requirements == other.resource_requirements
        )

    def __ne__(self, other: "K8sOnlineDeployment") -> bool:
        return not self.__eq__(other)


class ManagedOnlineDeployment(OnlineDeployment):
    """Managed Online endpoint deployment entity

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param name: Name of the resource.
    :type name: str
    :param type:  Type of the deployment, supported are 'K8S' and 'Managed'.
    :type type: str
    :param tags: Internal use only.
    :type tags: Dict[str, Any], optional
    :param properties: Internal use only.
    :type properties: Dict[str, Any], optional
    :param model: Model entity for the endpoint deployment, defaults to None
    :type model: Union[str, Model], optional
    :param code_configuration: defaults to None
    :type code_configuration: CodeConfiguration, optional
    :param environment: Environment entity for the endpoint deployment., defaults to None
    :type environment: Union[str, Environment], optional
    :param app_insights_enabled: defaults to False
    :type app_insights_enabled: bool, optional
    :param scale_settings: How the online deployment will scale.
    :type scale_settings:ScaleSettings, optional
    :param request_settings:defaults to RequestSettings()
    :type request_settings: DeploymentRequestSettings, optional
    :param liveness_probe: Liveness probe settings.
    :type liveness_probe: DeploymentProbeSettings, optional
    :param environment_variables: Environment variables that will be set in deployment.
    :type environment_variables: dict, optional
    :param readiness_probe: Readiness probe settings.
    :type readiness_probe: DeploymentProbeSettings, optional
    :param instance_type: Azure compute sku.
    :type instance_type: str
    """

    def __init__(
        self,
        name: str,
        base_path: Optional[str] = None,
        id: str = None,
        tags: Dict[str, Any] = None,
        properties: Dict[str, Any] = None,
        model: Union[str, "Model"] = None,
        code_configuration: CodeConfiguration = None,
        environment: Union[str, "Environment"] = None,
        app_insights_enabled: bool = False,
        scale_settings: ScaleSettings = None,
        request_settings: DeploymentRequestSettings = None,
        liveness_probe: DeploymentProbeSettings = None,
        environment_variables: Dict[str, str] = None,
        instance_type: str = None,
        readiness_probe: DeploymentProbeSettings = None,
        **kwargs,
    ):

        super(ManagedOnlineDeployment, self).__init__(
            base_path=base_path,
            id=id,
            name=name,
            type=EndpointComputeType.MANAGED.value,
            tags=tags,
            properties=properties,
            model=model,
            code_configuration=code_configuration,
            environment=environment,
            environment_variables=environment_variables,
            app_insights_enabled=app_insights_enabled,
            scale_settings=scale_settings,
            request_settings=request_settings,
            liveness_probe=liveness_probe,
        )

        self.instance_type = instance_type
        self.readiness_probe = readiness_probe

    def _to_rest_online_deployments(
        self, location: str, workspace_scope: WorkspaceScope
    ) -> OnlineDeploymentTrackedResource:
        self._validate()
        code, environment, model = self._generate_dependencies(workspace_scope)

        properties = RestManagedOnlineDeployment(
            code_configuration=code,
            environment_id=environment,
            model=model,
            scale_settings=self.scale_settings._to_rest_object() if self.scale_settings else None,
            properties=self.properties,
            environment_variables=self.environment_variables,
            app_insights_enabled=self.app_insights_enabled,
            request_settings=self.request_settings._to_rest_object() if self.request_settings else None,
            liveness_probe=self.liveness_probe._to_rest_object() if self.liveness_probe else None,
            instance_type=self.instance_type,
            readiness_probe=self.readiness_probe._to_rest_object() if self.readiness_probe else None,
        )
        return OnlineDeploymentTrackedResource(location=location, properties=properties, tags=self.tags)

    @classmethod
    def _from_rest_online_deployment(self, resource: OnlineDeploymentTrackedResource) -> "ManagedOnlineDeployment":

        deployment = resource.properties

        code_config = (
            CodeConfiguration(
                code=deployment.code_configuration.code_id,
                scoring_script=deployment.code_configuration.scoring_script,
            )
            if deployment.code_configuration
            else None
        )

        entity = ManagedOnlineDeployment(
            id=resource.id,
            name=resource.name,
            tags=resource.tags,
            properties=deployment.properties,
            request_settings=DeploymentRequestSettings._from_rest_object(deployment.request_settings),
            model=(deployment.model.asset_id if deployment.model else None),
            code_configuration=code_config,
            environment=deployment.environment_id,
            app_insights_enabled=deployment.app_insights_enabled,
            scale_settings=ScaleSettings._from_rest_object(deployment.scale_settings),
            liveness_probe=DeploymentProbeSettings._from_rest_object(deployment.liveness_probe),
            environment_variables=deployment.environment_variables,
            readiness_probe=DeploymentProbeSettings._from_rest_object(deployment.readiness_probe),
            instance_type=deployment.instance_type,
        )

        entity.provisioning_state = deployment.provisioning_state
        return entity

    def _merge_with(self, other: "ManagedOnlineDeployment") -> None:
        if other:
            super()._merge_with(other)
            self.instance_type = other.instance_type or self.instance_type
            if self.readiness_probe:
                self.readiness_probe._merge_with(other.readiness_probe)
            else:
                self.readiness_probe = other.readiness_probe

    def _validate(self) -> None:
        self._validate_name()
        super()._validate_scale_settings()

    def __eq__(self, other: "ManagedOnlineDeployment") -> bool:
        if not other:
            return False
        # only compare mutable fields
        return (
            self.name.lower() == other.name.lower()
            and self.code_configuration == other.code_configuration
            and dict_eq(self.environment_variables, other.environment_variables)
            and dict_eq(self.tags, other.tags)
            and dict_eq(self.properties, other.properties)
            and (
                isinstance(self.environment, Environment)
                and isinstance(other.environment, Environment)
                or isinstance(self.environment, str)
                and isinstance(other.environment, str)
            )
            and self.environment == other.environment
            and (
                isinstance(self.model, Model)
                and isinstance(other.model, Model)
                or isinstance(self.model, str)
                and isinstance(other.model, str)
            )
            and self.model == other.model
            and self.app_insights_enabled == other.app_insights_enabled
            and self.scale_settings == other.scale_settings
            and self.request_settings == other.request_settings
            and self.liveness_probe == other.liveness_probe
            and self.instance_type.lower() == other.instance_type.lower()
            and self.readiness_probe == other.readiness_probe
        )

    def __ne__(self, other: "ManagedOnlineDeployment") -> bool:
        return not self.__eq__(other)
