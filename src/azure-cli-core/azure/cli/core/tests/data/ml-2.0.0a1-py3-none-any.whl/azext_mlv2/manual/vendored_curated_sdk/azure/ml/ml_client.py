# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from typing import Optional

from azure.identity import (
    AzureCliCredential,
    ChainedTokenCredential,
    ManagedIdentityCredential,
    SharedTokenCacheCredential,
    EnvironmentCredential,
    InteractiveBrowserCredential,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import MFE_BASE_URL, AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import (
    ComputeOperations,
    DatastoreOperations,
    JobOperations,
    WorkspaceOperations,
    ModelOperations,
    DataOperations,
    CodeOperations,
    EnvironmentOperations,
    ComponentOperations,
    EndpointOperations,
    _LocalEndpointHelper,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces as ServiceClient032021Preview,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces as ServiceClient092020Preview,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope, OperationsContainer
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import _get_mfe_url_override, _is_https_url

module_logger = logging.getLogger(__name__)


class MLClient(object):
    """A client class to interact with Azure ML services.

    Use this client to manage Azure ML resources, e.g. workspaces, jobs, models and so on.
    """

    def __init__(
        self,
        subscription_id: str,
        resource_group_name: str,
        default_workspace_name: str = None,
        credential: ChainedTokenCredential = None,
        **kwargs,
    ):
        """Initiate Azure ML client

        param str subscription_id: Azure subscription ID.
        param str resource_group_name: Azure resource group.
        param str default_workspace_name: Workspace to use in the client, optional for non workspace dependent operations.
        param credential ChainedTokenCredential: Credential to use for authentication, by default the client will try the common credentils in order.
        """
        self._workspace_scope = WorkspaceScope(subscription_id, resource_group_name, default_workspace_name)

        if credential:
            self._credential = credential
        else:
            self._credential = self._default_chained_credentials()

        self._operation_container = OperationsContainer()

        mfe_base_url = _get_mfe_url_override()
        self._service_client_03_2021_preview = ServiceClient032021Preview(
            subscription_id=self._workspace_scope._subscription_id, credential=self._credential, base_url=mfe_base_url
        )
        self._service_client_09_2020_preview = ServiceClient092020Preview(
            subscription_id=self._workspace_scope._subscription_id, credential=self._credential, base_url=mfe_base_url
        )

        debug = kwargs.pop("debug", False)  # pop, to make sure it does not get passed down to API
        if debug:
            self._service_client_03_2021_preview._config.logging_policy.enable_http_logger = True
            self._service_client_09_2020_preview._config.logging_policy.enable_http_logger = True

        if mfe_base_url:  # When there's a developer url overwrite
            self._rp_service_client = ServiceClient032021Preview(
                subscription_id=self._workspace_scope._subscription_id, credential=self._credential
            )
            self._workspaces = WorkspaceOperations(
                self._workspace_scope,
                self._rp_service_client,
                self._operation_container,
                self._credential,
                **kwargs,
            )
            self._compute = ComputeOperations(self._workspace_scope, self._rp_service_client, **kwargs)
            kwargs = {"enforce_https": _is_https_url(mfe_base_url)}
        else:
            self._workspaces = WorkspaceOperations(
                self._workspace_scope,
                self._service_client_03_2021_preview,
                self._operation_container,
                self._credential,
                **kwargs,
            )
            self._compute = ComputeOperations(self._workspace_scope, self._service_client_03_2021_preview, **kwargs)
        self._operation_container.add(AzureMLResourceType.WORKSPACE, self._workspaces)
        self._operation_container.add(AzureMLResourceType.COMPUTE, self._compute)

        self._datastores = DatastoreOperations(self._workspace_scope, self._service_client_03_2021_preview, **kwargs)
        self._operation_container.add(AzureMLResourceType.DATASTORE, self._datastores)
        self._models = ModelOperations(self._workspace_scope, self._service_client_03_2021_preview, self._datastores)
        self._operation_container.add(AzureMLResourceType.MODEL, self._models)
        self._local_endpoint_helper = _LocalEndpointHelper()
        self._endpoints = EndpointOperations(
            self._workspace_scope,
            self._service_client_03_2021_preview,
            self._operation_container,
            self._local_endpoint_helper,
            self._credential,
            **kwargs,
        )
        self._operation_container.add(AzureMLResourceType.ENDPOINT, self._endpoints)
        self._data = DataOperations(
            self._workspace_scope, self._service_client_03_2021_preview, self._datastores, **kwargs
        )
        self._operation_container.add(AzureMLResourceType.DATA, self._data)
        self._code = CodeOperations(
            self._workspace_scope, self._service_client_03_2021_preview, self._datastores, **kwargs
        )
        self._operation_container.add(AzureMLResourceType.CODE, self._code)
        self._environments = EnvironmentOperations(
            self._workspace_scope, self._service_client_03_2021_preview, **kwargs
        )
        self._operation_container.add(AzureMLResourceType.ENVIRONMENT, self._environments)
        self._components = ComponentOperations(
            self._workspace_scope, self._service_client_09_2020_preview, self._operation_container, **kwargs
        )
        self._operation_container.add(AzureMLResourceType.COMPONENT, self._components)
        self._jobs = JobOperations(
            self._workspace_scope,
            self._service_client_09_2020_preview,
            self._service_client_03_2021_preview,
            self._operation_container,
            self._credential,
            **kwargs,
        )
        self._operation_container.add(AzureMLResourceType.JOB, self._jobs)

    @property
    def workspaces(self) -> WorkspaceOperations:
        """A collection of workspace related operations

        :return: Workspace operations
        :rtype: WorkspaceOperations
        """
        return self._workspaces

    @property
    def jobs(self) -> JobOperations:
        """A collection of job related operations

        :return: Job operations
        :rtype: JObOperations
        """
        return self._jobs

    @property
    def compute(self) -> ComputeOperations:
        """A collection of compute related operations

        :return: Compute operations
        :rtype: ComputeOperations
        """
        return self._compute

    @property
    def models(self) -> ModelOperations:
        """A collection of model related operations

        :return: Model operations
        :rtype: ModelOperations
        """
        return self._models

    @property
    def data(self) -> DataOperations:
        """A collection of data related operations

        :return: Data operations
        :rtype: DataOperations
        """
        return self._data

    @property
    def endpoints(self) -> EndpointOperations:
        """A collection of endpoint related operations

        :return: Endpoint operations
        :rtype: EndpointOperations
        """
        return self._endpoints

    @property
    def code(self) -> CodeOperations:
        """A collection of code related operations

        :return: Code operations
        :rtype: CodeOperations
        """
        return self._code

    @property
    def datastores(self) -> DatastoreOperations:
        """A collection of datastore related operations

        :return: Datastore operations
        :rtype: DatastoreOperations
        """
        return self._datastores

    @property
    def environments(self) -> EnvironmentOperations:
        """A collection of environment related operations

        :return: Environment operations
        :rtype: EnvironmentOperations
        """
        return self._environments

    @property
    def components(self) -> ComponentOperations:
        """A collection of component related operations

        :return: Component operations
        :rtype: ComponentOperations
        """
        return self._components

    @property
    def default_workspace_name(self) -> Optional[str]:
        """The workspace where workspace dependent operations will be executed in.

        :return: Default workspace name
        :rtype: Optional[str]
        """
        return self._workspace_scope.workspace_name

    @default_workspace_name.setter
    def default_workspace_name(self, value: str) -> None:
        """Set default workspace name for the MLClient object

        :param str value: Name of the default workspace
        """
        self._workspace_scope.workspace_name = value

    def _default_chained_credentials(self) -> ChainedTokenCredential:
        managed_identity = ManagedIdentityCredential()
        azure_cli = AzureCliCredential()
        environment = EnvironmentCredential()
        shared_token_cache = SharedTokenCacheCredential()
        interactive_browser = InteractiveBrowserCredential()

        return ChainedTokenCredential(azure_cli, interactive_browser, managed_identity, environment, shared_token_cache)
