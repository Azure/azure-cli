# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from os import getenv
from typing import Dict
from itertools import islice
from webbrowser import open_new_tab

from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    AZUREML_PRIVATE_FEATURES_ENV_VAR,
    LIMITED_RESULTSET_WARNING_FORMAT,
    JobType,
)
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Job, AutoMLJob, PipelineJob
from itertools import islice
from marshmallow.utils import EXCLUDE
from .print_error import print_error_and_exit, print_warning, print_warning_with_fore_reset
from .utils import _is_debug_set, _dump_entity_with_warnings


def open_job_in_browser(job):
    try:
        studio_endpoint = None
        interaction_endpoints = job.interaction_endpoints
        if interaction_endpoints:
            studio_endpoint = interaction_endpoints.get("Studio", None)

        if studio_endpoint and studio_endpoint.endpoint:
            open_new_tab(studio_endpoint.endpoint)
        else:
            print_warning(
                "Option --web was specified, but no studio URI was found in the list of interacion endpoints."
            )

    except Exception as err:
        print_warning(err)


def ml_job_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    name=None,
    save_as=None,
    stream=False,
    web=False,
    params_override=[],
):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )

    try:
        if name is not None:
            params_override.append({"name": name})

        job = Job.load(path=file, params_override=params_override)

        original_job_name = job.name
        job = ml_client.jobs.create_or_update(job=job)
        if save_as:
            job.dump(save_as)

        if web:
            open_job_in_browser(job)

        if stream:
            ml_client.jobs.stream(name=job.name)

        # TODO: Remove this message when PipelineJob backend honors custom names
        if original_job_name != job.name and job.type == JobType.PIPELINE:
            print_warning_with_fore_reset(
                f"Custom pipeline job names are not supported yet. Please refer to the created pipeline job using the name: {job.name}"
            )

        return _dump_entity_with_warnings(job)

    except Exception as err:
        print_error_and_exit(err)


def ml_job_show(cmd, resource_group_name, workspace_name, name, web=False, include_logs=False):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        job = ml_client.jobs.get(name, include_logs)
        private_features_enabled = getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR)
        if isinstance(job, AutoMLJob) and not private_features_enabled:
            print_error_and_exit(f"Job type {type(job)} for {name} is not supported.")
        if web:
            open_job_in_browser(job)

        return _dump_entity_with_warnings(job)
    except Exception as err:
        print_error_and_exit(err, debug)


# Used only by generic update to prevent the browser from opening when reading existing job if a user specifies "web"
def _ml_job_show(cmd, resource_group_name, workspace_name, name):
    return ml_job_show(cmd, resource_group_name, workspace_name, name)


def ml_job_cancel(cmd, resource_group_name, workspace_name, name):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.jobs.cancel(name)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_job_list(cmd, resource_group_name, workspace_name, max_results=100, **kwargs):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    print_warning_with_fore_reset(str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
    try:
        ret_list = []
        private_features_enabled = getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR)
        top_n_items = islice(ml_client.jobs.list(), int(max_results))
        for job in top_n_items:
            if (isinstance(job, AutoMLJob) or isinstance(job, PipelineJob)) and not private_features_enabled:
                continue
            ret_list.append(_dump_entity_with_warnings(job))
        return ret_list
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_job_download(cmd, resource_group_name, workspace_name, name, outputs=False, download_path=None):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        if not download_path:
            download_path = cmd.cli_ctx.local_context.current_dir
        return ml_client.jobs.download(name=name, logs_only=not outputs, download_path=download_path)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_job_stream(cmd, resource_group_name, workspace_name, name):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        ml_client.jobs.stream(name=name)
    except Exception as err:
        print_error_and_exit(err, debug)


# This will only be used for generic update
def _ml_job_update(cmd, resource_group_name, workspace_name, web=False, parameters: Dict = None):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        # Set unknown to EXCLUDE so that marshmallow doesn't raise on dump only fields.
        job = Job._load(data=parameters, unknown=EXCLUDE)

        updated_job = ml_client.jobs.create_or_update(job=job)

        if web:
            open_job_in_browser(updated_job)

        return _dump_entity_with_warnings(updated_job)

    except Exception as err:
        print_error_and_exit(err, debug)
