# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict
from marshmallow.utils import EXCLUDE
from itertools import islice

from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Environment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    LIMITED_RESULTSET_WARNING_FORMAT,
)
from .print_error import print_error_and_exit, print_warning_with_fore_reset
from .utils import _is_debug_set, _dump_entity_with_warnings


def ml_environment_create(cmd, resource_group_name, workspace_name, file, name=None, version=None, params_override=[]):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    if name:
        params_override.append({"name": name})
    if version:
        params_override.append({"version": version})

    try:
        environment = Environment.load(path=file, params_override=params_override)
        environment = ml_client.environments.create_or_update(environment)
        return _dump_entity_with_warnings(environment)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_environment_show(cmd, resource_group_name, workspace_name, name, version=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        environment = ml_client.environments.get(name=name, version=version)
        return _dump_entity_with_warnings(environment)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_environment_list(cmd, resource_group_name, workspace_name, name=None, max_results=100):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    print_warning_with_fore_reset(str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
    try:
        top_n_items = islice(ml_client.environments.list(name), int(max_results))
        return list(map(lambda x: _dump_entity_with_warnings(x), top_n_items))
    except Exception as err:
        print_error_and_exit(err, debug)


def _ml_environment_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )
    try:
        # Set unknown to EXCLUDE so that marshallow doesn't raise on dump only fields.
        environment = Environment._load(data=parameters)
        updated_environment = ml_client.environments.create_or_update(environment)
        return _dump_entity_with_warnings(updated_environment)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_environment_delete(cmd, name, version, resource_group_name, workspace_name, **kwargs):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.environments.delete(name=name, version=version, **kwargs)
    except Exception as err:
        print_error_and_exit(err, debug)
