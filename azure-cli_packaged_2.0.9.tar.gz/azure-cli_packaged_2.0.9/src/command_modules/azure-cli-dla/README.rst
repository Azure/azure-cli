Microsoft Azure CLI 'data lake analytics' Command Module
========================================================

This package is for the 'data lake analytics' module.
i.e. 'az dla'


