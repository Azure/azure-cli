# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from itertools import islice

from azure.cli.core.commands.client_factory import get_subscription_id
from azure.cli.core.commands.parameters import tags_type
from azure.identity import AzureCliCredential
from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Compute
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    ComputeType,
    LIMITED_RESULTSET_WARNING_FORMAT,
)
from .print_error import print_error_and_exit, print_warning_with_fore_reset
from .utils import _dump_entity_with_warnings, _is_debug_set

UPDATE_ERROR = "Only AmlCompute cluster properties are supported, compute name {}, is {} type."
IDENTITY_ERROR = "Identity_type can only be either of 'SystemAssigned', 'UserAssigned'"


def ml_compute_list(cmd, resource_group_name, workspace_name, type=None, max_results=100):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    print_warning_with_fore_reset(str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
    try:
        top_n_items = islice(ml_client.compute.list(compute_type=type), int(max_results))
        return [_dump_entity_with_warnings(compute) for compute in top_n_items]
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_show(cmd, resource_group_name, workspace_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return _dump_entity_with_warnings(ml_client.compute.get(name=name))
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_create(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=None,
    vnet_name=None,
    subnet=None,
    admin_username=None,
    admin_password=None,
    ssh_key_value=None,
    file=None,
    size=None,
    no_wait=False,
    user_tenant_id=None,
    user_object_id=None,
    public_ip=None,
    min_instances=None,
    max_instances=None,
    idle_time_before_scale_down=None,
    description=None,
    identity_type=None,
    user_assigned_identities=None,
    priority=None,
    params_override=[],
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    if name is not None:
        params_override.append({"name": name})
    if type is not None:
        params_override.append({"type": type})
    if vnet_name is not None:
        params_override.append({"vnet_name": vnet_name})
    if subnet is not None:
        params_override.append({"subnet": subnet})
    if admin_username is not None:
        params_override.append({"admin_username": admin_username})
    if admin_password is not None:
        params_override.append({"admin_password": admin_password})
    if ssh_key_value is not None:
        params_override.append({"ssh_key_value": ssh_key_value})
    if size is not None:
        params_override.append({"size": size})
    if user_tenant_id is not None:
        params_override.append({"user_tenant_id": user_tenant_id})
    if user_object_id is not None:
        params_override.append({"user_object_id": user_object_id})
    if public_ip is not None:
        params_override.append({"enable_public_ip": public_ip})
    if min_instances is not None:
        params_override.append({"min_instances": min_instances})
    if max_instances is not None:
        params_override.append({"max_instances": max_instances})
    if idle_time_before_scale_down is not None:
        params_override.append({"idle_time_before_scale_down": idle_time_before_scale_down})
    if description is not None:
        params_override.append({"description": description})
    if identity_type is not None:
        params_override.append({"identity_type": identity_type})
    if user_assigned_identities is not None:
        params_override.append({"user_assigned_identities": user_assigned_identities})
    if priority is not None:
        params_override.append({"priority": priority})

    try:
        compute = Compute.load(path=file, params_override=params_override)
        compute = ml_client.compute.create(compute, no_wait=no_wait)
        return _dump_entity_with_warnings(compute)
    except Exception as e:
        print_error_and_exit(e, debug)


def ml_compute_delete(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.compute.delete(name=name, no_wait=no_wait)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_start(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.compute.start(name=name, no_wait=no_wait)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_stop(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.compute.stop(name=name, no_wait=no_wait)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_restart(cmd, resource_group_name, workspace_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.compute.restart(name=name)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_list_sizes(cmd, resource_group_name, workspace_name, location=None, type=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.compute.list_sizes(location=location, compute_type=type)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_list_usage(cmd, resource_group_name, workspace_name, location=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.compute.list_usage(location=location)
    except Exception as err:
        print_error_and_exit(err, debug)


def _ml_compute_update(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    max_instances=None,
    min_instances=None,
    idle_time_before_scale_down=None,
    identity_type=None,
    user_assigned_identities=None,
    parameters: Dict = None,
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    compute_type = parameters["type"]
    if not compute_type == ComputeType.AMLCOMPUTE:
        print_error_and_exit(UPDATE_ERROR.format(name, compute_type))

    try:
        compute = ml_client.compute.update(
            name=name,
            max_instances=max_instances if max_instances else parameters["max_instances"],
            min_instances=min_instances if min_instances else parameters["min_instances"],
            idle_time_before_scale_down=idle_time_before_scale_down
            if idle_time_before_scale_down
            else parameters["idle_time_before_scale_down"],
            identity_type=identity_type,
            user_assigned_identities=user_assigned_identities,
        )
        return _dump_entity_with_warnings(compute)
    except Exception as err:
        print_error_and_exit(err, debug)


def _validate_identity(identity_type):
    if identity_type:
        if identity_type not in ["SystemAssigned", "UserAssigned"]:
            raise ValueError(IDENTITY_ERROR)


def ml_compute_attach(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=None,
    resource_id=None,
    admin_username=None,
    no_wait=False,
    ssh_key_value=None,
    file=None,
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )
    params_override = []
    if name:
        params_override.append({"name": name})
    if ssh_key_value:
        params_override.append({"ssh_key_value": ssh_key_value})
    if admin_username:
        params_override.append({"admin_username": admin_username})
    if type:
        params_override.append({"type": type})
    if resource_id:
        params_override.append({"resource_id": resource_id})
    try:
        compute = Compute.load(path=file, params_override=params_override)
        return _dump_entity_with_warnings(
            ml_client.compute.create(
                compute=compute,
                no_wait=no_wait,
            )
        )
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_compute_detach(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.compute.delete(
            name=name,
            action="Detach",
            no_wait=no_wait,
        )
    except Exception as err:
        print_error_and_exit(err, debug)
