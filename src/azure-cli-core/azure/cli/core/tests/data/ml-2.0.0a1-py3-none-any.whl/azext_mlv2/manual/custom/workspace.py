# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.custom.print_error import print_error_and_exit
from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from typing import Dict
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.workspace.workspace import Workspace
from .utils import _dump_entity_with_warnings, _is_debug_set
from .print_error import print_error_and_exit


def ml_workspace_list(cmd, resource_group_name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        ws_list = ml_client.workspaces.list()
        return list(map(lambda x: _dump_entity_with_warnings(x), ws_list))
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_workspace_show(cmd, resource_group_name, workspace_name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        ws = ml_client.workspaces.get(workspace_name)
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_workspace_listkeys(cmd, resource_group_name, workspace_name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.workspaces.list_keys(name=workspace_name)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_workspace_synckeys(cmd, resource_group_name, workspace_name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.workspaces.sync_keys(name=workspace_name)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_workspace_create(cmd, resource_group_name, workspace_name=None, file=None, no_wait=False, params_override=[]):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    if workspace_name:
        params_override.append({"name": workspace_name})

    workspace = Workspace.load(path=file, params_override=params_override)
    try:
        ws = ml_client.workspaces.create(workspace=workspace, no_wait=no_wait)
        return _dump_entity_with_warnings(ws) if ws else None
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_workspace_update(cmd, resource_group_name, workspace_name=None, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        ws = ml_client.workspaces.update(
            name=workspace_name,
            tags=parameters.get("tags", None),
            description=parameters.get("description", None),
            friendly_name=parameters.get("friendly_name", None),
        )
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_workspace_delete(cmd, resource_group_name, workspace_name, all_resources=False, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.workspaces.delete(
            name=workspace_name, delete_dependent_resources=all_resources, no_wait=no_wait
        )
    except Exception as err:
        print_error_and_exit(err, debug)
