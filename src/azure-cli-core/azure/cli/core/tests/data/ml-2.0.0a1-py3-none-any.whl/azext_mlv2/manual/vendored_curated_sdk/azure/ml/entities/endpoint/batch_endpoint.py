# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    BatchDeploymentTrackedResource,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import BatchEndpoint as RestBatchEndpoint
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import BatchEndpointTrackedResource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint import BatchEndpointSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake, snake_to_camel
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY, BATCH_ENDPOINT_TYPE, TYPE

from .batch_deployment import BatchDeployment
from .endpoint import Endpoint
from ._endpoint_helpers import validate_uniqueness_of_deployment_names, validate_endpoint_name

module_logger = logging.getLogger(__name__)


class BatchEndpoint(Endpoint):
    """Batch endpoint entity.

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param auth_mode: Possible values include: "AMLToken", "Key", "AADToken", defaults to None
    :type auth_mode: str, optional
    :param description: Description of the inference endpoint, defaults to None
    :type description: str, optional
    :param location: defaults to None
    :type location: str, optional
    :param traffic:  Traffic rules on how the traffic will be routed across deployments, defaults to {}
    :type traffic: Dict[str, int], optional
    :param deployments: defaults to {}
    :type deployments: Dict[str, BatchDeployment], optional
    :param scoring_uri: URI to use to perform a prediction, readonly.
    :type scoring_uri: str, optional
    :param swagger_uri: URI to check the swagger definition of the endpoint.
    :type swagger_uri: str, optional
    """

    def __init__(
        self,
        base_path: Optional[str] = None,
        name: str = None,
        id: str = None,
        tags: Dict = None,
        properties: Dict = None,
        auth_mode: str = None,
        description: str = None,
        location: str = None,
        traffic: Dict[str, int] = None,
        deployments: List[BatchDeployment] = None,
        scoring_uri: str = None,
        swagger_uri: str = None,
        **kwargs,
    ) -> None:
        kwargs[TYPE] = BATCH_ENDPOINT_TYPE
        super(BatchEndpoint, self).__init__(
            base_path=base_path,
            name=name,
            id=id,
            tags=tags,
            properties=properties,
            auth_mode=auth_mode,
            description=description,
            location=location,
            traffic=traffic,
            scoring_uri=scoring_uri,
            swagger_uri=swagger_uri,
            **kwargs,
        )

        self.deployments = list(deployments) if deployments else []

    def _to_rest_batch_endpoint(self, location: str) -> BatchEndpointTrackedResource:
        validate_endpoint_name(self.name)
        validate_uniqueness_of_deployment_names(self.deployments)
        batch_endpoint = RestBatchEndpoint(
            description=self.description,
            auth_mode=snake_to_camel(self.auth_mode),
        )
        return BatchEndpointTrackedResource(location=location, properties=batch_endpoint)

    def _to_rest_batch_endpoint_with_traffic(self, location: str) -> BatchEndpointTrackedResource:
        validate_uniqueness_of_deployment_names(self.deployments)
        batch_endpoint = RestBatchEndpoint(
            description=self.description,
            auth_mode=snake_to_camel(self.auth_mode),
            traffic=self.traffic,
        )
        return BatchEndpointTrackedResource(location=location, properties=batch_endpoint)

    @classmethod
    def _from_rest_object(
        cls, endpoint: BatchEndpointTrackedResource, deployments: Iterable[BatchDeploymentTrackedResource]
    ) -> "BatchEndpoint":
        all_deployments: List[BatchDeployment] = []
        if deployments:
            all_deployments = [BatchDeployment._from_rest_obj(deployment) for deployment in deployments]
        obj = cls(
            id=endpoint.id,
            name=endpoint.name,
            type=BATCH_ENDPOINT_TYPE,
            tags=endpoint.tags,
            properties=endpoint.properties.properties,
            auth_mode=camel_to_snake(endpoint.properties.auth_mode),
            description=endpoint.properties.description,
            location=endpoint.location,
            traffic=endpoint.properties.traffic,
            deployments=all_deployments,
        )
        obj._scoring_uri = endpoint.properties.scoring_uri
        obj._swagger_uri = endpoint.properties.swagger_uri
        return obj

    def dump(self) -> Dict[str, Any]:
        context = {BASE_PATH_CONTEXT_KEY: Path(".").parent}
        return BatchEndpointSchema(context=context).dump(self)  # type: ignore

    def _merge_with(self, other: "BatchEndpoint") -> None:
        if other:
            super()._merge_with(other)
            for deployment in other.deployments:
                exist_deployment = next((d for d in self.deployments if d.name == deployment.name), None)
                if exist_deployment:
                    exist_deployment._merge_with(deployment)
                else:
                    self.deployments.append(deployment)
