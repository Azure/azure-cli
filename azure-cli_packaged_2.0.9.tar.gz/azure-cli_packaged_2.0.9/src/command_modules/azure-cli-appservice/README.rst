Microsoft Azure CLI 'appservice' Command Module
===============================================

This package is for the 'appservice' module.
i.e. 'az appservice'


