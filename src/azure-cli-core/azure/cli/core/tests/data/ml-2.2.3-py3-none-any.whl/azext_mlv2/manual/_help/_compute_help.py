# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_compute_help():
    helps[
        "ml compute"
    ] = """
        type: group
        short-summary: Manage Azure ML compute resources.
        long-summary: >
            Azure ML compute targets are designated compute resources where you can run your jobs for
            training or deploy your models for inference.
    """
    helps[
        "ml compute show"
    ] = """
        type: command
        short-summary: Show details for a compute target.
        examples:
        - name: Show details for a compute target
          text: az ml compute show --name nc6-cluster --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml compute update"
    ] = """
        type: command
        short-summary: Update a compute target.
        long-summary: >
            The 'tags', 'max_instances', 'min_instances', 'idle_time_before_scale_down',
            'identity_type', and 'user_assigned_identities' properties can be updated.
        examples:
        - name: Update the minimum number of nodes for an AmlCompute cluster
          text: az ml compute update --name nc6-cluster --min-instances 1 --resource-group my-resource-group --workspace-name my-workspace
        - name: Update existing tags or add new tags for an AmlCompute cluster
          text: az ml compute update --name nc6-cluster --set tags.key1=value1 tags.key2=value2 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml compute create"
    ] = """
        type: command
        short-summary: Create a compute target.
        long-summary: >
            You can create an AmlCompute cluster, which is Azure ML's managed compute infrastructure,
            or a compute instance, which is a managed cloud-based workstation.
        examples:
        - name: Create a compute target from a YAML specification file
          text: az ml compute create --file compute.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Create an AmlCompute target using command options
          text: az ml compute create --name nc6-cluster --size Standard_NC6 --min-instances 0 --max-instances 5 --type AmlCompute --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml compute delete"
    ] = """
        type: command
        short-summary: Delete a compute target.
    """
    helps[
        "ml compute list"
    ] = """
        type: command
        short-summary: List the compute targets in a workspace.
        examples:
        - name: List all the compute targets in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml compute list --query \"[].{Name:name}\"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml compute list-sizes"
    ] = """
        type: command
        short-summary: List the VM sizes available by location.
    """
    helps[
        "ml compute list-usage"
    ] = """
        type: command
        short-summary: List the available usage resources for VMs.
    """
    helps[
        "ml compute restart"
    ] = """
        type: command
        short-summary: Restart a ComputeInstance target.
        long-summary: >
            --no-wait option is recommended.
    """
    helps[
        "ml compute start"
    ] = """
        type: command
        short-summary: Start a ComputeInstance target.
        long-summary: >
            --no-wait option is recommended.
    """
    helps[
        "ml compute stop"
    ] = """
        type: command
        short-summary: Stop a ComputeInstance target.
        long-summary: >
            --no-wait option is recommended.
    """
    helps[
        "ml compute attach"
    ] = """
        type: command
        short-summary: Attach an existing compute resource to a workspace.
        long-summary: >
            Kubernetes clusters and remote VMs can be attached as compute targets.

    """
    helps[
        "ml compute detach"
    ] = """
        type: command
        short-summary: Detach a previously attached compute resource from a workspace.
    """
    helps[
        "ml compute list-nodes"
    ] = """
        type: command
        short-summary: List node details for a compute target. The only supported compute type for this command is AML compute.
        examples:
        - name: List node details for an AML compute target
          text: az ml compute list-nodes --name nc6-cluster --resource-group my-resource-group --workspace-name my-workspace
    """
