# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


import json
import logging
import requests
from docker.models.containers import Container
from pathlib import Path
from typing import Iterable

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import ONLINE_ENDPOINT_TYPE, EndpointInvokeFields, LocalEndpointConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Endpoint, OnlineEndpoint, Deployment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._local_endpoints import LocalEndpointValidator, DockerClient, DockerfileResolver, AzureMlImageContext
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._local_endpoints.errors import InvalidLocalEndpointError, LocalEndpointNotFoundError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._endpoint_utils import local_endpoint_polling_wrapper


module_logger = logging.getLogger(__name__)


class _LocalEndpointHelper(object):
    """A helper class to interact with Azure ML endpoints locally.

    Use this helper to manage Azure ML endpoints locally, e.g. create, invoke, show, list, delete.
    """

    def __init__(self):
        self._validator = LocalEndpointValidator()
        self._docker_client = DockerClient()

    def create(self, endpoint: OnlineEndpoint):
        """Create an endpoint locally using Docker.

        :param endpoint: OnlineEndpoint object with information from user yaml.
        :type endpoint: OnlineEndpoint
        """
        try:
            endpoint = self.get(endpoint_name=endpoint.name)
            module_logger.info(f"The local endpoint {endpoint.name} already exists. Try using update instead.\n")
            return endpoint
        except LocalEndpointNotFoundError:
            pass
        return self._create_or_update_endpoint(endpoint=endpoint, operation_message="Creating local deployment")

    def update(self, endpoint: OnlineEndpoint):
        """Update an endpoint locally using Docker.

        :param endpoint: OnlineEndpoint object with information from user yaml.
        :type endpoint: OnlineEndpoint
        """
        return self._create_or_update_endpoint(endpoint=endpoint, operation_message="Updating local deployment")

    def invoke(self, endpoint_name: str, data: dict, deployment_name: str = None) -> str:
        """Invoke a local endpoint.

        :param endpoint_name: Name of endpoint to invoke.
        :type endpoint_name: str
        :param data: json data to pass
        :type data: dict
        :param deployment_name: Name of specific deployment to invoke.
        :type deployment_name: (str, optional)
        :return: str
        """
        # get_scoring_uri will throw user error if there are multiple deployments and no deployment_name is specified
        scoring_uri = self._docker_client.get_scoring_uri(endpoint_name=endpoint_name, deployment_name=deployment_name)
        if scoring_uri is None:
            raise LocalEndpointNotFoundError(endpoint_name=endpoint_name, deployment_name=deployment_name)
        headers = {}
        if deployment_name is not None:
            headers[EndpointInvokeFields.MODEL_DEPLOYMENT] = deployment_name
        return requests.post(scoring_uri, json=data, headers=headers).text

    def get_deployment_logs(self, endpoint_name: str, deployment_name: str, lines: int) -> str:
        """Get logs from a local endpoint.

        :param endpoint_name: Name of endpoint to invoke.
        :type endpoint_name: str
        :param deployment_name: Name of specific deployment to invoke.
        :type deployment_name: str
        :param lines: Number of most recent lines from container logs.
        :type lines: int
        :return: str
        """
        return self._docker_client.logs(endpoint_name=endpoint_name, deployment_name=deployment_name, lines=lines)

    def get(self, endpoint_name: str) -> OnlineEndpoint:
        """Get a local endpoint.

        :param name: Name of endpoint.
        :type name: str
        :return OnlineEndpoint:
        """
        container = self._docker_client.get_endpoint_container(endpoint_name=endpoint_name, include_stopped=True)
        if container is None:
            raise LocalEndpointNotFoundError(endpoint_name=endpoint_name)
        return self._convert_container_to_endpoint(container=container)

    def list(self) -> Iterable[OnlineEndpoint]:
        """List all local endpoints."""
        containers = self._docker_client.list_containers()
        endpoints = []
        for container in containers:
            endpoints.append(self._convert_container_to_endpoint(container=container))
        return endpoints

    def delete(self, name: str, deployment_name: str = None):
        """Delete a local endpoint.

        :param name: Name of endpoint to delete.
        :type name: str
        :param deployment_name: Name of specific deployment to delete.
        :type deployment_name: str
        """
        self._docker_client.delete(endpoint_name=name, deployment_name=deployment_name)

    def _create_or_update_endpoint(
        self, endpoint: Endpoint, operation_message: str = "Creating local deployment"
    ) -> OnlineEndpoint:
        """Create or update an endpoint locally using Docker.

        :param endpoint: OnlineEndpoint object with information from user yaml.
        :type endpoint: OnlineEndpoint
        :param operation_message: Output string for operation messages.
        :type operation_message: str
        """
        if endpoint is None:
            raise InvalidLocalEndpointError(
                "The entity provided for local endpoint was null. Please provide valid entity."
            )
        if endpoint.deployments is None or len(endpoint.deployments) == 0:
            raise InvalidLocalEndpointError(
                f"The entity provided for local endpoint {endpoint.name} was invalid. Local endpoints must contain deployments."
            )
        # TODO: uncomment validation when bugs with multiple deployments per endpoint are hashed out (keeping list / show up to date and scoring_uri)
        if len(endpoint.deployments) > 1:
            raise InvalidLocalEndpointError(
                f"The entity provided for local endpoint {endpoint.name} contains more than one deployment. Only one deployment per endpoint is supported."
            )

        endpoint_metadata = json.dumps(endpoint.dump())
        for deployment in endpoint.deployments:
            local_endpoint_polling_wrapper(
                func=self._create_deployment,
                message=f"{operation_message} ({endpoint.name} / {deployment.name}) ",
                endpoint_name=endpoint.name,
                deployment=deployment,
                endpoint_metadata=endpoint_metadata,
            )
        # TODO: update logic when multiple deployments per endpoint are supported
        return self.get(endpoint_name=endpoint.name)

    def _create_deployment(self, endpoint_name: str, deployment: Deployment, endpoint_metadata: dict = None):
        """Create deployment locally using Docker.

        :param endpoint: OnlineEndpoint object with information from user yaml.
        :type endpoint: OnlineEndpoint
        :param deployment: Deployment to create
        :type deployment: Deployment entity
        :param endpoint_metadata: Endpoint metadata (json serialied Endpoint entity)
        :type endpoint_metadata: dict
        """
        deployment_name = deployment.name
        (yaml_base_image_name, yaml_dockerfile) = self._validator.get_local_environment_artifacts(
            endpoint_name=endpoint_name, deployment=deployment
        )
        yaml_env_conda_file_contents = deployment.environment.conda_file
        (yaml_code_directory_path, yaml_code_scoring_script) = self._validator.get_local_code_configuration_artifacts(
            endpoint_name=endpoint_name, deployment=deployment
        )
        yaml_model_file_path = self._validator.get_local_model_artifacts(
            endpoint_name=endpoint_name, deployment=deployment
        )
        user_environment_variables = deployment.environment_variables

        build_directory = Path(Path.home(), ".azureml", "inferencing", endpoint_name, deployment_name)
        build_directory.mkdir(parents=True, exist_ok=True)
        build_directory_path = str(build_directory.resolve())
        image_context = AzureMlImageContext(
            endpoint_name=endpoint_name,
            deployment_name=deployment_name,
            yaml_code_directory_path=yaml_code_directory_path,
            yaml_code_scoring_script_file_name=yaml_code_scoring_script,
            yaml_model_file_path=yaml_model_file_path,
        )

        if yaml_env_conda_file_contents:
            self._write_conda_file(
                conda_contents=yaml_env_conda_file_contents,
                directory_path=build_directory_path,
                conda_file_name=LocalEndpointConstants.CONDA_FILE_NAME,
            )
            dockerfile = DockerfileResolver(
                dockerfile=yaml_dockerfile,
                docker_base_image=yaml_base_image_name,
                docker_azureml_app_path=image_context.docker_azureml_app_path,
                docker_conda_file_name=LocalEndpointConstants.CONDA_FILE_NAME,
                docker_port=LocalEndpointConstants.DOCKER_PORT,
            )
        else:
            dockerfile = DockerfileResolver(
                dockerfile=yaml_dockerfile,
                docker_base_image=yaml_base_image_name,
                docker_azureml_app_path=image_context.docker_azureml_app_path,
                docker_conda_file_name=None,
                docker_port=LocalEndpointConstants.DOCKER_PORT,
            )
        dockerfile.write_file(directory_path=build_directory_path)

        # Merge AzureML environment variables and user environment variables
        environment_variables = {**image_context.environment, **user_environment_variables}
        self._docker_client.create(
            endpoint_name=endpoint_name,
            deployment_name=deployment_name,
            endpoint_metadata=endpoint_metadata,
            build_directory=build_directory_path,
            dockerfile_path=dockerfile.local_dockerfile_path,
            volumes=image_context.volumes,
            environment=environment_variables,
            azureml_port=LocalEndpointConstants.DOCKER_PORT,
        )

    def _write_conda_file(self, conda_contents: str, directory_path: str, conda_file_name: str):
        """Writes out conda file to provided directory

        :param conda_contents: contents of conda yaml file provided by user
        :type conda_contents: str
        :param directory_path: directory on user's local system to write conda file
        :type directory_path: str
        """
        conda_file_path = f"{directory_path}/{conda_file_name}"
        p = Path(conda_file_path)
        p.write_text(conda_contents)

    def _convert_container_to_endpoint(self, container: Container) -> OnlineEndpoint:
        """Converts provided Container for local deployment to OnlineEndpoint entity.

        :param container: Container for a local deployment.
        :type container: docker.models.containers.Container
        :returns OnlineEndpoint entity:
        """
        endpoint_json = self._docker_client.get_endpoint_json_from_container(container=container)
        provisioning_state = self._docker_client.get_status_from_container(container=container)
        if provisioning_state == LocalEndpointConstants.CONTAINER_EXITED:
            return self._convert_json_to_endpoint(
                endpoint_json=endpoint_json, provisioning_state=LocalEndpointConstants.ENDPOINT_STATE_FAILED
            )
        else:
            scoring_uri = self._docker_client.get_scoring_uri_from_container(container=container)
            return self._convert_json_to_endpoint(
                endpoint_json=endpoint_json,
                provisioning_state=LocalEndpointConstants.ENDPOINT_STATE_SUCCEEDED,
                scoring_uri=scoring_uri,
            )

    def _convert_json_to_endpoint(self, endpoint_json: dict, **kwargs) -> OnlineEndpoint:
        """Converts metadata json and kwargs to OnlineEndpoint entity.

        :param endpoint_json: dictionary representation of OnlineEndpoint entity.
        :type endpoint_json: dict
        :returns OnlineEndpoint entity:
        """
        params_override = []
        for k, v in kwargs.items():
            params_override.append({k: v})
        return OnlineEndpoint._load(data=endpoint_json, params_override=params_override)
