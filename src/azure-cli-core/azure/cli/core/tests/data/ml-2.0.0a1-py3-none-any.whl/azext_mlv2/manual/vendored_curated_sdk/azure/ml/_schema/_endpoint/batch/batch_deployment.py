# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from typing import Any

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.deployment import DeploymentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import ComputeBindingSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY
from marshmallow import fields, post_load

from .batch_deployment_settings import (
    BatchRetrySettingsSchema,
)

module_logger = logging.getLogger(__name__)


class BatchDeploymentSchema(DeploymentSchema):
    name = fields.Str(required=True)
    compute = NestedField(ComputeBindingSchema, required=True)
    error_threshold = fields.Int(
        metadata={
            "description": "The number of item processing failures should be ignored. If the error_threshold is reached, the job will be early terminated."
        }
    )
    retry_settings = NestedField(BatchRetrySettingsSchema)
    partition_keys = fields.List(fields.Str(), metadata={"description": "The partition strategy for the input data."})
    mini_batch_size = fields.Int()
    logging_level = fields.Str(
        metadata={
            "description": "A string of the logging level name, which is defined in 'logging'. Possible values are 'warning', 'info', and 'debug'."
        }
    )
    output_file_name = fields.Str(metadata={"description": "File name of the prediction output."})

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import BatchDeployment

        return BatchDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
