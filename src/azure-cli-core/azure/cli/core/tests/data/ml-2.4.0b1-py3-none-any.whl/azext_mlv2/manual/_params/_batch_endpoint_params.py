# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_lro_param, add_file_param
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.constants import YAMLRefDocLinks


def add_batch_endpoint_common_param(
    c,
    name_help_message="Name of the batch endpoint.",
):
    c.argument("name", options_list=["--name", "-n"], type=str, help=name_help_message)


def load_batch_endpoint_params(self):
    with self.argument_context("ml batch-endpoint create") as c:
        add_common_params(c)
        add_batch_endpoint_common_param(
            c,
        )
        add_lro_param(c)
        add_file_param(c, "batch-endpoint", YAMLRefDocLinks.BATCH_ENDPOINT)
        add_override_param(c)

    with self.argument_context("ml batch-endpoint show") as c:
        add_common_params(c)
        add_batch_endpoint_common_param(c)

    with self.argument_context("ml batch-endpoint delete") as c:
        add_common_params(c)
        add_batch_endpoint_common_param(c)
        add_lro_param(c)

    with self.argument_context("ml batch-endpoint list") as c:
        add_common_params(c)

    with self.argument_context("ml batch-endpoint update") as c:
        add_common_params(c)
        add_batch_endpoint_common_param(c)
        add_lro_param(c)
        c.argument("defaults", help="Update deployment_name inside defaults settings for endpoint invoke")
        add_file_param(c, "batch-endpoint", YAMLRefDocLinks.BATCH_ENDPOINT)

    with self.argument_context("ml batch-endpoint invoke") as c:
        add_common_params(c)
        add_batch_endpoint_common_param(c)
        add_override_param(c)
        c.argument(
            "batch_deployment_name",
            options_list=["--deployment-name", "-d"],
            help="Name of the deployment to target.",
        )
        c.argument(
            "input",
            help="Reference to input data to use for batch inferencing. It can be a path on the datastore, public URI, a registered dataset, or a local folder path.",
        )
        c.argument(
            "input_type",
            help="Type of the input, specifying whether it's a file or a folder. Use this when you are using a path on datastore or public URI. Supported values: uri_folder, uri_file.",
        )
        c.argument(
            "output_path",
            help="Path on the datastore where output files will be uploaded to.",
        )
        c.argument(
            "mini_batch_size",
            options_list=["--mini-batch-size", "-m"],
            help="Size of each mini batch that the input data will be split into for prediction.",
        )
        c.argument(
            "instance_count",
            options_list=["--instance-count", "-c"],
            help="Number of instances the prediction will run on.",
        )
        c.argument(
            "job_name",
            help="Name of the job for batch invoke.",
        )

    with self.argument_context("ml batch-endpoint list-jobs") as c:
        add_common_params(c)
        add_batch_endpoint_common_param(c)
        c.argument(
            "deployment_name", options_list=["--deployment-name", "-d"], help="Name of the deployment to target."
        )
