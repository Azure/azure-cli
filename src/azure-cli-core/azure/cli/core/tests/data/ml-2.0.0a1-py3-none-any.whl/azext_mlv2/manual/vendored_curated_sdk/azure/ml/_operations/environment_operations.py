# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from typing import Any, Iterable, List

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import ARM_ID_PREFIX
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import _WorkspaceDependentOperations, WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    EnvironmentSpecificationVersionResource,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Environment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import _get_latest

module_logger = logging.getLogger(__name__)


class EnvironmentOperations(_WorkspaceDependentOperations):
    def __init__(self, workspace_scope: WorkspaceScope, service_client: AzureMachineLearningWorkspaces, **kwargs: Any):
        super(EnvironmentOperations, self).__init__(workspace_scope)
        self._kwargs = kwargs
        self._containers_operations = service_client.environment_containers
        self._version_operations = service_client.environment_specification_versions

    def create_or_update(self, environment: Environment) -> Environment:
        """Returns created or updated environment asset.

        :param environment: Environment object
        :type environment: Environment
        :return: Created or updated Environment object
        """
        env_version_resource = environment._to_rest_object()
        env_rest_obj = self._version_operations.create_or_update(
            name=environment.name,
            version=str(environment.version),
            workspace_name=self._workspace_name,
            body=env_version_resource,
            **self._scope_kwargs,
            **self._kwargs,
        )

        return Environment._from_rest_object(env_rest_obj)

    def _get(self, name: str, version: int) -> EnvironmentSpecificationVersionResource:
        env_version_resource = self._version_operations.get(
            name=name,
            version=str(version),
            workspace_name=self._workspace_name,
            **self._scope_kwargs,
            **self._kwargs,
        )
        return env_version_resource

    def get(self, name: str, version: int = None) -> Environment:
        """Returns the specified environment asset.

        :param name: Name of the environment.
        :type name: str
        :param version: Version of the environment. Default is the most recently created version.
        :type version: int
        :return: Environment object
        """
        name = _preprocess_environment_name(name)
        if version:
            env_version_resource = self._get(name, version)
        else:
            env_version_resource = _get_latest(
                asset_name=name,
                version_operation=self._version_operations,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
            )
        return Environment._from_rest_object(env_version_resource)

    def list(self, name: str = None) -> Iterable[Environment]:
        """List all environment assets in workspace.

        :return: A Iterable of Environment objects.
        """
        if name:
            env_list = self._version_operations.list(
                name=name, workspace_name=self._workspace_name, **self._scope_kwargs, **self._kwargs
            )
            return map(lambda x: Environment._from_rest_object(env_rest_object=x), env_list)
        else:
            env_list = self._containers_operations.list(
                workspace_name=self._workspace_name, **self._scope_kwargs, **self._kwargs
            )
            return map(lambda x: Environment._from_container_rest_object(env_container_rest_object=x), env_list)

    def delete(self, name: str, version: int, **kwargs) -> None:
        """
        Delete the environment container

        :param name: Name of the environment.
        :type name: str
        :param version: Version of the environment.
        :type version: int
        """
        self._version_operations.delete(
            name=name,
            version=str(version),
            workspace_name=self._workspace_name,
            **self._scope_kwargs,
            **self._kwargs,
        )


def _preprocess_environment_name(environment_name: str) -> str:
    if environment_name.startswith(ARM_ID_PREFIX):
        return environment_name[len(ARM_ID_PREFIX) :]
    return environment_name
