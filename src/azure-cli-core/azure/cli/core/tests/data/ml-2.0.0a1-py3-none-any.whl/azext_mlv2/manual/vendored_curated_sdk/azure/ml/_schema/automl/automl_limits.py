# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import LimitSettings


class AutoMLLimitsSchema(metaclass=PatchedSchemaMeta):
    max_trials = fields.Int(data_key=AutoMLConstants.MAX_TRIALS_YAML)
    job_timeout = fields.Int(data_key=AutoMLConstants.JOB_TIMEOUT_YAML)
    job_exit_score = fields.Float()
    max_concurrent_trials = fields.Int()
    max_core_per_trials = fields.Int()
    enable_early_termination = fields.Bool()
    trial_timeout = fields.Int(data_key=AutoMLConstants.TRIAL_TIMEOUT_YAML)

    @post_load
    def make(self, data, **kwargs):
        return LimitSettings(**data)
