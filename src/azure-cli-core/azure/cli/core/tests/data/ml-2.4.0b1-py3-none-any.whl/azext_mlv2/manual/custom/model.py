# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from itertools import islice
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._assets import Model
from .raise_error import log_and_raise_error
from .utils import get_list_view_type, get_ml_client, _dump_entity_with_warnings
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._load_functions import load_model


def ml_model_create(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    version=None,
    file=None,
    path=None,
    type=None,
    description=None,
    tags=None,
    params_override=None,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    subscription_id = get_subscription_id(cmd.cli_ctx)
    params_override = params_override or []

    if name:
        params_override.append({"name": name})
    if version:
        params_override.append({"version": version})
    if path:
        params_override.append({"path": path})
    if type:
        params_override.append({"type": type})
    if description:
        params_override.append({"description": description})
    if tags:
        params_override.append({"tags": tags})

    try:
        if file:
            model = load_model(path=file, params_override=params_override)
        elif path and name:
            # no yaml, cli param specification

            model = Model(
                name=name,
                version=version,
                path=path,
                description=description,
                tags=tags,
                type=type,
            )
        else:
            raise Exception("Please provide either --file/-f  or --name/-n and --path/-p.")
        model = ml_client.create_or_update(model)
        return _dump_entity_with_warnings(model)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_model_show(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        model = ml_client.models.get(name=name, version=version, label=label)
        return _dump_entity_with_warnings(model)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_model_download(cmd, resource_group_name, workspace_name, name, version, download_path=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if not download_path:
            download_path = cmd.cli_ctx.local_context.current_dir
        ml_client.models.download(name=name, version=version, download_path=download_path)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_model_list(
    cmd, resource_group_name, workspace_name, name=None, max_results=None, include_archived=False, archived_only=False
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        list_view_type = get_list_view_type(include_archived=include_archived, archived_only=archived_only)
        if max_results:
            results = islice(
                ml_client.models.list(name=name, list_view_type=list_view_type),
                int(max_results),
            )
        else:
            results = ml_client.models.list(name=name, list_view_type=list_view_type)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_model_update(cmd, resource_group_name, workspace_name, parameters):
    # The State of Assets specifies the only difference for PrP in update is that update cannot create a new model.
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        # Set unknown to EXCLUDE so that marshmallow doesn't raise on dump only fields.
        model = Model._load(data=parameters)
        updated_model = ml_client.create_or_update(model)
        return _dump_entity_with_warnings(updated_model)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_model_archive(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, _ = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    return ml_client.models.archive(name=name, version=version, label=label)


def ml_model_restore(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, _ = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    return ml_client.models.restore(name=name, version=version, label=label)
