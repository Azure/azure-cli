# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands.parameters import resource_group_name_type, LocalContextAttribute, LocalContextAction, ALL
from ._common_params import (
    add_override_param,
    add_max_results_params,
    add_lro_param,
    add_tags_param,
    add_description_param,
    add_file_param,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.constants import YAMLRefDocLinks


def add_display_name_param(c):
    c.argument(
        "display_name",
        options_list=["--display-name"],
        help="Display name for the workspace.",
    )


def load_workspace_params(self):
    with self.argument_context("ml workspace create") as c:
        c.argument("resource_group_name", resource_group_name_type)
        add_override_param(c)
        add_lro_param(c)
        add_file_param(c, "workspace", YAMLRefDocLinks.WORKSPACE)
        # workspace create command doesn't use add_workspace_common_params() as --names doesn't tie to az defaults for the workspace create command
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the Azure ML workspace.")
        c.argument("location", options_list=["--location", "-l"], help="The location to be used for the new workspace.")
        add_description_param(c, help_message="Description of the Azure ML workspace.")
        add_display_name_param(c)
        c.argument("no_wait", help="Do not wait for workspace creation to finish.")
        add_tags_param(c)
        c.argument(
            "image_build_compute",
            options_list=["--image-build-compute", "-i"],
            help="The name of the compute target to use for building environment Docker images when the container registry is behind a VNet.",
        )
        c.argument(
            "public_network_access",
            options_list=["--public-network-access"],
            help="Allow public endpoint connectivity when a workspace is private link enabled.",
        )
        c.argument(
            "update_dependent_resources",
            options_list=["--update-dependent-resources", "-u"],
            help="Specifying --update_dependent_resources, gives your consent to update the workspace dependent resources. Updating the workspace-attached Azure Container Registry or Application Insights resource may break lineage of previous jobs, deployed inference endpoints, or your ability to rerun earlier jobs in this workspace.",
        )
        c.argument(
            "application_insights",
            options_list=[
                "--application-insights",
            ],
            help="ARM id of the application insights associated with this workspace.",
        )
        c.argument(
            "container_registry",
            options_list=["--container-registry"],
            help="ARM id of the container registry associated with this workspace.",
        )

    with self.argument_context("ml workspace list") as c:
        c.argument("resource_group_name", resource_group_name_type)
        add_max_results_params(c)

    with self.argument_context("ml workspace show") as c:
        add_workspace_common_params(c)

    with self.argument_context("ml workspace delete") as c:
        add_workspace_common_params(c)
        add_lro_param(c)
        c.argument(
            "all_resources",
            help="Delete all the dependent resources associated with the workspace (Azure Storage account, Azure Container Registry, Azure Application Insights, Azure Key Vault).",
        )

    with self.argument_context("ml workspace list-keys") as c:
        add_workspace_common_params(c)

    with self.argument_context("ml workspace sync-keys") as c:
        add_workspace_common_params(c)
        add_lro_param(c)

    with self.argument_context("ml workspace update") as c:
        add_workspace_common_params(c)
        add_override_param(c)
        add_lro_param(c)
        add_file_param(c, "workspace", YAMLRefDocLinks.WORKSPACE)
        add_description_param(c, help_message="Description of the Azure ML workspace.")
        add_display_name_param(c)
        c.argument(
            "image_build_compute",
            options_list=["--image-build-compute", "-i"],
            help="The name of the compute target to use for building environment Docker images when the container registry is behind a VNet.",
        )
        c.argument(
            "public_network_access",
            options_list=["--public-network-access"],
            help="Allow public endpoint connectivity when a workspace is private link enabled.",
        )
        c.argument(
            "update_dependent_resources",
            options_list=["--update-dependent-resources", "-u"],
            help="Specifying --update_dependent_resources, gives your consent to update the workspace dependent resources. Updating the workspace-attached Azure Container Registry or Application Insights resource may break lineage of previous jobs, deployed inference endpoints, or your ability to rerun earlier jobs in this workspace.",
        )
        c.argument(
            "application_insights",
            options_list=[
                "--application-insights",
            ],
            help="ARM id of the application insights associated with this workspace.",
        )
        c.argument(
            "container_registry",
            options_list=["--container-registry"],
            help="ARM id of the container registry associated with this workspace.",
        )

    with self.argument_context("ml workspace diagnose") as c:
        add_workspace_common_params(c)
        add_lro_param(c)


# Workspace commands' common paramaters differ from rest of the commands because it takes --name instead of --workspace-name as the workspace name.
def add_workspace_common_params(c):
    c.argument("resource_group_name", resource_group_name_type)
    c.argument(
        "name",
        options_list=["--name", "-n"],
        type=str,
        help="Name of the Azure ML workspace."
        " You can configure the default group using `az configure --defaults workspace=<name>`",
        configured_default="workspace",
        local_context_attribute=LocalContextAttribute(
            name="aml_workspace_name", actions=[LocalContextAction.SET, LocalContextAction.GET], scopes=[ALL]
        ),
    )
