# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import EndpointKeyType
import logging
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import (
    Endpoint,
    OnlineEndpoint,
)
from .raise_error import log_and_raise_error
from .utils import get_ml_client, convert_str_to_dict, _dump_entity_with_warnings

module_logger = logging.getLogger(__name__)


def ml_online_endpoint_show(cmd, resource_group_name, workspace_name, name, local: bool = False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        endpoint = ml_client.online_endpoints.get(name=name, local=local)

        return endpoint.dump()
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_online_endpoint_show(cmd, resource_group_name, workspace_name, name=None, file=None, local=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if not name:
            endpoint = OnlineEndpoint.load(path=file)
            name = endpoint.name
        return ml_client.online_endpoints.get(name=name, local=local)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_create(
    cmd,
    resource_group_name,
    workspace_name,
    auth_mode=None,
    file=None,
    name=None,
    local: bool = False,
    no_wait=False,
    params_override=None,
    **kwargs,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []
    try:
        if name:
            # MFE is case-insensitive for Name. So convert the name into lower case here.
            params_override.append({"name": name.lower()})
        if auth_mode:
            params_override.append({"auth_mode": auth_mode.lower()})

        endpoint = OnlineEndpoint.load(path=file, params_override=params_override)
        try:
            ml_client.online_endpoints.get(name=endpoint.name, local=local)
        except:
            pass
        else:
            raise Exception("Endpoint already exists")
        endpoint = ml_client.begin_create_or_update(endpoint, local=local, no_wait=no_wait)
        if isinstance(endpoint, OnlineEndpoint):
            return endpoint.dump()
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    local: bool = False,
    no_wait=False,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        if no_wait:
            module_logger.info(
                f"Delete request initiated. Status can be checked using `az ml online-endpoint show -n {name}`\n"
            )
        return ml_client.online_endpoints.begin_delete(name=name, local=local, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_get_credentials(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        return ml_client.online_endpoints.list_keys(name=name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_list(cmd, resource_group_name, workspace_name, local: bool = False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        results = ml_client.online_endpoints.list(local=local)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_update(
    cmd,
    resource_group_name,
    workspace_name,
    traffic=None,
    name=None,
    file=None,
    parameters=None,
    local=False,
    no_wait=False,
    **kwargs,
) -> None:
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        if name:
            parameters.name = name

        if file:
            loaded_endpoint = OnlineEndpoint.load(file)
            loaded_endpoint.name = parameters.name
            parameters._merge_with(loaded_endpoint)

        if traffic and isinstance(traffic, str):
            traffic = convert_str_to_dict(traffic)
            parameters.traffic = traffic

        endpoint_return = ml_client.begin_create_or_update(
            entity=parameters,
            local=local,
            no_wait=no_wait,
        )

        if isinstance(endpoint_return, Endpoint):
            return endpoint_return.dump()
        else:
            return endpoint_return

    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_invoke(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    request_file=None,
    online_deployment_name=None,
    local: bool = False,
) -> str:
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        input_data_asset = None

        kwargs = {
            "logging_enable": debug,
        }

        return ml_client.online_endpoints.invoke(
            endpoint_name=name,
            request_file=request_file,
            input_data=input_data_asset,
            deployment_name=online_deployment_name,
            local=local,
            **kwargs,
        )
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_regenerate_keys(
    cmd, resource_group_name, workspace_name, name, key_type=EndpointKeyType.PRIMARY_KEY_TYPE, no_wait: bool = False
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.online_endpoints.begin_regenerate_keys(name=name, key_type=key_type, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)
