# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from itertools import islice
from typing import Dict

from azext_mlv2.manual.custom import get_ml_client
from azext_mlv2.manual.custom.utils import _is_debug_set, _dump_entity_with_warnings
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import WorkspaceConnection

from .raise_error import log_and_raise_error


def ml_workspace_connection_show(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        ws = ml_client.connections.get(name)
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_connection_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    name=None,
    params_override=None,
):
    ml_client, debug = get_ml_client(
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        cli_ctx=cmd.cli_ctx,
    )

    params_override = params_override or []
    if name:
        params_override.append({"name": name})

    try:
        workspace_connection = WorkspaceConnection.load(path=file, params_override=params_override)
        ws = ml_client.connections.create_or_update(workspace_connection)
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_connection_delete(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.connections.delete(name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_connection_list(cmd, resource_group_name, workspace_name, connection_type=None, max_results=None):
    ml_client, debug = get_ml_client(
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        if max_results:
            results = islice(ml_client.connections.list(connection_type=connection_type), int(max_results))
        else:
            results = ml_client.connections.list(connection_type=connection_type)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_workspace_connection_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    ml_client, debug = get_ml_client(
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        # Set unknown to EXCLUDE so that marshallow doesn't raise on dump only fields.
        workspace_connection = WorkspaceConnection._load(data=parameters)
        updated_workspace_connection = ml_client.connections.create_or_update(workspace_connection)
        return _dump_entity_with_warnings(updated_workspace_connection)
    except Exception as err:
        log_and_raise_error(err, debug)
