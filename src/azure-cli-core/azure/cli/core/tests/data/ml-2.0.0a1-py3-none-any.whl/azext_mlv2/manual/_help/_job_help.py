# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_job_help():
    helps[
        "ml job"
    ] = """
        type: group
        short-summary: Manage Azure ML jobs.
        long-summary: >
            An Azure ML job executes a task against a specified compute target. You can configure jobs
            to scale out model training on Azure. Azure ML supports different job types with different
            capabilities. For example, the most basic job, a command job, executes a command in a Docker
            container and can be leveraged for single-node and distributed training. A sweep job executes
            a hyperparameter sweep over a specified search space for tuning a model's hyperparameters.


            Jobs also enable systematic tracking for your ML experimentation and workflows. Once a job is
            created, Azure ML maintains a run record for the job that includes the metadata, any metrics,
            logs, and artifacts generated during the job, code that was executed, and the Azure ML
            environment used. All of your jobs' run records can be viewed in Azure ML studio.  
    """
    helps[
        "ml job create"
    ] = """
        type: command
        short-summary: Create a job.
        long-summary: >
            To create a job, you will typically need to configure any code to be run, an environment
            encapsulating the dependencies, a compute target to execute the job on, and any additional
            job-specific settings. When a job is created, it is submitted for execution against the
            specified compute resource.
        examples:
        - name: Create a job from a YAML specification file
          text: az ml job create --file job.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Create a job from a YAML specification file and open the job's run details in the Azure ML studio portal
          text: az ml job create --file job.yml --web --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml job list"
    ] = """
        type: command
        short-summary: List jobs in a workspace.
    """
    helps[
        "ml job show"
    ] = """
        type: command
        short-summary: Show details for a job.
    """
    helps[
        "ml job download"
    ] = """
        type: command
        short-summary: Download all job-related files.
        long-summary: The files will be downloaded in a folder named after the job's name.
        examples:
        - name: Download a job's files, including outputs, to the current working directory
          text: az ml job download --name my-job --outputs --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml job stream"
    ] = """
        type: command
        short-summary: Stream job logs to the console.
    """
    helps[
        "ml job update"
    ] = """
        type: command
        short-summary: Update a job.
        long-summary: >
            Only the 'tags' and 'properties' properties can be updated.
    """
    helps[
        "ml job cancel"
    ] = """
        type: command
        short-summary: Cancel a job.
    """
