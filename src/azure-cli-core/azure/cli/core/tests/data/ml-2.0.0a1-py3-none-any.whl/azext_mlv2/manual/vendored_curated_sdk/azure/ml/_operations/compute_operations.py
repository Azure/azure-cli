# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Union

from azure.core.exceptions import HttpResponseError
from azure.core.polling import LROPoller
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    ClusterUpdateParameters,
    ComputeResource,
    PaginatedComputeResourcesList,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._utils.utils import get_subnet_str, validate_arm_str
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute.compute import ComputeSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._compute_utils import make_identity_and_scale_settings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import ComputeType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Compute

module_logger = logging.getLogger(__name__)


class ComputeOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: AzureMachineLearningWorkspaces,
        **kwargs: Dict,
    ):
        super(ComputeOperations, self).__init__(workspace_scope)
        self._operation = service_client.machine_learning_compute
        self._workspace_operations = service_client.workspaces
        self._vmsize_operations = service_client.virtual_machine_sizes
        self._usage_operations = service_client.usages

    def list(self, compute_type: str = ComputeType.AMLCOMPUTE) -> Iterable[Compute]:
        """List computes of the workspace

        :param compute_type: the type of the compute to be listed, defaults to amlcompute
        :type compute_type: str
        :return: an iterator compute
        :rtype: Iterable[Compute]
        """
        return {Compute._from_rest_object(obj) for obj in self._list(compute_type=compute_type)}

    def _list(self, compute_type: str = None) -> Iterable[PaginatedComputeResourcesList]:
        comp_list = self._operation.list_by_workspace(self._workspace_scope.resource_group_name, self._workspace_name)
        if compute_type:
            return [item for item in comp_list if compute_type.lower() == item.properties.compute_type.lower()]
        else:
            return comp_list

    def get(self, name: str) -> Compute:
        """Get a compute resource

        :param name: Name of the compute
        :type name: str
        :return: Compute object
        :rtype: Compute
        """
        rest_obj = self._operation.get(self._workspace_scope.resource_group_name, self._workspace_name, name)
        return Compute._from_rest_object(rest_obj)

    def create(self, compute: Compute, no_wait: bool = False) -> Union[Compute, LROPoller]:
        """Create a compute

        :param compute: Compute definition
        :type compute: Compute
        :param no_wait: flag to wait for the operation to complete, defaults to False
        :type no_wait: bool, optional
        :return: Either a Compute object or LROPoller
        :rtype: Union[Compute, LROPoller]
        """
        compute.location = self._get_workspace_location()
        if compute.subnet:
            compute.subnet = get_subnet_str(
                compute.vnet_name,
                compute.subnet,
                self._workspace_scope.subscription_id,
                self._workspace_scope.resource_group_name,
            )
        compute_rest_obj = compute._to_rest_object()

        poller = self._operation.begin_create_or_update(
            self._workspace_scope.resource_group_name,
            self._workspace_name,
            compute_name=compute.name,
            parameters=compute_rest_obj,
            polling=not no_wait,
        )

        if not no_wait:
            return Compute._from_rest_object(poller.result())
        else:
            return poller

    def update(
        self,
        name: str,
        max_instances: int,
        min_instances: int,
        idle_time_before_scale_down: int,
        identity_type: str = None,
        user_assigned_identities: list = None,
        no_wait: bool = False,
        **kwargs: Any,
    ) -> Compute:
        """Update a compute

        :param name: The name of the compute
        :type name: str
        :param max_instances: Max number of nodes to use.
        :type max_instances: int
        :param min_instances: Min number of nodes to use.
        :type min_instances: int
        :param idle_time_before_scale_down: Node Idle Time before scaling down amlCompute. This string needs to be in the RFC Format.
        :type idle_time_before_scale_down: int
        :param identity_type: Possible value: [SystemAssigned, UserAssigned]
        :type identity_type: str, optional
        :param user_assigned_identities: The list of user identities associated with the resource.
        :type user_assigned_identities: list, optional
        :param no_wait: flag to wait for the operation to complete, defaults to False
        :type no_wait: bool, optional
        :return: Compute resource
        :rtype: Compute
        """

        scale_settings, identity = make_identity_and_scale_settings(
            max_instances=max_instances,
            min_instances=min_instances,
            idle_time_before_scale_down=idle_time_before_scale_down,
            identity_type=identity_type,
            user_assigned_identities=user_assigned_identities,
        )

        cluster_update_params = ClusterUpdateParameters(scale_settings=scale_settings)
        compute_res = ComputeResource(properties=cluster_update_params, identity=identity)

        try:
            rest_obj = self._operation.begin_update(
                self._workspace_scope.resource_group_name,
                self._workspace_name,
                compute_name=name,
                parameters=compute_res,
                polling=not no_wait,
            )
            return Compute._from_rest_object(rest_obj)
        # This is a temporary fix until the swagger with MLC if fixed for update not to throw exception on 202
        except HttpResponseError as e:
            if e.status_code == 202:
                time.sleep(5)
                return self.get(name=name)
            raise e

    def delete(self, name: str, action: str = "Delete", no_wait: bool = False) -> LROPoller:
        """Delete a compute

        :param name: the name of the compute
        :type name: str
        :param action: action to perform. Possible value: [Delete, Detach], defaults to "Delete"
        :type action: str, optional
        :param no_wait: flag to wait for the operation to complete, defaults to False
        :type no_wait: bool, optional
        :return: LROPoller
        :rtype: LROPoller
        """
        return self._operation.begin_delete(
            self._workspace_scope.resource_group_name,
            self._workspace_name,
            name,
            underlying_resource_action=action,
            polling=not no_wait,
        )

    def start(self, name: str, no_wait: bool = False) -> LROPoller:
        """Start a compute

        :param name: the name of the compute
        :type name: str
        :param no_wait: flag to wait for the operation to complete, defaults to False
        :type no_wait: bool, optional
        :return: LROPoller
        :rtype: LROPoller
        """
        return self._operation.begin_start(
            self._workspace_scope.resource_group_name, self._workspace_name, name, polling=not no_wait
        )

    def stop(self, name: str, no_wait: bool = False) -> LROPoller:
        """Stop a compute

        :param name: the name of the compute
        :type name: str
        :param no_wait: flag to wait for the operation to complete, defaults to False
        :type no_wait: bool, optional
        :return: LROPoller
        :rtype: LROPoller
        """
        return self._operation.begin_stop(
            self._workspace_scope.resource_group_name, self._workspace_name, name, polling=not no_wait
        )

    def restart(self, name: str) -> None:
        """Restart a compute

        :param name: the name of the compute
        :type name: str
        """
        return self._operation.restart(self._workspace_scope.resource_group_name, self._workspace_name, name)

    def list_usage(self, location: str) -> None:
        """
        If location not provided , defaults to workspace location
        """
        if not location:
            location = self._get_workspace_location()
        return self._usage_operations.list(location=location)

    def list_sizes(self, location: str, compute_type: str = None) -> list:
        """
        If location not provided , defaults to workspace location
        """
        if not location:
            location = self._get_workspace_location()
        size_list = self._vmsize_operations.list(location=location)
        if compute_type:
            return [
                item
                for item in size_list.aml_compute
                if compute_type in item.additional_properties["supportedComputeTypes"]
            ]
        else:
            return size_list

    def _get_workspace_location(self) -> str:
        workspace = self._workspace_operations.get(self._resource_group_name, self._workspace_name)
        return workspace.location
