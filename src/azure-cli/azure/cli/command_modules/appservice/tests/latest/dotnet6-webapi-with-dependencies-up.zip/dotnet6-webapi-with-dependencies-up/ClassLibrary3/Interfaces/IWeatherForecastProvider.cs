﻿namespace ClassLibrary3.Interfaces
{
    public interface IWeatherForecastProvider
    {
        IEnumerable<WeatherForecastDTO> Get();
    }
}