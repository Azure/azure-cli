Microsoft Azure CLI 'component' Command Module
==============================================

This package is for the 'component' module.
i.e. 'az component'


