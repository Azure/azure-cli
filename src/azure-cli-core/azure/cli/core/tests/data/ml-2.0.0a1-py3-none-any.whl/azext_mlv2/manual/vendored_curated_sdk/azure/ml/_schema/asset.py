# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import CreationContextSchema
from marshmallow import fields, post_load, ValidationError, pre_load
from .resource import ResourceSchema
from .fields import ArmStr, ArmVersionedStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType

module_logger = logging.getLogger(__name__)


class AssetSchema(ResourceSchema):
    version = fields.Int()
    datastore = ArmStr(
        azureml_type=AzureMLResourceType.DATASTORE,
        metadata={"description": "the datastore in which the data resides (once the Artifact is created)"},
    )
    local_path = fields.Str(metadata={"description": "the path from which the data gets uploaded to the cloud"})
    path = fields.Str(metadata={"description": "URI pointing to a file or directory."})
    arm_id = ArmVersionedStr(azureml_type=AzureMLResourceType.DATA, dump_only=True)
    creation_context = NestedField(CreationContextSchema, dump_only=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Data

        return Data(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class AnonymousAssetSchema(AssetSchema):
    version = fields.Int(dump_only=True)
    name = fields.Str(dump_only=True)

    @pre_load
    def warn_if_named(self, data, **kwargs):
        if isinstance(data, str):
            raise ValidationError("Anonymous assets must be defined inline")
        name = data.pop("name", None)
        data.pop("version", None)
        if name is not None:
            print(f"Warning: the provided asset name '{name}' will not be used for anonymous registration")
        return data
