# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    CredentialsType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    AccountKeyDatastoreCredentials,
    AccountKeyDatastoreSecrets,
    SasDatastoreCredentials,
    SasDatastoreSecrets,
    ServicePrincipalDatastoreCredentials,
    ServicePrincipalDatastoreSecrets,
    CertificateDatastoreCredentials,
    CertificateDatastoreSecrets,
)


class DatastoreCredentials(RestTranslatableMixin):
    def __init__(self, type: str = None):
        self.type = type


class AccountKeyCredentials(DatastoreCredentials):
    def __init__(
        self,
        key: str = None,
    ):
        self.type = CredentialsType.ACCOUNT_KEY
        self.key = key

    def _to_rest_object(self) -> AccountKeyDatastoreCredentials:
        secrets = AccountKeyDatastoreSecrets(key=self.key)
        return AccountKeyDatastoreCredentials(secrets=secrets)

    @classmethod
    def _from_rest_object(cls, obj: AccountKeyDatastoreCredentials) -> "AccountKeyCredentials":
        return cls(key=obj.secrets.key if obj.secrets else None)

    def __eq__(self, other: "AccountKeyCredentials") -> bool:
        return self.key == other.key

    def __ne__(self, other: "AccountKeyCredentials") -> bool:
        return not self.__eq__(other)


class SasTokenCredentials(DatastoreCredentials):
    def __init__(
        self,
        sas_token: str = None,
    ):
        self.type = CredentialsType.SAS
        self.sas_token = sas_token

    def _to_rest_object(self) -> SasDatastoreCredentials:
        secrets = SasDatastoreSecrets(sas_token=self.sas_token)
        return SasTokenDatastoreCredentials(secrets=secrets)

    @classmethod
    def _from_rest_object(cls, obj: SasDatastoreCredentials) -> "AccountKeyCredentials":
        return cls(sas_token=obj.secrets.sas_token if obj.secrets else None)

    def __eq__(self, other: "SasTokenCredentials") -> bool:
        return self.sas_token == other.sas_token

    def __ne__(self, other: "SasTokenCredentials") -> bool:
        return not self.__eq__(other)


class BaseTenantCredentials(DatastoreCredentials):
    def __init__(
        self,
        authority_url: str = None,
        resource_url: str = None,
        tenant_id: str = None,
        client_id: str = None,
    ):
        self.authority_url = authority_url
        self.resource_url = resource_url
        self.tenant_id = tenant_id
        self.client_id = client_id


class ServicePrincipalCredentials(BaseTenantCredentials):
    def __init__(
        self,
        client_secret=None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.type = CredentialsType.SERVICE_PRINCIPAL
        self.client_secret = client_secret

    def _to_rest_object(self) -> ServicePrincipalDatastoreCredentials:
        secrets = ServicePrincipalDatastoreSecrets(client_secret=self.client_secret)
        return ServicePrincipalDatastoreCredentials(
            authority_url=self.authority_url,
            resource_uri=self.resource_url,
            tenant_id=self.tenant_id,
            client_id=self.client_id,
            secrets=secrets,
        )

    @classmethod
    def _from_rest_object(cls, obj: ServicePrincipalDatastoreCredentials) -> "ServicePrincipalCredentials":
        return cls(
            authority_url=obj.authority_url,
            resource_url=obj.resource_uri,
            tenant_id=obj.tenant_id,
            client_id=obj.client_id,
            client_secret=obj.secrets.client_secret if obj.secrets else None,
        )

    def __eq__(self, other: "ServicePrincipalCredentials") -> bool:
        return (
            self.authority_url == other.authority_url
            and self.resource_url == other.resource_url
            and self.tenant_id == other.tenant_id
            and self.client_id == other.client_id
            and self.client_secret == other.client_secret
        )

    def __ne__(self, other: "ServicePrincipalCredentials") -> bool:
        return not self.__eq__(other)


class CertificateCredentials(BaseTenantCredentials):
    def __init__(
        self,
        certificate: str = None,
        thumprint: str = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.type = CredentialsType.CERTIFICATE
        self.certificate = certificate
        self.thumbprint = thumprint

    def _to_rest_object(self) -> CertificateDatastoreCredentials:
        secrets = CertificateDatastoreSecrets(certificate=self.certificate)
        return CertificateDatastoreCredentials(
            authority_url=self.authority_url,
            resource_uri=self.resource_url,
            tenant_id=self.tenant_id,
            client_id=self.client_id,
            thumbprint=self.thumbprint,
            secrets=secrets,
        )

    @classmethod
    def _from_rest_object(cls, obj: CertificateDatastoreCredentials) -> "CertificateCredentials":
        return cls(
            authority_url=obj.authority_url,
            resource_url=obj.resource_uri,
            tenant_id=obj.tenant_id,
            client_id=obj.client_id,
            thumbprint=obj.thumbprint,
            certificate=obj.secrets.certificate if obj.secrets else None,
        )

    def __eq__(self, other: "CertificateCredential") -> bool:
        return (
            self.authority_url == other.authority_url
            and self.resource_url == other.resource_url
            and self.tenant_id == other.tenant_id
            and self.client_id == other.client_id
            and self.thumbprint == other.thumbprint
            and self.certificate == other.certificate
        )

    def __ne__(self, other: "CertificateCredential") -> bool:
        return not self.__eq__(other)
