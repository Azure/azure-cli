# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Union, List

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    ForecastingSettings as RestForecastingSettings,
    TargetLags,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    TargetLagsMode,
)


class ForecastingSettings(RestTranslatableMixin):
    """Forecasting settings for an AutoML Job

    :param country_or_region_for_holidays: The country/region used to generate holiday features. These should be ISO 3166 two-letter country/region code, for example 'US' or 'GB'.
    :type country_or_region_for_holidays: str
    :param forecast_horizon: The desired maximum forecast horizon in units of time-series frequency.
    :type forecast_horizon: int
    :param target_lags: The number of past periods to lag from the target column. Use 'auto' to use the automatic heuristic based lag.
    :type target_lags: Union[str, int, List[int]]
    :param target_rolling_window_size: The number of past periods used to create a rolling window average of the target column.
    :type target_rolling_window_size: int
    :param time_column_name: The name of the time column.
    :type time_column_name: str
    :param time_series_id_column_names:  The names of columns used to group a timeseries.
    :type time_series_id_column_names: Union[str, List[str]]
    """

    def __init__(
        self,
        country_or_region_for_holidays: str = None,
        forecast_horizon: int = None,
        target_lags: Union[str, int, List[int]] = TargetLagsMode.OFF.lower(),
        target_rolling_window_size: int = None,
        time_column_name: str = None,
        time_series_id_column_names: Union[str, List[str]] = None,
    ):
        self.country_or_region_for_holidays = country_or_region_for_holidays
        self.forecast_horizon = forecast_horizon
        self.target_lags = target_lags
        self.target_rolling_window_size = target_rolling_window_size
        self.time_column_name = time_column_name
        self.time_series_id_column_names = time_series_id_column_names

    def _to_rest_object(self) -> RestForecastingSettings:
        if not self.target_lags:
            target_lags = TargetLags(mode=TargetLagsMode.OFF)
        elif isinstance(self.target_lags, str):
            target_lags = TargetLags(mode=self.target_lags)
        else:
            lags = [self.target_lags] if not isinstance(self.target_lags, list) else self.target_lags
            target_lags = TargetLags(mode=TargetLagsMode.CUSTOM, lags=lags)
        return RestForecastingSettings(
            forecasting_country_or_region=self.country_or_region_for_holidays,
            time_column_name=self.time_column_name,
            target_lags=target_lags,
            target_rolling_window_size=self.target_rolling_window_size,
            forecast_horizon=self.forecast_horizon,
            time_series_id_column_names=[self.time_series_id_column_names]
            if not isinstance(self.time_series_id_column_names, list)
            else self.time_series_id_column_names,
        )

    @classmethod
    def _from_rest_object(cls, obj: RestForecastingSettings) -> "ForecastingSettings":
        rest_target_lags = obj.target_lags
        if not rest_target_lags:
            target_lags = TargetLagsMode.OFF.lower()
        elif rest_target_lags.mode == TargetLagsMode.AUTO or rest_target_lags.mode == TargetLagsMode.OFF:
            target_lags = rest_target_lags.mode.lower()
        else:
            target_lags = rest_target_lags.lags
        return cls(
            country_or_region_for_holidays=obj.forecasting_country_or_region,
            forecast_horizon=obj.forecast_horizon,
            target_lags=target_lags,
            target_rolling_window_size=obj.target_rolling_window_size,
            time_column_name=obj.time_column_name,
            time_series_id_column_names=obj.time_series_id_column_names,
        )

    def __eq__(self, other) -> bool:
        return (
            self.country_or_region_for_holidays == other.country_or_region_for_holidays
            and self.forecast_horizon == other.forecast_horizon
            and self.target_lags == other.target_lags
            and self.target_rolling_window_size == other.target_rolling_window_size
            and self.time_column_name == other.time_column_name
            and self.time_series_id_column_names == other.time_series_id_column_names
        )

    def __ne__(self, other) -> bool:
        return not self.__eq__(other)
