# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta
from marshmallow import fields, post_load


class EndpointConnectionSchema(metaclass=PatchedSchemaMeta):
    subscription_id = fields.UUID()
    resource_group = fields.Str()
    location = fields.Str()
    vnet_name = fields.Str()
    subnet_name = fields.Str()

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import EndpointConnection

        return EndpointConnection(**data)
