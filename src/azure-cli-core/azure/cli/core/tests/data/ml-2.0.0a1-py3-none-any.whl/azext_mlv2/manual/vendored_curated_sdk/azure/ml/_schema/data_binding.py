# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from marshmallow import fields, post_load
from .schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import DataBinding

module_logger = logging.getLogger(__name__)


class DataBindingSchema(metaclass=PatchedSchemaMeta):
    source_data_reference = fields.Str()
    local_reference = fields.Str()
    mode = fields.Str()

    @post_load
    def make(self, data, **kwargs):
        return DataBinding(**data)
