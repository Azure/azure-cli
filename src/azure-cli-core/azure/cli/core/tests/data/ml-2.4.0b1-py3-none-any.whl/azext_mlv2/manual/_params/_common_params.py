# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import List, Union
from azure.cli.core.commands.parameters import (
    resource_group_name_type,
    LocalContextAttribute,
    LocalContextAction,
    ALL,
    tags_type,
)
from azext_mlv2.manual.action import OverridePropertiesBySet


REF_DOC_SENTENCE_FMT = "The YAML reference docs for {} can be found at: {}"


def add_common_params(c):
    c.argument("resource_group_name", resource_group_name_type)
    c.argument(
        "workspace_name",
        options_list=["--workspace-name", "-w"],
        type=str,
        help="Name of the Azure ML workspace."
        " You can configure the default group using `az configure --defaults workspace=<name>`",
        configured_default="workspace",
        local_context_attribute=LocalContextAttribute(
            name="aml_workspace_name", actions=[LocalContextAction.SET, LocalContextAction.GET], scopes=[ALL]
        ),
    )


def add_override_param(c):
    c.argument(
        "params_override",
        options_list=["--set"],
        help="Update an object by specifying a property path and value to set. Example: --set "
        "property1.property2=<value>.",
        action=OverridePropertiesBySet,
        nargs="+",
    )


def add_max_results_params(c):
    c.argument(
        "max_results",
        options_list=["--max-results", "-r"],
        type=int,
        help="Max number of results to return.",
    )


def add_lro_param(c):
    c.argument(
        "no_wait",
        help="Do not wait for the long-running-operation to finish. Default is False",
    )


def add_tags_param(c):
    c.argument(
        "tags",
        tags_type,
        options_list=["--tags"],
        help="Space-separated key-value pairs for the tags of the object.",
    )


def add_description_param(c, help_message: str = "Description of the object."):
    c.argument(
        "description",
        options_list=["--description"],
        help=help_message,
    )


def add_include_archived_param(c, help_message: str):
    c.argument(
        "include_archived",
        options_list=["--include-archived"],
        help=help_message,
    )


def add_archived_only_param(c, help_message):
    c.argument(
        "archived_only",
        options_list=["--archived-only"],
        help=help_message,
    )


def add_file_param(c, resource_type: str, ref_doc_links: Union[str, List[str]]):
    if isinstance(ref_doc_links, list):
        ref_doc_links = ", ".join(ref_doc_links)
    ref_doc_phrase = REF_DOC_SENTENCE_FMT.format(resource_type, ref_doc_links)
    c.argument(
        "file",
        options_list=["--file", "-f"],
        help=f"Local path to the YAML file containing the Azure ML {resource_type} specification. {ref_doc_phrase}",
    )


def add_registry_param(c):
    c.argument(
        "registry_name",
        options_list=["--registry-name"],
        help=" this will interact with the registry provided name, not use workspace",
    )
