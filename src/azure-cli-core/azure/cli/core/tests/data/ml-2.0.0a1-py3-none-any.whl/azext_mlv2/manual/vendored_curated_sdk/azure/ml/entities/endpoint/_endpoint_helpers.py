# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import re
from typing import List, Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import OnlineEndpointConfigurations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint.deployment import Deployment


def validate_endpoint_name(name: str) -> None:
    """Validates that the name of an endpoint or deployment is:
    1. Between 3 and 32 characters long (inclusive of both ends of the range)
    2. Follows the following regex pattern: ^[a-zA-Z]([-a-zA-Z0-9]*[a-zA-Z0-9])?$
    """
    if (
        len(name) < OnlineEndpointConfigurations.MIN_NAME_LENGTH
        or len(name) > OnlineEndpointConfigurations.MAX_NAME_LENGTH
    ):
        raise Exception(
            "The name for an endpoint must be at least 3 and at most 32 characters long (inclusive of both limits)."
        )
    if not re.match(OnlineEndpointConfigurations.NAME_REGEX_PATTERN, name):
        raise Exception(
            "The name for an endpoint must start with an upper- or lowercase letter and only consist of '-'s and alphanumeric characters."
        )


def validate_uniqueness_of_deployment_names(deployments: List[Deployment]) -> None:
    if len({d.name for d in deployments}) != len(deployments):
        raise Exception("the names for deployment is not unique")


def validate_deployment_name_matches_traffic(deployments: List[Deployment], traffic: Dict) -> None:
    # https://docs.python.org/3.8/library/stdtypes.html#dict-views. Dict keys returned Keys views which are set-like since their entries
    # are unique and hashable. For set-like views, all of the operations defined for the abstract base class collections.abc.Set are available (for example, ==, <, or ^).
    if traffic and (not deployments or traffic.keys() != {d.name for d in deployments}):
        raise Exception(f"The deployment names in the traffic rules must match the traffic names: {traffic.keys()}")
