Microsoft Azure CLI 'serviceconnector-passwordless' Extension

==========================================



This package is for the 'serviceconnector-passwordless' extension.

i.e. 'az serviceconnector-passwordless'

.. :changelog:



Release History

===============

0.3.13

++++++

* AAD rebranding and make some improvements



0.3.12

++++++

* make some improvements and support slot.



0.3.11

++++++

* make some improvements.



0.3.10

++++++

* make some improvements.



0.3.9

++++++

* Support `--customized-keys` and make some improvements.



0.3.8

++++++

* Make some improvements.



0.3.6

++++++

* Make some improvements.



0.3.5

++++++

* Make some improvements.



0.3.4

++++++

* Make some improvements.



0.3.3

++++++

* Make some improvements.



0.3.2

++++++

* Fix some issues and support Service Principal for local connection.



0.3.1

++++++

* Support User-Assigned Managed Identity and Service Principal.



0.3.0

++++++

* Add extension information in API request.



0.2.2

++++++

* Update dependency psycopg2 to psycopg2-binary.



0.2.1

++++++

* Update SQL connection.



0.2.0

++++++

* Fix some security issues. Prompt confirmation before open all IPs. Add param `--yes` to skip the confirmation. 



0.1.0

++++++

* Initial release.

