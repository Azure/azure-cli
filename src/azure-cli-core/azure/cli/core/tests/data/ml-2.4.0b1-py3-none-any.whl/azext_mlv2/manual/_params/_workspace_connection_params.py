# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import (
    add_common_params,
    add_override_param,
    add_max_results_params,
)


def add_name_param(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the environment.")


def load_workspace_connection_params(self):
    with self.argument_context("ml connection create") as c:
        add_common_params(c)
        add_name_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML workspace connection specification.",
        )
        add_override_param(c)

    with self.argument_context("ml connection show") as c:
        add_common_params(c)
        add_name_param(c)

    with self.argument_context("ml connection list") as c:
        add_common_params(c)
        add_max_results_params(c)
        c.argument(
            "connection_type",
            options_list=["--type", "-t"],
            help="The type of Azure ML workspace connection to list.",
        )

    with self.argument_context("ml connection update") as c:
        add_common_params(c)
        add_name_param(c)

    with self.argument_context("ml connection delete") as c:
        add_common_params(c)
        add_name_param(c)
