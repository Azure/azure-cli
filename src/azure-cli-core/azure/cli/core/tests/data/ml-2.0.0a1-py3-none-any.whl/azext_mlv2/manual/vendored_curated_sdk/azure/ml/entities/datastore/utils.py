# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    DatastoreCredentials,
    AccountKeyDatastoreCredentials,
    SasDatastoreCredentials,
    ServicePrincipalDatastoreCredentials,
    CertificateDatastoreCredentials,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.datastore.credentials import (
    AccountKeyCredentials,
    SasTokenCredentials,
    ServicePrincipalCredentials,
    CertificateCredentials,
)


def from_rest_datastore_credentials(rest_credentials: DatastoreCredentials):
    if isinstance(rest_credentials, AccountKeyDatastoreCredentials):
        return AccountKeyCredentials._from_rest_object(rest_credentials)
    elif isinstance(rest_credentials, SasDatastoreCredentials):
        return SasTokenCredentials._from_rest_object(rest_credentials)
    elif isinstance(rest_credentials, ServicePrincipalDatastoreCredentials):
        return ServicePrincipalCredentials._from_rest_object(rest_credentials)
    elif isinstance(rest_credentials, CertificateDatastoreCredentials):
        return CertificateCredentials._from_rest_object(CertificateCredentials)
