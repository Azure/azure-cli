# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings
from itertools import islice

from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Dataset


def ml_dataset_list(cmd, resource_group_name, workspace_name, name=None, max_results=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if max_results:
            results = islice(ml_client.datasets.list(name=name), int(max_results))
        else:
            results = ml_client.datasets.list(name=name)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_dataset_show(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        dataset = ml_client.datasets.get(name=name, version=version, label=label)
        return _dump_entity_with_warnings(dataset)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_dataset_create(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    version=None,
    file=None,
    paths=None,
    local_path=None,
    description=None,
    tags=None,
    params_override=None,
    **kwargs,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    if name:
        params_override.append({"name": name})
    if version:
        params_override.append({"version": version})
    if paths:
        # should support array of paths in future
        path_list = []
        if paths.startswith("file:"):
            path_list.append({"file": paths[5:]})
        elif paths.startswith("folder:"):
            path_list.append({"folder": paths[7:]})
        else:
            log_and_raise_error(Exception("Unable to parse paths. Should start with 'file:' or 'folder:'"), debug)
        params_override.append({"paths": path_list})
    if local_path:
        params_override.append({"local_path": local_path})
    if description:
        params_override.append({"description": description})
    if tags:
        params_override.append({"tags": tags})

    try:
        dataset = Dataset.load(path=file, params_override=params_override)
        dataset = ml_client.create_or_update(dataset)
        if kwargs.get("no_dump", None):
            return dataset
        else:
            return _dump_entity_with_warnings(dataset)
    except Exception as err:
        log_and_raise_error(err, debug)


# This will only be used for generic update
def _ml_dataset_update(cmd, resource_group_name, workspace_name, name=None, version=None, **kwargs):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    dataset_params = kwargs["parameters"]

    if name:
        dataset_params["name"] = name
    # TODO: need to add validation for version
    if version:
        dataset_params["version"] = version

    try:
        dataset_obj = Dataset._load(yaml_data=dataset_params)
        dataset = ml_client.create_or_update(dataset_obj)
        return _dump_entity_with_warnings(dataset)
    except Exception as err:
        log_and_raise_error(err, debug)
