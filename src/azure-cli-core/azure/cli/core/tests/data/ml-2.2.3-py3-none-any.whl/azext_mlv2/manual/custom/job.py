# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from os import getenv
from typing import Dict
from webbrowser import open_new_tab
from itertools import islice
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AZUREML_PRIVATE_FEATURES_ENV_VAR, MAX_LIST_CLI_RESULTS
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Job, AutoMLJob
from marshmallow.utils import EXCLUDE
from .raise_error import log_and_raise_error, print_limited_result_set_warning
from .utils import get_ml_client, _dump_entity_with_warnings, filter_job_tags
from knack.log import get_logger
from azure.cli.core import telemetry
from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient

module_logger = get_logger(__name__)


def open_job_in_browser(job):
    try:
        studio_endpoint = None
        services = job.services
        if services:
            studio_endpoint = services.get("Studio", None)

        if studio_endpoint and studio_endpoint.endpoint:
            open_new_tab(studio_endpoint.endpoint)
        else:
            module_logger.warning("Option --web was specified, but no studio URI was found in the list of services.")

    except Exception as err:
        module_logger.warning(err)


def ml_job_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    name=None,
    save_as=None,
    stream=False,
    web=False,
    params_override=None,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    try:
        if name is not None:
            params_override.append({"name": name})

        job = Job.load(path=file, params_override=params_override)
        job = filter_job_tags(job)
        telemetry.set_debug_info("JobType", job.type)

        job = ml_client.jobs.create_or_update(job=job)
        if save_as:
            job.dump(save_as)

        if web:
            open_job_in_browser(job)

        if stream:
            ml_client.jobs.stream(name=job.name)

        return _dump_entity_with_warnings(job)

    except Exception as err:
        log_and_raise_error(err, debug)


def ml_job_show(cmd, resource_group_name, workspace_name, name, web=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        job = ml_client.jobs.get(name)
        job = filter_job_tags(job)
        private_features_enabled = getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR)
        if isinstance(job, AutoMLJob) and not private_features_enabled:
            log_and_raise_error(f"Job type {type(job)} for {name} is not supported.")
        if web:
            open_job_in_browser(job)

        return _dump_entity_with_warnings(job)
    except Exception as err:
        log_and_raise_error(err, debug)


# Used only by generic update to prevent the browser from opening when reading existing job if a user specifies "web"
def _ml_job_show(cmd, resource_group_name, workspace_name, name):
    return ml_job_show(cmd, resource_group_name, workspace_name, name)


def ml_job_cancel(cmd, resource_group_name, workspace_name, name):

    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.jobs.cancel(name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_job_list(
    cmd,
    resource_group_name,
    workspace_name,
    max_results=MAX_LIST_CLI_RESULTS,
    all_results=False,
    include_archived=False,
    parent_job_name=None,
    **kwargs,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    if all_results:
        max_results = None
    else:
        print_limited_result_set_warning(max_results)

    try:
        ret_list = []
        private_features_enabled = getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR)
        if max_results:
            results = islice(
                ml_client.jobs.list(include_archived=include_archived, parent_job_name=parent_job_name),
                int(max_results),
            )
        else:
            results = ml_client.jobs.list(include_archived=include_archived, parent_job_name=parent_job_name)
        for job in results:
            if job:
                job = filter_job_tags(job)
                ret_list.append(_dump_entity_with_warnings(job))
        return ret_list
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_job_download(cmd, resource_group_name, workspace_name, name, download_path=None, output_name=None, all=False):

    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if not download_path:
            download_path = cmd.cli_ctx.local_context.current_dir
        return ml_client.jobs.download(name=name, download_path=download_path, output_name=output_name, all=all)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_job_stream(cmd, resource_group_name, workspace_name, name):

    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        ml_client.jobs.stream(name=name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_job_archive(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        ml_client.jobs.archive(name=name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_job_restore(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        ml_client.jobs.restore(name=name)
    except Exception as err:
        log_and_raise_error(err, debug)


# This will only be used for generic update
def _ml_job_update(cmd, resource_group_name, workspace_name, web=False, parameters: Dict = None):

    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        # Set unknown to EXCLUDE so that marshmallow doesn't raise on dump only fields.
        job = Job._load(data=parameters, unknown=EXCLUDE)

        updated_job = ml_client.jobs.create_or_update(job=job)
        updated_job = filter_job_tags(updated_job)
        if web:
            open_job_in_browser(updated_job)

        return _dump_entity_with_warnings(updated_job)

    except Exception as err:
        log_and_raise_error(err, debug)
