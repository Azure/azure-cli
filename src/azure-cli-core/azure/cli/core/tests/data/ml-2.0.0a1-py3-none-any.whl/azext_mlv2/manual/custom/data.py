# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from itertools import islice
from marshmallow.utils import EXCLUDE, RAISE
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Data
from .print_error import print_error_and_exit
from .utils import _dump_entity_with_warnings
from .utils import _is_debug_set
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    LIMITED_RESULTSET_WARNING_FORMAT,
)
from .print_error import print_error_and_exit, print_warning_with_fore_reset


def ml_data_list(cmd, resource_group_name, workspace_name, name=None, max_results=100):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    print_warning_with_fore_reset(str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
    try:
        top_n_items = islice(ml_client.data.list(name=name), int(max_results))
        return list(map(lambda x: _dump_entity_with_warnings(x), top_n_items))
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_data_show(cmd, resource_group_name, workspace_name, name, version=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        data = ml_client.data.get(name=name, version=version)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_data_create(cmd, resource_group_name, workspace_name, name=None, version=None, file=None, params_override=[]):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    if name:
        params_override.append({"name": name})
    if version:
        params_override.append({"version": version})

    try:
        data = Data.load(path=file, params_override=params_override)
        data = ml_client.data.create_or_update(data)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        print_error_and_exit(err, debug)


# This will only be used for generic update
def _ml_data_update(cmd, resource_group_name, workspace_name, name=None, version=None, **kwargs):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    data_params = kwargs["parameters"]

    if name:
        data_params["name"] = name
    if version:
        data_params["version"] = version

    try:
        data_obj = Data._load(yaml_data=data_params)
        data = ml_client.data.create_or_update(data_obj)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_data_delete(cmd, resource_group_name, workspace_name, name, version):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.data.delete(name=name, version=version)
    except Exception as err:
        print_error_and_exit(err, debug)
