# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from marshmallow.utils import EXCLUDE
from itertools import islice

from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azure.identity import AzureCliCredential
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Datastore
from azure.cli.core.commands.client_factory import get_subscription_id
from .utils import _is_debug_set
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    LIMITED_RESULTSET_WARNING_FORMAT,
)
from .print_error import print_error_and_exit, print_warning_with_fore_reset


def ml_datastore_delete(cmd, resource_group_name, workspace_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.datastores.delete(name)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_datastore_show(cmd, resource_group_name, workspace_name, name, include_secrets=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        return ml_client.datastores.get(name, include_secrets=include_secrets)._dump_yaml()
    except Exception as err:
        print_error_and_exit(err, debug)


def _ml_datastore_show(cmd, resource_group_name, workspace_name, file=None, name=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    try:
        if file:
            params_override = []
            if name:
                params_override = [{"name": name}]
            return Datastore.load(file, params_override=params_override)._dump_yaml()
        else:
            return ml_datastore_show(cmd, resource_group_name, workspace_name, name)
    except Exception as err:
        print_error_and_exit(err)


def ml_datastore_list(cmd, resource_group_name, workspace_name, include_secrets=False, max_results=100):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    print_warning_with_fore_reset(str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
    try:
        top_n_items = islice(
            ml_client.datastores.list(include_secrets=include_secrets),
            int(max_results),
        )
        return [ds._dump_yaml() for ds in top_n_items]
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_datastore_create(cmd, resource_group_name, workspace_name, file, name=None, params_override=[]):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    if name:
        params_override.append({"name": name})

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )
    try:
        datastore = Datastore.load(file, params_override=params_override)
        return ml_client.datastores.create_or_update(datastore)._dump_yaml()
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_datastore_update(cmd, resource_group_name, workspace_name, parameters: Dict):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )
    try:
        datastore = Datastore._load(parameters)
        return ml_client.datastores.create_or_update(datastore)._dump_yaml()
    except Exception as err:
        print_error_and_exit(err)
