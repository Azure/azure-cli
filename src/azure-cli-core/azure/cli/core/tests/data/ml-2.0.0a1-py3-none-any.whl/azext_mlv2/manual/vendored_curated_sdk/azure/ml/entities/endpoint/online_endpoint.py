# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from abc import abstractmethod
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    OnlineDeploymentTrackedResourceArmPaginatedResult,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import OnlineEndpoint as RestOnlineEndpoint
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    OnlineEndpointTrackedResource,
    ResourceIdentity,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    EndpointAuthMode,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint import K8sOnlineEndpointSchema, ManagedOnlineEndpointSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import dict_eq
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    AAD_TOKEN_YAML,
    AML_TOKEN_YAML,
    BASE_PATH_CONTEXT_KEY,
    KEY,
    ONLINE_ENDPOINT_TYPE,
    TYPE,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint.deployment import Deployment
from ._endpoint_helpers import (
    validate_deployment_name_matches_traffic,
    validate_endpoint_name,
    validate_uniqueness_of_deployment_names,
)
from .endpoint import Endpoint
from .online_deployment import K8sOnlineDeployment, ManagedOnlineDeployment, OnlineDeployment

module_logger = logging.getLogger(__name__)


class OnlineEndpoint(Endpoint):
    """Online endpoint entity

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param auth_mode: Possible values include: "AMLToken", "Key", "AADToken", defaults to None
    :type auth_mode: str, optional
    :param description: Description of the inference endpoint, defaults to None
    :type description: str, optional
    :param location: defaults to None
    :type location: str, optional
    :param traffic:  Traffic rules on how the traffic will be routed across deployments, defaults to {}
    :type traffic: Dict[str, int], optional
    :param deployments: defaults to {}
    :type deployments: Dict[str, OnlineDeployment], optional
    :param scoring_uri: URI to use to perform a prediction, readonly.
    :type scoring_uri: str, optional
    :param swagger_uri: URI to check the swagger definition of the endpoint.
    :type swagger_uri: str, optional
    :param provisioning_state: str, provisioning state, readonly
    :type provisioning_state: str, optional
    :param identity: defaults to SystemAssigned
    :type location: ResourceIdentity, optional
    """

    def __init__(
        self,
        base_path: Optional[str] = None,
        id: str = None,
        name: str = None,
        tags: Dict[str, Any] = None,
        properties: Dict[str, Any] = None,
        auth_mode: str = AML_TOKEN_YAML,
        description: str = None,
        location: str = None,
        traffic: Dict[str, int] = None,
        deployments: List[Deployment] = None,
        scoring_uri: str = None,
        swagger_uri: str = None,
        provisioning_state: str = None,
        identity: ResourceIdentity = None,
        **kwargs,
    ):
        kwargs[TYPE] = ONLINE_ENDPOINT_TYPE
        super(OnlineEndpoint, self).__init__(
            base_path=base_path,
            id=id,
            name=name,
            properties=properties,
            tags=tags,
            auth_mode=auth_mode,
            description=description,
            location=location,
            traffic=traffic,
            scoring_uri=scoring_uri,
            swagger_uri=swagger_uri,
            **kwargs,
        )

        self.deployments = list(deployments) if deployments else []
        self.identity = identity

        self._provisioning_state = provisioning_state

    @property
    def provisioning_state(self) -> Optional[str]:
        return self._provisioning_state

    def _to_rest_online_endpoint(self, location: str) -> OnlineEndpointTrackedResource:
        validate_deployment_name_matches_traffic(self.deployments, self.traffic)
        validate_endpoint_name(self.name)
        validate_uniqueness_of_deployment_names(self.deployments)
        properties = RestOnlineEndpoint(
            description=self.description,
            auth_mode=OnlineEndpoint._yaml_auth_mode_to_rest_auth_mode(self.auth_mode),
            properties=self.properties,
        )
        return OnlineEndpointTrackedResource(
            location=location, properties=properties, identity=self.identity, tags=self.tags
        )

    def _to_rest_online_endpoint_traffic_update(
        self, location: str, no_validation: bool = False
    ) -> OnlineEndpointTrackedResource:
        if not no_validation:
            validate_deployment_name_matches_traffic(self.deployments, self.traffic)
            validate_uniqueness_of_deployment_names(self.deployments)
        properties = RestOnlineEndpoint(
            description=self.description,
            auth_mode=OnlineEndpoint._yaml_auth_mode_to_rest_auth_mode(self.auth_mode),
            endpoint=self.name,
            traffic=self.traffic,
        )
        return OnlineEndpointTrackedResource(
            location=location, properties=properties, identity=self.identity, tags=self.tags
        )

    @classmethod
    def _rest_auth_mode_to_yaml_auth_mode(cls, rest_auth_mode: str) -> str:
        switcher = {
            EndpointAuthMode.AML_TOKEN: AML_TOKEN_YAML,
            EndpointAuthMode.AAD_TOKEN: AAD_TOKEN_YAML,
            EndpointAuthMode.KEY: KEY,
        }

        return switcher.get(rest_auth_mode, rest_auth_mode)

    @classmethod
    def _yaml_auth_mode_to_rest_auth_mode(cls, yaml_auth_mode: str) -> str:
        yaml_auth_mode = yaml_auth_mode.lower()

        switcher = {
            AML_TOKEN_YAML: EndpointAuthMode.AML_TOKEN,
            AAD_TOKEN_YAML: EndpointAuthMode.AAD_TOKEN,
            KEY: EndpointAuthMode.KEY,
        }

        return switcher.get(yaml_auth_mode, yaml_auth_mode)

    @classmethod
    def _from_rest_object(
        cls,
        resource: OnlineEndpointTrackedResource,
        deployments: Iterable[OnlineDeploymentTrackedResourceArmPaginatedResult],
    ):
        all_deployments = []
        if deployments:
            all_deployments = [OnlineDeployment._from_rest_online_deployment(deployment) for deployment in deployments]

        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import K8sOnlineEndpoint, ManagedOnlineEndpoint

        auth_mode = cls._rest_auth_mode_to_yaml_auth_mode(resource.properties.auth_mode)
        if resource.properties.target:
            endpoint = K8sOnlineEndpoint(
                id=resource.id,
                name=resource.name,
                tags=resource.tags,
                properties=resource.properties.properties,
                target=resource.properties.target,
                auth_mode=auth_mode,
                description=resource.properties.description,
                location=resource.location,
                traffic=resource.properties.traffic,
                deployments=all_deployments,
                provisioning_state=resource.properties.provisioning_state,
                scoring_uri=resource.properties.scoring_uri,
                swagger_uri=resource.properties.swagger_uri,
                identity=resource.identity,
            )
        else:
            endpoint = ManagedOnlineEndpoint(
                id=resource.id,
                name=resource.name,
                tags=resource.tags,
                properties=resource.properties.properties,
                auth_mode=auth_mode,
                description=resource.properties.description,
                location=resource.location,
                traffic=resource.properties.traffic,
                deployments=all_deployments,
                provisioning_state=resource.properties.provisioning_state,
                scoring_uri=resource.properties.scoring_uri,
                swagger_uri=resource.properties.swagger_uri,
                identity=resource.identity,
            )

        return endpoint

    def __eq__(self, other) -> bool:
        if not other:
            return False
        # only compare mutable fields
        return (
            self.name.lower() == other.name.lower()
            and self.auth_mode.lower() == other.auth_mode.lower()
            and dict_eq(self.tags, other.tags)
            and self.description == other.description
            and dict_eq(self.traffic, other.traffic)
        )

    def __ne__(self, other) -> bool:
        return not self.__eq__(other)

    def _merge_with(self, other: "OnlineEndpoint") -> None:
        if other:
            super()._merge_with(other)
            for deployment in other.deployments:
                exist_deployment = next((d for d in self.deployments if d.name == deployment.name), None)
                if exist_deployment:
                    exist_deployment._merge_with(deployment)
                else:
                    self.deployments.append(deployment)


class K8sOnlineEndpoint(OnlineEndpoint):
    """K8s Online endpoint entity

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param auth_mode: Possible values include: "AMLToken", "Key", "AADToken", defaults to None
    :type auth_mode: str, optional
    :param description: Description of the inference endpoint, defaults to None
    :type description: str, optional
    :param location: defaults to None
    :type location: str, optional
    :param traffic:  Traffic rules on how the traffic will be routed across deployments, defaults to {}
    :type traffic: Dict[str, int], optional
    :param deployments: defaults to {}
    :type deployments: Dict[str, K8sOnlineDeployment], optional
    :param scoring_uri: URI to use to perform a prediction, readonly.
    :type scoring_uri: str, optional
    :param swagger_uri: URI to check the swagger definition of the endpoint.
    :type swagger_uri: str, optional
    :param provisioning_state: str, provisioning state, readonly
    :type provisioning_state: str, optional
    :param target: Compute cluster id.
    :type target: str, optional
    :param identity: defaults to SystemAssigned
    :type location: ResourceIdentityInArm, optional
    """

    def __init__(
        self,
        base_path: Optional[str] = None,
        id: str = None,
        name: str = None,
        tags: Dict[str, Any] = None,
        properties: Dict[str, Any] = None,
        auth_mode: str = AML_TOKEN_YAML,
        description: str = None,
        location: str = None,
        traffic: Dict[str, int] = None,
        deployments: List[K8sOnlineDeployment] = None,
        scoring_uri: str = None,
        swagger_uri: str = None,
        provisioning_state: str = None,
        target: str = None,
        identity: ResourceIdentity = None,
    ):
        super(K8sOnlineEndpoint, self).__init__(
            base_path=base_path,
            id=id,
            name=name,
            properties=properties,
            tags=tags,
            auth_mode=auth_mode,
            description=description,
            location=location,
            traffic=traffic,
            deployments=deployments,
            scoring_uri=scoring_uri,
            swagger_uri=swagger_uri,
            provisioning_state=provisioning_state,
            identity=identity,
        )

        self.target = target

    def dump(self) -> Dict[str, Any]:
        context = {BASE_PATH_CONTEXT_KEY: Path(".").parent}
        return K8sOnlineEndpointSchema(context=context).dump(self)

    def _to_rest_online_endpoint(self, location: str) -> OnlineEndpointTrackedResource:
        resource = super()._to_rest_online_endpoint(location)
        resource.properties.target = self.target
        return resource

    def _to_rest_online_endpoint_traffic_update(
        self, location: str, no_validation: bool = False
    ) -> OnlineEndpointTrackedResource:
        resource = super()._to_rest_online_endpoint_traffic_update(location, no_validation)
        resource.properties.target = self.target
        return resource

    def _merge_with(self, other: "K8sOnlineEndpoint") -> None:
        if other:
            if self.name != other.name:
                raise Exception(f"The endpoint name: {self.name} and {other.name} are not matched when combining.")
            super()._merge_with(other)
            self.target = other.target or self.target


class ManagedOnlineEndpoint(OnlineEndpoint):
    """Managed Online endpoint entity

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param auth_mode: Possible values include: "AMLToken", "Key", "AADToken", defaults to None
    :type auth_mode: str, optional
    :param description: Description of the inference endpoint, defaults to None
    :type description: str, optional
    :param location: defaults to None
    :type location: str, optional
    :param traffic:  Traffic rules on how the traffic will be routed across deployments, defaults to {}
    :type traffic: Dict[str, int], optional
    :param deployments: defaults to {}
    :type deployments: Dict[str, ManagedOnlineDeployment], optional
    :param scoring_uri: URI to use to perform a prediction, readonly.
    :type scoring_uri: str, optional
    :param swagger_uri: URI to check the swagger definition of the endpoint.
    :type swagger_uri: str, optional
    :param provisioning_state: str, provisioning state, readonly
    :type provisioning_state: str, optional
    :param identity: defaults to SystemAssigned
    :type location: ResourceIdentityInArm, optional
    """

    def __init__(
        self,
        base_path: Optional[str] = None,
        id: str = None,
        name: str = None,
        tags: Dict[str, Any] = None,
        properties: Dict[str, Any] = None,
        auth_mode: str = AML_TOKEN_YAML,
        description: str = None,
        location: str = None,
        traffic: Dict[str, int] = None,
        deployments: List[ManagedOnlineDeployment] = None,
        scoring_uri: str = None,
        swagger_uri: str = None,
        provisioning_state: str = None,
        identity: ResourceIdentity = None,
    ):
        super(ManagedOnlineEndpoint, self).__init__(
            base_path=base_path,
            id=id,
            name=name,
            properties=properties,
            tags=tags,
            auth_mode=auth_mode,
            description=description,
            location=location,
            traffic=traffic,
            deployments=deployments,
            scoring_uri=scoring_uri,
            swagger_uri=swagger_uri,
            provisioning_state=provisioning_state,
            identity=identity,
        )

    def dump(self) -> Dict[str, Any]:
        context = {BASE_PATH_CONTEXT_KEY: Path(".").parent}
        return ManagedOnlineEndpointSchema(context=context).dump(self)
