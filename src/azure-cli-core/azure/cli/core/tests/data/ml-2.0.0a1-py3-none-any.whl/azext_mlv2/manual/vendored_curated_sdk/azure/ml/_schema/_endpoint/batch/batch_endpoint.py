# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any
from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.endpoint import EndpointSchema
from .batch_deployment import BatchDeploymentSchema

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY

module_logger = logging.getLogger(__name__)


class BatchEndpointSchema(EndpointSchema):
    deployments = fields.List(NestedField(BatchDeploymentSchema))

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import BatchEndpoint

        return BatchEndpoint(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
