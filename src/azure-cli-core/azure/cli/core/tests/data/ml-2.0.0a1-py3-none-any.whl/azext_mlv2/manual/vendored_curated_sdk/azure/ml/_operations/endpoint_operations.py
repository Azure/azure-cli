# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import json
import logging
import os
import random
import time
from http import HTTPStatus
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Union

import requests
from azure.core.exceptions import HttpResponseError
from azure.core.polling import LROPoller
from azure.identity import ChainedTokenCredential
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._arm_deployments import ArmDeploymentExecutor, OnlineEndpointArmGenerator
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations.endpoint_validator import EndpointValidator
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    BatchEndpointTrackedResourceArmPaginatedResult,
    BatchJobResource,
    DeploymentLogsRequest,
    EndpointAuthKeys,
    EndpointAuthToken,
    OnlineEndpointTrackedResource,
    OnlineEndpointTrackedResourceArmPaginatedResult,
    RegenerateEndpointKeysRequest,
    KeyType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.batch.batch_job import BatchJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Data, Model
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._endpoint_utils import polling_wait, local_endpoint_polling_wrapper
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import (
    generate_data_arm_id,
    get_datastore_arm_id,
    is_ARM_id_for_resource,
    parse_name_version,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import (
    _get_mfe_base_url_from_batch_endpoint,
    load_yaml,
    modified_operation_client,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations._local_endpoint_helper import _LocalEndpointHelper
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    API_VERSION_2021_03_01_PREVIEW,
    API_VERSION_2020_09_01_DATAPLANE,
    BASE_PATH_CONTEXT_KEY,
    BATCH_ENDPOINT_TYPE,
    KEY,
    ONLINE_ENDPOINT_TYPE,
    PARAMS_OVERRIDE_KEY,
    AzureMLResourceType,
    EndpointDeploymentLogContainerType,
    EndpointInvokeFields,
    EndpointYamlFields,
    HttpResponseStatusCode,
    OnlineEndpointConfigurations,
    EndpointKeyType,
    AZUREML_LOCAL_ENDPOINTS_NOT_IMPLEMENTED_ERROR,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import BatchEndpoint, CodeConfiguration, Endpoint, K8sOnlineEndpoint, OnlineEndpoint, Deployment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint.batch_deployment import BatchDeployment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint._endpoint_helpers import validate_deployment_name_matches_traffic
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._azureml_polling import AzureMLPolling
from marshmallow import RAISE

from .operation_orchestrator import OperationOrchestrator

module_logger = logging.getLogger(__name__)


class EndpointOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: AzureMachineLearningWorkspaces,
        all_operations: OperationsContainer,
        local_endpoint_helper: _LocalEndpointHelper,
        credentials: ChainedTokenCredential = None,
        **kwargs: Dict,
    ):
        super(EndpointOperations, self).__init__(workspace_scope)
        self._client = service_client
        self._local_endpoint_helper = local_endpoint_helper
        self._online_operation = service_client.online_endpoints
        self._batch_operation = service_client.batch_endpoints
        self._online_deployment = service_client.online_deployments
        self._batch_deployment = service_client.batch_deployments
        self._batch_job_endpoint = service_client.batch_job_endpoint
        self._batch_job_deployment = service_client.batch_job_deployment
        self._all_operations = all_operations
        self._credentials = credentials
        self._init_kwargs = kwargs

    def list(
        self,
        type: str = ONLINE_ENDPOINT_TYPE,
        local: bool = False,
    ) -> Union[
        Iterable[OnlineEndpointTrackedResourceArmPaginatedResult],
        Iterable[BatchEndpointTrackedResourceArmPaginatedResult],
    ]:
        """List endpoints of the workspace.

        :param str type: the endpoint type. Defaults to ONLINE_ENDPOINT_TYPE.
        :param (bool, optional) local: Whether endpoints should be listed from local docker environment. Defaults to False.
        :return: a list of endpoints
        """
        endpoint_type = self._validate_endpoint_type(endpoint_type=type)
        if local:
            return self._local_endpoint_helper.list()
        if endpoint_type.lower() == ONLINE_ENDPOINT_TYPE:
            return self._online_operation.list(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
        else:
            return self._batch_operation.list(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )

    def list_keys(self, name: str, type: str = ONLINE_ENDPOINT_TYPE) -> Union[EndpointAuthKeys, EndpointAuthToken]:
        """List the keys

        :param name str: the endpoint name
        :param str type: the endpoint type. Defaults to ONLINE_ENDPOINT_TYPE.
        :raise: Exception if cannot get online credentials
        :return Union[EndpointAuthKeys, EndpointAuthToken]: depending on the auth mode in the endpoint, returns either keys or token
        """
        endpoint_type = self._validate_endpoint_type(endpoint_type=type)
        if endpoint_type.lower() == ONLINE_ENDPOINT_TYPE:
            return self._get_online_credentials(name=name)
        else:
            raise Exception("Batch endpoints don't support listing keys.")

    def get(
        self, name: str, type: str = ONLINE_ENDPOINT_TYPE, local: bool = False
    ) -> Union[OnlineEndpoint, BatchEndpoint]:
        """Get a Endpoint resource.

        :param str name: Name of the endpoint.
        :param str type: the endpoint type. Defaults to ONLINE_ENDPOINT_TYPE.
        :param (bool, optional) local: Whether endpoint should be retrieved from local docker environment. Defaults to False.
        :return: Endpoint object retrieved from the service.
        :rtype: Union[OnlineEndpoint, BatchEndpoint]:
        """
        endpoint_type = self._validate_endpoint_type(endpoint_type=type)
        if local:
            return self._local_endpoint_helper.get(endpoint_name=name)
        if endpoint_type.lower() == ONLINE_ENDPOINT_TYPE:
            return self._get_online_endpoint(name)
        else:
            return self._get_batch_endpoint(name)

    def delete(
        self, name: str, type: str = ONLINE_ENDPOINT_TYPE, deployment: str = None, local: bool = False, no_wait=False
    ) -> None:
        """Delete a Endpoint resource.

        :param str name: Name of the endpoint.
        :param str type: the endpoint type. Defaults to ONLINE_ENDPOINT_TYPE.
        :param (str, optional) deployment: The endpoint deployment name to be deleted.
        :param (bool, optional) local: Whether endpoint should be deleted from local docker environment. Defaults to False.
        :param (str, optional) no_wait: a flag to indicate whether to wait for the deletion.
        """
        endpoint_type = self._validate_endpoint_type(endpoint_type=type)
        if local:
            resource_name = f"local deployment ({name} / {deployment})" if deployment else f"local endpoint ({name})"
            local_endpoint_polling_wrapper(
                func=self._local_endpoint_helper.delete,
                message=f"Deleting {resource_name} ",
                name=name,
                deployment_name=deployment,
            )
        elif endpoint_type.lower() == ONLINE_ENDPOINT_TYPE:
            self._delete_online_endpoint(name=name, deployment=deployment, no_wait=no_wait)
        else:
            self._delete_batch_endpoint(name=name, deployment=deployment)

    def create(
        self,
        endpoint: Endpoint,
        local: bool = False,
        no_wait: bool = False,
    ) -> Optional[Endpoint]:
        """Create an endpoint

        :param Endpoint endpoint: the endpoint entity
        :param (bool, optional) no_wait: Defaults to False.
        :param (bool, optional) local: Whether endpoint should be created locally. Defaults to False.
        :param (bool, optional) no_wait: Defaults to False.
        :raise: TypeError: when endpoint is not a online, or batch endpoint
        :return Optional[Endpoint]: the endpoint entity
        """
        if local:
            if not isinstance(endpoint, OnlineEndpoint):
                raise TypeError(f"Expected OnlineEndpoint, {type(endpoint)} found.")
            return self._local_endpoint_helper.create(endpoint=endpoint)
        if isinstance(endpoint, OnlineEndpoint):
            return self._create_online_endpoint(internal_endpoint=endpoint, no_wait=no_wait)
        elif isinstance(endpoint, BatchEndpoint):
            return self._create_or_update_batch_endpoint(endpoint=endpoint)
        else:
            raise TypeError(f"Expected Endpoint, {type(endpoint)} found.")

    def get_deployment_logs(
        self,
        endpoint_name: str,
        deployment_name: str,
        lines: int,
        type: str = None,
        local: bool = False,
        container_type: Optional[str] = None,
    ) -> str:
        """Get the deployment logs for online endpoint

        :param str endpoint_name: the endpoint name
        :param str deployment_name: the deployment name
        :param int lines: The maximum number of lines to tail.
        :param str type: the endpoint type. Defaults to ONLINE_ENDPOINT_TYPE.
        :param (bool, optional) local: Logs should be pulled from local endpoint. Defaults to False.
        :param (str, optional) container_type: one of StorageInitializer, InferenceServer, inference-server, storage-initializer. Defaults to None.
        :return str: the stream of logs
        """
        endpoint_type = self._validate_endpoint_type(endpoint_type=type)
        if local:
            return self._local_endpoint_helper.get_deployment_logs(
                endpoint_name=endpoint_name, deployment_name=deployment_name, lines=lines
            )
        if endpoint_type == ONLINE_ENDPOINT_TYPE:
            return self._get_online_deployment_logs(
                endpoint_name, deployment_name, lines, container_type=container_type
            )
        else:
            pass

    def regenerate_keys(
        self, name: str, type: str = ONLINE_ENDPOINT_TYPE, key_type: str = EndpointKeyType.PRIMARY_KEY_TYPE
    ) -> Union[LROPoller[None], None]:
        """Regenerate keys for endpoint

        :param str endpoint_name: the endpoint name
        :param str type: the endpoint type. Defaults to ONLINE_ENDPOINT_TYPE.
        :param (str, optional) key_typer: one of primary, secondary. Defaults to primary.
        :return Union[EndpointAuthKeys]: depending on the auth mode in the endpoint, returns either keys or token
        """
        endpoint_type = self._validate_endpoint_type(endpoint_type=type)
        if endpoint_type == ONLINE_ENDPOINT_TYPE:
            endpoint = self._online_operation.get(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                endpoint_name=name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
            if endpoint.properties.auth_mode.lower() == "key":
                return self._regenerate_online_keys(name=name, key_type=key_type)
            else:
                raise Exception(f"Endpoint '{name}' does not use keys for authentication.")
        else:
            module_logger.info("Batch endpoint doesn't support regenerating keys")

    def update(
        self,
        endpoint: Endpoint,
        deployment: Deployment,
        local=False,
        no_wait=False,
    ) -> Union[BatchEndpoint, LROPoller[OnlineEndpointTrackedResource], OnlineEndpointTrackedResource]:
        """Update the endpoint

        :param Endpoint endpoint: the endpoint entity
        :param Deployment deployment: the deployment entity
        :param (bool, optional) no_wait: Defaults to False.
        :return Union[BatchEndpoint, None]: return batch endpoint entity if the type if backendpoint, otherwise none
        """
        if deployment:
            if endpoint.deployments:
                exist_deployment = next((d for d in endpoint.deployments if d.name == deployment.name), None)
                if exist_deployment:
                    exist_deployment._merge_with(other=deployment)
                else:
                    endpoint.deployments.append(deployment)
            else:
                endpoint.deployment = []
                endpoint.deployments.append(deployment)
        if local:
            if not isinstance(endpoint, OnlineEndpoint):
                raise TypeError(f"Expected OnlineEndpoint, {type(endpoint)} found.")
            return self._local_endpoint_helper.update(endpoint=endpoint)
        if isinstance(endpoint, OnlineEndpoint):
            old_endpoint = self._get_online_endpoint(name=endpoint.name)
            self._update_online_endpoint(old_endpoint=old_endpoint, new_endpoint=endpoint, no_wait=no_wait)
        elif isinstance(endpoint, BatchEndpoint):
            return self._create_or_update_batch_endpoint(endpoint=endpoint)
        else:
            raise Exception("The endpoint type is not supported")

    def invoke(
        self,
        endpoint_name: str,
        request_file: str = None,
        type: str = None,
        deployment_name: str = None,
        input_data: Union[str, Data] = None,
        local: bool = False,
        params_override=[],
        **kwargs,
    ) -> Union[str, BatchJobResource]:
        """Invokes the endpoint with the provided payload


        :param str endpoint_name: the endpoint name
        :param (str, optional) request_file: File containing the request payload. This is only valid for online endpoint.
        :param (str, optional) type: the endpoint type. Defaults to ONLINE_ENDPOINT_TYPE.
        :param (str, optional) deployment_name: Name of a specific deployment to invoke. This is optional. By default requests are routed to any of the deployments according to the traffic rules.
        :param (Union[str, Data], optional) input_data: To use a pre-registered data asset, pass str in format "<data-name>:<data-version>". To use new data asset, pass in a Data object, for batch endpoints only.
        :param (List, optional) params_override: Used to overwrite deployment configurations, for batch endpoints only.
        Returns:
            Union[str, BatchJobResource]: Prediction output for online endpoints or details of batch prediction job.
        """
        endpoint_type = self._validate_endpoint_type(endpoint_type=type)
        if endpoint_type == ONLINE_ENDPOINT_TYPE:
            with open(request_file, "rb") as f:
                data = json.loads(f.read())
            if local:
                return self._local_endpoint_helper.invoke(
                    endpoint_name=endpoint_name, data=data, deployment_name=deployment_name
                )
            return self._invoke_online_endpoint(endpoint_name=endpoint_name, data=data, deployment_name=deployment_name)
        else:
            return self._invoke_batch_endpoint(
                endpoint_name=endpoint_name,
                input_data=input_data,
                deployment_name=deployment_name,
                params_override=params_override,
            )

    def list_jobs(self, endpoint_name: str, type: str = BATCH_ENDPOINT_TYPE, deployment_name: str = None):
        """List jobs under the provided batch endpoint deployment. This is only valid for batch endpoint.


        :param str endpoint_name: the endpoint name
        :param (str, optional) type: the endpoint type. Defaults to BATCH_ENDPOINT_TYPE.
        :param (str, optional) deployment_name: Name of a specific deployment to invoke. This is optional. By default requests are routed to any of the deployments according to the traffic rules.
        :raise: Exception if type is not BATCH_ENDPOINT_TYPE
        :return: Iterable[BatchJobResourceArmPaginatedResult]
        """
        if type != BATCH_ENDPOINT_TYPE:
            raise Exception("Only batch endpoints support listing jobs.")

        mfe_base_uri = _get_mfe_base_url_from_batch_endpoint(self.get(endpoint_name, BATCH_ENDPOINT_TYPE))

        if not deployment_name:
            with modified_operation_client(self._batch_job_endpoint, mfe_base_uri):
                result = self._batch_job_endpoint.list(
                    endpoint_name=endpoint_name,
                    subscription_id=self._subscription_id,
                    resource_group_name=self._resource_group_name,
                    workspace_name=self._workspace_name,
                    api_version=API_VERSION_2020_09_01_DATAPLANE,
                    **self._init_kwargs,
                )

                # This is necessary as the paged result need to be resolved inside the context manager
                return list(result)
        else:
            with modified_operation_client(self._batch_job_deployment, mfe_base_uri):
                result = self._batch_job_deployment.list(
                    endpoint_name=endpoint_name,
                    deployment_name=deployment_name,
                    subscription_id=self._subscription_id,
                    resource_group_name=self._resource_group_name,
                    workspace_name=self._workspace_name,
                    api_version=API_VERSION_2020_09_01_DATAPLANE,
                    **self._init_kwargs,
                )

                # This is necessary as the paged result need to be resolved inside the context manager
                return list(result)

    def _invoke_online_endpoint(
        self,
        endpoint_name: str,
        data: str,
        deployment_name: str = None,
    ) -> str:
        endpoint = self._online_operation.get(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=endpoint_name,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )
        keys = self._get_online_credentials(name=endpoint_name, auth_mode=endpoint.properties.auth_mode)
        if isinstance(keys, EndpointAuthKeys):
            key = keys.primary_key
        elif isinstance(keys, EndpointAuthToken):
            key = keys.access_token
        else:
            key = ""
        headers = EndpointInvokeFields.DEFAULT_HEADER
        if key:
            headers[EndpointInvokeFields.AUTHORIZATION] = f"Bearer {key}"
        if deployment_name:
            headers[EndpointInvokeFields.MODEL_DEPLOYMENT] = deployment_name
        return requests.post(endpoint.properties.scoring_uri, json=data, headers=headers).text

    def _invoke_batch_endpoint(
        self,
        endpoint_name: str,
        input_data: Union[str, Data],
        deployment_name: str = None,
        params_override=[],
        **kwargs,
    ) -> BatchJobResource:

        if isinstance(input_data, str):
            name, version = parse_name_version(input_data)
            if name and version:
                input_data_id = generate_data_arm_id(self._workspace_scope, name, version)
            else:
                raise Exception(
                    'Input data needs to be in format "azureml:<data-name>:<data-version>" or "<data-name>:<data-version>"'
                )
        elif isinstance(input_data, Data):
            data_operations = self._all_operations.all_operations.get(AzureMLResourceType.DATA)

            # Since data was defined inline and it will be created, it will be registered as anonymous
            input_data._is_anonymous = True
            input_data_id = data_operations.create_or_update(input_data).id
        else:
            raise Exception(
                "Unsupported input data, please use either a string to reference a pre-registered data asset or a data object."
            )

        params_override.append({EndpointYamlFields.BATCH_JOB_DATASET: input_data_id})

        # Batch job doesn't have a python class, loading a rest object using params override
        context = {BASE_PATH_CONTEXT_KEY: Path(".").parent, PARAMS_OVERRIDE_KEY: params_override}

        batch_job = BatchJobSchema(context=context).load(data={})
        # update output datastore to arm id if needed
        # TODO: Unify datastore name -> arm id logic, TASK: 1104172
        if (
            batch_job.output_dataset
            and batch_job.output_dataset.datastore_id
            and (not is_ARM_id_for_resource(batch_job.output_dataset.datastore_id))
        ):
            batch_job.output_dataset.datastore_id = get_datastore_arm_id(
                batch_job.output_dataset.datastore_id, self._workspace_scope
            )

        mfe_base_uri = _get_mfe_base_url_from_batch_endpoint(self.get(endpoint_name, BATCH_ENDPOINT_TYPE))

        if deployment_name:
            with modified_operation_client(self._batch_job_deployment, mfe_base_uri):
                batch_job = self._batch_job_deployment.create(
                    endpoint_name,
                    deployment_name,
                    self._subscription_id,
                    self._resource_group_name,
                    self._workspace_name,
                    BatchJobResource(properties=batch_job),
                    API_VERSION_2020_09_01_DATAPLANE,
                    **self._init_kwargs,
                )
            return batch_job

        else:
            with modified_operation_client(self._batch_job_deployment, mfe_base_uri):
                return self._batch_job_endpoint.create(
                    endpoint_name,
                    self._subscription_id,
                    self._resource_group_name,
                    self._workspace_name,
                    BatchJobResource(properties=batch_job),
                    API_VERSION_2020_09_01_DATAPLANE,
                    **self._init_kwargs,
                )

    def _validate_endpoint_type(self, endpoint_type: str) -> str:
        if not endpoint_type or (
            endpoint_type.lower() != ONLINE_ENDPOINT_TYPE and endpoint_type.lower() != BATCH_ENDPOINT_TYPE
        ):
            raise Exception(
                f'Endpoint type needs to be set to either "{ONLINE_ENDPOINT_TYPE}" or "{BATCH_ENDPOINT_TYPE}", provided is {endpoint_type}'
            )
        return endpoint_type.lower()

    def _load_code_configuration(self, register_asset: bool, endpoint: Union[OnlineEndpoint, BatchEndpoint]):
        orchestrators = OperationOrchestrator(
            operation_container=self._all_operations, workspace_scope=self._workspace_scope
        )
        if isinstance(endpoint, K8sOnlineEndpoint):
            endpoint.target = orchestrators.get_asset_arm_id(
                endpoint.target, azureml_type=AzureMLResourceType.COMPUTE, register_asset=register_asset
            )
        # Online and batch deployments have different signature but code_configuration field is the same
        if endpoint.deployments:
            for deployment in endpoint.deployments:
                deployment.code_configuration = (
                    CodeConfiguration(
                        code=orchestrators.get_asset_arm_id(
                            deployment.code_configuration.code,
                            azureml_type=AzureMLResourceType.CODE,
                            register_asset=register_asset,
                        ),
                        scoring_script=deployment.code_configuration.scoring_script,
                    )
                    if deployment.code_configuration
                    else None
                )
                deployment.environment = orchestrators.get_asset_arm_id(
                    deployment.environment, azureml_type=AzureMLResourceType.ENVIRONMENT, register_asset=register_asset
                )
                if deployment.model:
                    deployment.model = orchestrators.get_asset_arm_id(
                        deployment.model, azureml_type=AzureMLResourceType.MODEL, register_asset=register_asset
                    )
                else:
                    deployment.model = None

                if isinstance(deployment, BatchDeployment):
                    if deployment.compute:
                        deployment.compute.target = orchestrators.get_asset_arm_id(
                            deployment.compute.target, azureml_type=AzureMLResourceType.COMPUTE
                        )
                        # deployment.batch_settings.compute_id = deployment.compute.target

    def _get_workspace_location(self) -> str:
        return self._all_operations.all_operations[AzureMLResourceType.WORKSPACE].get(self._workspace_name).location

    def _get_online_deployment_logs(
        self, endpoint_name: str, deployment_name: str, lines: int, container_type: Optional[str] = None
    ) -> str:
        if container_type:
            container_type = self._validate_deployment_log_container_type(container_type)
        log_request = DeploymentLogsRequest(container_type=container_type, tail=lines)
        return self._online_deployment.get_logs(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=endpoint_name,
            deployment_name=deployment_name,
            body=log_request,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        ).content

    def _validate_deployment_log_container_type(self, container_type: str) -> str:
        if container_type.lower() == EndpointDeploymentLogContainerType.INFERENCE_SERVER:
            return EndpointDeploymentLogContainerType.INFERENCE_SERVER_REST
        elif container_type.lower() == EndpointDeploymentLogContainerType.STORAGE_INITIALIZER:
            return EndpointDeploymentLogContainerType.STORAGE_INITIALIZER_REST
        else:
            raise Exception(f"Unknown deployment log container type {container_type}")

    def _create_online_endpoint(
        self,
        internal_endpoint: OnlineEndpoint,
        no_wait: bool = False,
    ) -> Optional[OnlineEndpoint]:

        # TODO: override the yaml settings by the input
        self._load_code_configuration(endpoint=internal_endpoint, register_asset=False)
        location = self._get_workspace_location()

        # first to check whether the endpoint exists
        try:
            old_endpoint = self._get_online_endpoint(internal_endpoint.name)
            if old_endpoint:
                module_logger.info(
                    f"The endpoint {internal_endpoint.name} already exists. You can't create it again.\n"
                )
                return old_endpoint
        except HttpResponseError as e:
            if e.status_code != HttpResponseStatusCode.NOT_FOUND:
                raise

        # generate online endpoint arm template
        arm_generator = OnlineEndpointArmGenerator(
            operation_container=self._all_operations, workspace_scope=self._workspace_scope
        )
        template, resources_being_deployed = arm_generator.generate_online_endpoint_template(
            workspace_name=self._workspace_name, location=location, old_endpoint=None, new_endpoint=internal_endpoint
        )

        arm_submit = ArmDeploymentExecutor(
            credentials=self._credentials,
            resource_group_name=self._resource_group_name,
            subscription_id=self._subscription_id,
            deployment_name=self._get_deployment_name(internal_endpoint.name),
        )

        arm_submit.deploy_resource(
            template=template, resources_being_deployed=resources_being_deployed, wait=not no_wait
        )

    def _get_deployment_name(self, name: str):
        random.seed(version=2)
        return f"{self._workspace_name}-{name}-{random.randint(1, 10000000)}"

    def _get_online_endpoint(self, name: str, include_deployments: bool = True) -> OnlineEndpoint:
        # first get the endpoint
        endpoint = self._online_operation.get(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )

        deployment_list = []
        if include_deployments:
            # fetch all the deployments belonging to the endpoint
            deployment_list = self._online_deployment.list(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                endpoint_name=name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
        return OnlineEndpoint._from_rest_object(endpoint, deployment_list)

    def _get_batch_endpoint(self, name: str) -> BatchEndpoint:
        # first get the endpoint
        endpoint = self._batch_operation.get(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )

        # fetch all the deployments belonging to the endpoint
        deploymentPagedResult = self._batch_deployment.list(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )
        endpoint_data = BatchEndpoint._from_rest_object(endpoint, deploymentPagedResult)
        return endpoint_data

    def _delete_online_endpoint(
        self, name: str, deployment: str = None, no_wait: bool = False
    ) -> Union[LROPoller[OnlineEndpointTrackedResource], LROPoller[None], None]:
        # Deleting a deployment is always a synchronous operation
        start_time = time.time()
        path_format_arguments = {
            "endpointName": name,
            "subscriptionId": self._subscription_id,
            "resourceGroupName": self._resource_group_name,
            "workspaceName": self._workspace_name,
        }

        endpoint = self._get_online_endpoint(name, include_deployments=False)
        if deployment:
            if endpoint.traffic and deployment in endpoint.traffic.keys() and endpoint.traffic[deployment] > 0:
                raise Exception(
                    f"The deployment {deployment} has live traffic. Can't be deleted. "
                    "Please scale down traffic to 0 first."
                )
            # Delete the specific deployment. This is a blocking operation and returns only
            # after the deployment was successfully deleted.
            self._delete_online_deployment(name, deployment, no_wait=False)
            # Remove the deployment from the exisitng traffic rules
            endpoint.traffic.pop(deployment, None)
            body = endpoint._to_rest_online_endpoint_traffic_update(endpoint.location, no_validation=True)
            # update the endpoint traffic rules that have the deployment removed
            poller = self._online_operation.begin_create_or_update(
                endpoint_name=name,
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                body=body,
                polling=AzureMLPolling(
                    OnlineEndpointConfigurations.POLL_INTERVAL,
                    lro_options={"final-state-via": "location"},
                    path_format_arguments=path_format_arguments,
                    **self._init_kwargs,
                )
                if not no_wait
                else False,
                **self._init_kwargs,
            )
            if no_wait:
                return poller
            else:
                message = "Update traffic"
                return polling_wait(poller=poller, start_time=start_time, message=message)

        deletePoller = self._online_operation.begin_delete(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            polling=AzureMLPolling(
                OnlineEndpointConfigurations.POLL_INTERVAL,
                lro_options={"final-state-via": "location"},
                path_format_arguments=path_format_arguments,
                **self._init_kwargs,
            )
            if not no_wait
            else False,
            polling_interval=OnlineEndpointConfigurations.POLL_INTERVAL,
            **self._init_kwargs,
        )
        if no_wait:
            module_logger.info(
                f"Delete request initiated. Status can be checked using `az ml endpoint show -n {name}`\n"
            )
            return deletePoller
        else:
            message = f"Deleting endpoint {name} "
            polling_wait(poller=deletePoller, start_time=start_time, message=message)

    def _delete_online_deployment(
        self, name: str, deployment: str, no_wait: bool = False
    ) -> Union[LROPoller[None], None]:
        module_logger.info(f"Deleting the endpoint {name}'s deployment {deployment}\n")
        path_format_arguments = {
            "endpointName": name,
            "deploymentName": deployment,
            "subscriptionId": self._subscription_id,
            "resourceGroupName": self._resource_group_name,
            "workspaceName": self._workspace_name,
        }
        poller = self._online_deployment.begin_delete(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            deployment_name=deployment,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            polling=AzureMLPolling(
                OnlineEndpointConfigurations.POLL_INTERVAL,
                lro_options={"final-state-via": "location"},
                path_format_arguments=path_format_arguments,
                **self._init_kwargs,
            )
            if not no_wait
            else False,
            **self._init_kwargs,
        )
        if no_wait:
            module_logger.info(f"\nSuccessfully sent deletion request for {deployment}.\n")
            return poller
        else:
            message = f"Delete {deployment}"
            return polling_wait(poller=poller, message=message, start_time=None)

    def _delete_batch_endpoint(self, name: str, deployment: str = None):
        # Deleting batch endpoint/deployment is a synchronous operation
        if deployment:
            self._delete_batch_deployment(name=name, deployment=deployment)
        else:
            module_logger.info(f"Deleting batch endpoint {name}.")
            endpoint = self._get_batch_endpoint(name)
            for d in endpoint.deployments:
                self._delete_batch_deployment(name=name, deployment=d.name)

            self._batch_operation.delete(
                endpoint_name=name,
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )

    def _delete_batch_deployment(self, name: str, deployment: str) -> None:
        module_logger.info(f"Deleting the batch endpoint {name}'s deployment {deployment}.")
        self._batch_deployment.delete(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            deployment_name=deployment,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )

        module_logger.info(f"Successfully deleted {deployment}.")

    def _create_or_update_batch_endpoint(self, endpoint: BatchEndpoint) -> BatchEndpoint:

        self._load_code_configuration(endpoint=endpoint, register_asset=True)
        location = self._get_workspace_location()
        # create the endpoint
        endpoint_resource = endpoint._to_rest_batch_endpoint(location)
        self._batch_operation.create_or_update(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=endpoint.name,
            body=endpoint_resource,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
            # enforce_https=False,
        )

        for deployment in endpoint.deployments:
            deployment_rest = deployment._to_rest_obj(location=location)
            self._batch_deployment.create_or_update(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                endpoint_name=endpoint.name,
                deployment_name=deployment.name,
                body=deployment_rest,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )

        # set the traffic
        endpoint_resource = endpoint._to_rest_batch_endpoint_with_traffic(location)
        self._batch_operation.create_or_update(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=endpoint.name,
            body=endpoint_resource,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )
        return self.get(name=endpoint.name, type=BATCH_ENDPOINT_TYPE)  # TODO: why get here?

    def _get_online_credentials(self, name: str, auth_mode: str = None) -> Union[EndpointAuthKeys, EndpointAuthToken]:
        if not auth_mode:
            endpoint = self._online_operation.get(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                endpoint_name=name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
            auth_mode = endpoint.properties.auth_mode
        if auth_mode.lower() == KEY:
            return self._online_operation.list_keys(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                endpoint_name=name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
        else:
            return self._online_operation.get_token(
                subscription_id=self._subscription_id,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                endpoint_name=name,
                api_version=API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )

    def _update_online_endpoint(
        self, old_endpoint: OnlineEndpoint, new_endpoint: OnlineEndpoint, no_wait: bool = False
    ) -> None:
        # First preprocess new endpoint data.
        self._load_code_configuration(endpoint=new_endpoint, register_asset=False)
        orchestrators = OperationOrchestrator(
            operation_container=self._all_operations, workspace_scope=self._workspace_scope
        )
        # reset duplicate resources for the new endpoint
        orchestrators.reset_duplicate_resources(old_endpoint=old_endpoint, new_endpoint=new_endpoint)

        # validate the updates
        validator = EndpointValidator()
        validator.validate_updates(old_endpoint=old_endpoint, new_endpoint=new_endpoint)
        # handle delete first
        self._process_delete(old_endpoint=old_endpoint, new_endpoint=new_endpoint)
        # for update, if traffic rules is not set for the deployment, cli needs to set it to zero. Otherwise DP will throw exception
        if not old_endpoint.traffic:
            old_endpoint.traffic = {}
        if old_endpoint.deployments:
            for deployment in {d.name for d in old_endpoint.deployments}:
                if deployment not in old_endpoint.traffic:
                    old_endpoint.traffic[deployment] = 0

        # generate online endpoint arm template
        arm_generator = OnlineEndpointArmGenerator(
            operation_container=self._all_operations, workspace_scope=self._workspace_scope
        )
        template, resources_being_deployed = arm_generator.generate_online_endpoint_template(
            workspace_name=self._workspace_name,
            location=old_endpoint.location,
            old_endpoint=old_endpoint,
            new_endpoint=new_endpoint,
        )
        if template and resources_being_deployed:
            arm_submit = ArmDeploymentExecutor(
                credentials=self._credentials,
                resource_group_name=self._resource_group_name,
                subscription_id=self._subscription_id,
                deployment_name=self._get_deployment_name(new_endpoint.name),
            )
            arm_submit.deploy_resource(
                template=template, resources_being_deployed=resources_being_deployed, wait=not no_wait
            )

    def _process_delete(self, old_endpoint: OnlineEndpoint, new_endpoint: OnlineEndpoint) -> None:
        validate_deployment_name_matches_traffic(deployments=new_endpoint.deployments, traffic=new_endpoint.traffic)
        deployments_to_remove = {d.name for d in old_endpoint.deployments} - {d.name for d in new_endpoint.deployments}
        for deployment in deployments_to_remove:
            if deployment in old_endpoint.traffic and old_endpoint.traffic[deployment] > 0:
                raise Exception(
                    f"deployment {deployment} has live traffic and not allowed to be deleted."
                    "Please scale down the traffic to zero first."
                )
        for deployment in deployments_to_remove:
            # TODO: Change to call delete by passing the deployment name
            module_logger.info(f"deployment {deployment} will be deleted.\n")
            self._delete_online_deployment(name=old_endpoint.name, deployment=deployment, no_wait=False)
            if deployment in old_endpoint.traffic:
                old_endpoint.traffic.pop(deployment)
        old_endpoint.deployments = [d for d in old_endpoint.deployments if d.name not in deployments_to_remove]

    def _regenerate_online_keys(
        self, name: str, key_type: str = EndpointKeyType.PRIMARY_KEY_TYPE, no_wait: bool = False
    ) -> Union[LROPoller[None], None]:
        keys = self._online_operation.list_keys(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )
        if key_type.lower() == EndpointKeyType.PRIMARY_KEY_TYPE:
            key_request = RegenerateEndpointKeysRequest(key_type=KeyType.Primary, key_value=keys.primary_key)
        elif key_type.lower() == EndpointKeyType.SECONDARY_KEY_TYPE:
            key_request = RegenerateEndpointKeysRequest(key_type=KeyType.Secondary, key_value=keys.secondary_key)
        else:
            raise Exception("Key type must be 'primary' or 'secondary'.")

        poller = self._online_operation.begin_regenerate_keys(
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=name,
            body=key_request,
            api_version=API_VERSION_2021_03_01_PREVIEW,
            **self._init_kwargs,
        )
        if not no_wait:
            return polling_wait(poller=poller, message="regenerate key")

        return poller
