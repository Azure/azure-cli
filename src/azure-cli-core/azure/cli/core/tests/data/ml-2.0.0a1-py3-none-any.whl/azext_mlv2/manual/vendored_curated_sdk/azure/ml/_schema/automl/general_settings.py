# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import GeneralSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    TaskType,
    OptimizationMetric,
)


class AutoMLGeneralSettingsSchema(metaclass=PatchedSchemaMeta):
    task_type = StringTransformedEnum(
        allowed_values=[t.value for t in TaskType], required=True, data_key=AutoMLConstants.TASK_TYPE_YAML
    )
    primary_metric = StringTransformedEnum(allowed_values=[o.value for o in OptimizationMetric])
    enable_model_explainability = fields.Bool()

    @post_load
    def make(self, data, **kwargs):
        return GeneralSettings(**data)
