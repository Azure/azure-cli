# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import json
from typing import Any, Optional, Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import ComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType, JobComputeProperityFields
from marshmallow import ValidationError, fields, post_load, validates_schema

from .fields import ArmStr, StringTransformedEnum, UnionField
from .schema import PatchedSchemaMeta

module_logger = logging.getLogger(__name__)

LOCAL_TARGET = "local"


class InternalComputeConfiguration:
    def __init__(
        self,
        target: str = None,
        instance_count: int = None,
        is_local: bool = None,
        instance_type: str = None,
        location: str = None,
        properties: Dict[str, Any] = None,
        deserialize_properties: bool = False,
    ):
        self.instance_count = instance_count
        self.target = target or LOCAL_TARGET
        self.is_local = is_local or self.target == LOCAL_TARGET
        self.instance_type = instance_type
        self.location = location
        self.properties = properties
        if deserialize_properties and properties:
            for key, value in properties.items():
                try:
                    self.properties[key] = json.loads(value)
                except Exception:
                    # keep serialized string if load fails
                    pass

    def dump_to_rest(self) -> ComputeConfiguration:
        serialized_properties = {} if self.properties else None
        if self.properties:
            for key, value in self.properties.items():
                try:
                    # Ensure keymatch is case invariant
                    if key.lower() == JobComputeProperityFields.AISUPERCOMPUTER.lower():
                        key = JobComputeProperityFields.AISUPERCOMPUTER
                    serialized_properties[key] = json.dumps(value)
                except Exception:
                    pass
        return ComputeConfiguration(
            target=self.target if not self.is_local else None,
            is_local=self.is_local,
            instance_count=self.instance_count,
            instance_type=self.instance_type,
            location=self.location,
            properties=serialized_properties,
        )

    def __eq__(self, other: "InternalComputeConfiguration") -> bool:
        return (
            self.instance_count == other.instance_count
            and self.target == other.target
            and self.is_local == other.is_local
            and self.location == other.location
            and self.instance_type == other.instance_type
        )

    def __ne__(self, other: "InternalComputeConfiguration") -> bool:
        return not self.__eq__(other)


class ComputeBindingSchema(metaclass=PatchedSchemaMeta):
    target = UnionField(
        [
            StringTransformedEnum(allowed_values=[LOCAL_TARGET]),
            ArmStr(azureml_type=AzureMLResourceType.COMPUTE),
            # Case for virtual clusters
            fields.Str(),
        ]
    )
    instance_count = fields.Integer()
    instance_type = fields.Str(metadata={"description": "The instance type to make availabel to this job."})
    location = fields.Str(metadata={"description": "The locations where this job may run."})
    properties = fields.Dict(keys=fields.Str())

    @validates_schema
    def validate(self, data: Any, **kwargs):
        if data.get("target") == LOCAL_TARGET and data.get("instance_count", 1) != 1:
            raise ValidationError("Local runs must have node count of 1.")

    @post_load
    def make(self, data, **kwargs) -> ComputeConfiguration:
        return InternalComputeConfiguration(**data)
