# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any, Dict, List, Optional, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    BatchDeployment as RestBatchDeployment,
    BatchDeploymentTrackedResource,
    CodeConfiguration as RestCodeConfiguration,
    IdAssetReference,
    BatchOutputConfiguration,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BATCH_ENDPOINT_TYPE
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.endpoint.deployment_settings import BatchRetrySettings

from .code_configuration import CodeConfiguration
from .deployment import Deployment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Model, Environment

module_logger = logging.getLogger(__name__)


class BatchDeployment(Deployment):
    """Batch endpoint deployment entity

    :param name: the name of the batch deployment
    :type name: str
    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param type:  Type of the job, supported are 'online' and 'batch'.
    :type type: str, optional
    :param tags: Internal use only.
    :type tags: Dict[str, Any], optional
    :param properties: Property dictionary. Properties can be added, but not removed or altered.
    :type properties: dict[str, str]
    :param model: Model entity for the endpoint deployment, defaults to None
    :type model: Union[str, Model], optional
    :param code_configuration: defaults to None
    :type code_configuration: CodeConfiguration, optional
    :param environment: Environment entity for the endpoint deployment., defaults to None
    :type environment: Union[str, Environment], optional
    :param compute: Reference to compute entity, defaults to None
    :type compute: InternalComputeBinding, optional
    :param output_file_name: Output file name of the prediction result. defaults to None
    :type output_file_name: str, optional
    :param error_threshold: Error threshold, if the error count for the entire input goes above
        this value,
        the batch inference will be aborted. Range is [-1, int.MaxValue]
        -1 value indicates, ignore all failures during batch inference
        For FileDataset count of file failures
        For TabularDataset, this is the count of record failures, defaults to None
    :type error_threshold: int, optional
    :param retry_settings: Retry settings for a batch inference operation, defaults to None
    :type retry_settings: BatchRetrySettings, optional
    :param logging_level: Logging level for batch inference operation, defaults to None
    :type logging_level: str, optional
    :param mini_batch_size: Size of the mini-batch passed to each batch invocation.
    :type mini_batch_size: int, optional
    :param partition_keys: Partition keys list used for Named partitioning
    :type partition_keys: List[str], optional
    :param environment_variables: Environment variables that will be set in deployment.
    :type environment_variables: dict, optional
    """

    def __init__(
        self,
        name: str,
        base_path: Optional[str] = None,
        id: str = None,
        type: str = BATCH_ENDPOINT_TYPE,
        tags: Dict[str, Any] = None,
        properties: Dict[str, str] = None,
        model: Union[str, Model] = None,
        code_configuration: CodeConfiguration = None,
        environment: Union[str, Environment] = None,
        compute: InternalComputeConfiguration = None,
        output_file_name: str = None,
        error_threshold: int = None,
        retry_settings: BatchRetrySettings = None,
        logging_level: str = None,
        partition_keys: List[str] = None,
        mini_batch_size: int = None,
        environment_variables: Dict[str, str] = None,
    ) -> None:

        super(BatchDeployment, self).__init__(
            name=name,
            id=id,
            type=type,
            properties=properties,
            tags=tags,
            model=model,
            code_configuration=code_configuration,
            environment=environment,
            environment_variables=environment_variables,
        )

        self.compute = compute
        self.output_file_name = output_file_name
        self.error_threshold = error_threshold
        self.retry_settings = retry_settings
        self.logging_level = logging_level
        self.partition_keys = partition_keys
        self.mini_batch_size = mini_batch_size

    def _to_rest_obj(self, location: str) -> BatchDeploymentTrackedResource:
        code_config = (
            RestCodeConfiguration(
                code_id=self.code_configuration.code, scoring_script=self.code_configuration.scoring_script
            )
            if self.code_configuration
            else None
        )
        model = IdAssetReference(asset_id=self.model) if self.model else None
        environment = self.environment

        batch_deployment = RestBatchDeployment(
            compute=self.compute.dump_to_rest(),
            code_configuration=code_config,
            environment_id=environment,
            model=model,
            output_configuration=BatchOutputConfiguration(append_row_file_name=self.output_file_name)
            if self.output_file_name
            else None,
            error_threshold=self.error_threshold,
            retry_settings=self.retry_settings._to_rest_object() if self.retry_settings else None,
            logging_level=self.logging_level,
            partition_keys=self.partition_keys,
            mini_batch_size=self.mini_batch_size,
            environment_variables=self.environment_variables,
        )

        return BatchDeploymentTrackedResource(location=location, properties=batch_deployment, tags=self.tags)

    @classmethod
    def _from_rest_obj(cls, deployment: BatchDeploymentTrackedResource):

        modelId = deployment.properties.model.asset_id if deployment.properties.model else None
        code_configuration = (
            CodeConfiguration._from_rest_code_configuration(deployment.properties.code_configuration)
            if deployment.properties.code_configuration
            else None
        )

        return BatchDeployment(
            name=deployment.name,
            id=deployment.id,
            type=deployment.type,
            tags=deployment.tags,
            model=modelId,
            environment=deployment.properties.environment_id,
            code_configuration=code_configuration,
            output_file_name=deployment.properties.output_configuration.append_row_file_name
            if deployment.properties.output_configuration
            else None,
            error_threshold=deployment.properties.error_threshold,
            retry_settings=BatchRetrySettings._from_rest_object(deployment.properties.retry_settings),
            logging_level=deployment.properties.logging_level,
            partition_keys=deployment.properties.partition_keys,
            mini_batch_size=deployment.properties.mini_batch_size,
            compute=InternalComputeConfiguration(
                target=deployment.properties.compute.target,
                instance_count=deployment.properties.compute.instance_count,
            ),
            environment_variables=deployment.properties.environment_variables,
        )

    def _merge_with(self, other: "BatchDeployment") -> None:
        if other:
            super()._merge_with(other)
            self.mini_batch_size = other.mini_batch_size or self.mini_batch_size
            self.logging_level = other.logging_level or self.logging_level
            self.partition_keys = other.partition_keys or self.partition_keys
            self.error_threshold = other.error_threshold or self.error_threshold
            self.compute = other.compute or self.compute
            self.output_file_name = self.output_file_name or other.output_file_name
            if self.retry_settings:
                self.retry_settings = self.retry_settings._merge_with(other.retry_settings)
            else:
                self.retry_settings = other.retry_settings
