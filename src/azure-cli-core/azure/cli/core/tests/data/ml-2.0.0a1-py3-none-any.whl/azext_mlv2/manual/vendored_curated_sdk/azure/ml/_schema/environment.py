# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from pathlib import Path

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    OperatingSystemType,
    Route,
    InferenceContainerProperties,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PatchedSchemaMeta, UnionField, YamlFileSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.asset import AnonymousAssetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.creation_context import CreationContextSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType
from marshmallow import ValidationError, fields, post_load, pre_dump, pre_load

from .fields import ArmStr, FileRefField, StringTransformedEnum

module_logger = logging.getLogger(__name__)


class DockerBuildSchema(metaclass=PatchedSchemaMeta):
    dockerfile = UnionField([FileRefField(), fields.Str()])

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets.environment import _DockerBuild

        return _DockerBuild(**data)


class DockerSchema(metaclass=PatchedSchemaMeta):
    image = fields.Str()
    build = NestedField(DockerBuildSchema)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets.environment import _DockerConfiguration

        return _DockerConfiguration(**data)


class RouteSchema(metaclass=PatchedSchemaMeta):
    port = fields.Int(required=True)
    path = fields.Str(required=True)

    @post_load
    def make(self, data, **kwargs):
        return Route(**data)


class InferenceConfigSchema(metaclass=PatchedSchemaMeta):
    liveness_route = NestedField(RouteSchema, required=True)
    scoring_route = NestedField(RouteSchema, required=True)
    readiness_route = NestedField(RouteSchema, required=True)

    @post_load
    def make(self, data, **kwargs):
        return InferenceContainerProperties(**data)


class EnvironmentSchema(YamlFileSchema):
    docker = NestedField(DockerSchema)
    conda_file = UnionField([FileRefField(), fields.Str()])
    name = fields.Str()
    version = fields.Int()
    path = fields.Str()
    tags = fields.Dict(keys=fields.Str(), values=fields.Str())
    description = fields.Str()
    creation_context = NestedField(CreationContextSchema, dump_only=True)
    id = ArmStr(azureml_type=AzureMLResourceType.ENVIRONMENT, dump_only=True)
    inference_config = NestedField(InferenceConfigSchema)
    os_type = StringTransformedEnum(
        allowed_values=[OperatingSystemType.Linux, OperatingSystemType.Windows], required=False
    )

    def __init__(self, *args, **kwargs):
        self._previous_base_path = None
        super().__init__(*args, **kwargs)

    @pre_load
    def pre_load(self, data, **kwargs):
        if isinstance(data, str):
            raise ValidationError("Environment schema data cannot be a string")
        self._previous_base_path = Path(self.context[BASE_PATH_CONTEXT_KEY])
        path = data.get("path", None)
        if path:
            self.context[BASE_PATH_CONTEXT_KEY] = Path(self._previous_base_path, path).resolve()
        return data

    @pre_dump
    def validate(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Environment

        if isinstance(data, Environment):
            return data
        if data is None or not hasattr(data, "get"):
            raise ValidationError("Environment cannot be None")
        return data

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Environment

        if self._previous_base_path:
            self.context[BASE_PATH_CONTEXT_KEY] = self._previous_base_path
        return Environment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class AnonymousEnvironmentSchema(EnvironmentSchema, AnonymousAssetSchema):
    # This is just a subclass of the two parents; it has no additional implementation
    # Necessary methods are provided by parents.
    pass
