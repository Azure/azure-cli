# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from abc import ABC
from os import PathLike
from pathlib import Path
from typing import Any, Dict, Optional, Union

from .code_configuration import CodeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.online.online_deployment import (
    K8sOnlineDeploymentSchema,
    ManagedOnlineDeploymentSchema,
    OnlineDeploymentSchema,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.batch.batch_deployment import BatchDeploymentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BASE_PATH_CONTEXT_KEY,
    BATCH_ENDPOINT_TYPE,
    DeploymentType,
    ONLINE_ENDPOINT_TYPE,
    PARAMS_OVERRIDE_KEY,
    CommonYamlFields,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import find_type_in_override
from marshmallow.utils import RAISE
from marshmallow.exceptions import ValidationError


module_logger = logging.getLogger(__name__)


class Deployment(ABC):
    """Endpoint Deployment base class.

    :param base_path: TBD
    :type base_path: Optional[str], optional
    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param type:  Type of the job, supported are 'command' and 'sweep'. #TODO: need to update
    :type type: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param model: the Model entity, defaults to None
    :type model: Union[str, Model], optional
    :param code_configuration: the CodeConfiguration entity, defaults to None
    :type code_configuration: CodeConfiguration, optional
    :param environment: the Environment entity, defaults to None
    :type environment: Union[str, Environment], optional
    :param environment_variables: Environment variables that will be set in deployment.
    :type environment_variables: dict, optional
    """

    def __init__(
        self,
        base_path: Optional[str] = None,
        id: str = None,
        name: str = None,
        type: str = None,
        tags: Dict[str, Any] = None,
        properties: Dict[str, Any] = None,
        model: Union[str, "Model"] = None,
        code_configuration: CodeConfiguration = None,
        environment: Union[str, "Environment"] = None,
        environment_variables: Dict[str, str] = None,
    ):
        # MFE is case-insensitive for Name. So convert the name into lower case here.
        self.name = name.lower()
        self.id = id
        self.tags = dict(tags) if tags else {}
        self.properties = dict(properties) if properties else {}
        self.type = type
        self.model = model
        self.code_configuration = code_configuration
        self.environment = environment
        self.environment_variables = dict(environment_variables) if environment_variables else {}

    @classmethod
    def load(
        cls,
        path: Union[PathLike, str],
        params_override: list = [],
    ) -> "Deployment":
        context = {
            BASE_PATH_CONTEXT_KEY: Path(path).parent if path else Path.cwd(),
            PARAMS_OVERRIDE_KEY: params_override,
        }
        yaml_dict = load_yaml(path)
        type_in_override = find_type_in_override(params_override)
        type = type_in_override or yaml_dict.get(CommonYamlFields.TYPE, None)
        type_to_cls = {
            DeploymentType.K8S: K8sOnlineDeploymentSchema,
            DeploymentType.MANAGED: ManagedOnlineDeploymentSchema,
            BATCH_ENDPOINT_TYPE: BatchDeploymentSchema,
        }
        if not type:
            try:
                return BatchDeploymentSchema(context=context).load(yaml_dict, unknown=RAISE)
            except ValidationError:
                return ManagedOnlineDeploymentSchema(context=context).load(yaml_dict, unknown=RAISE)
        else:
            return type_to_cls[type](context=context).load(yaml_dict, unknown=RAISE)

    def dump(self, path: Union[PathLike, str]) -> None:
        pass

    def _merge_with(self, other: "Deployment") -> None:
        if other:
            if self.name != other.name:
                raise Exception(f"The deployment name: {self.name} and {other.name} are not matched when combining.")
            if other.tags:
                self.tags = {**self.tags, **other.tags}
            if other.properties:
                self.properties = {**self.properties, **other.properties}
            if other.environment_variables:
                self.environment_variables = {**self.environment_variables, **other.environment_variables}
            self.code_configuration = other.code_configuration or self.code_configuration
            self.model = other.model or self.model
            self.environment = other.environment or self.environment
