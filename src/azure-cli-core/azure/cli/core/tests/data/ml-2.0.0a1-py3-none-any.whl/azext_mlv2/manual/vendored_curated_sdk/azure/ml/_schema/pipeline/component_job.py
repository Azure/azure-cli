# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, UnionField, ArmVersionedStr, PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import ComputeBindingSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import InputEntrySchema, OutputEntrySchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component import AnonymousCommandComponentSchema, ComponentFileRefField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.pipeline.component_job import ComponentJob
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.pipeline.pipeline_job_io import OutputBindingStr

module_logger = logging.getLogger(__name__)


class ComponentJobSchema(metaclass=PatchedSchemaMeta):
    type = fields.Str()
    inputs = fields.Dict(
        keys=fields.Str(),
        values=UnionField([fields.Str(), fields.Bool(), fields.Int(), fields.Float(), NestedField(InputEntrySchema)]),
    )
    outputs = fields.Dict(keys=fields.Str(), values=UnionField([OutputBindingStr, NestedField(OutputEntrySchema)]))
    component = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.COMPONENT),
            NestedField(AnonymousCommandComponentSchema),
            ComponentFileRefField,
        ]
    )
    compute = NestedField(ComputeBindingSchema())

    @post_load
    def make(self, data, **kwargs) -> ComponentJob:
        return ComponentJob(**data)
