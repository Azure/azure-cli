# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict, Optional, Union, Any
from pathlib import Path
from os import PathLike

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Artifact
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BASE_PATH_CONTEXT_KEY,
    PARAMS_OVERRIDE_KEY,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    ModelVersionResource,
    ModelVersion,
    ModelContainerResource,
    SystemData,
    FlavorData,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import ModelSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import AMLVersionedArmId, AMLNamedArmId
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict


class Model(Artifact):
    """Model for training and scoring.

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param version: Version of the resource.
    :type version: int
    :param local_path: The local path to the asset.
    :type local_path: Union[str, os.PathLike]
    :param utc_time_created: Date and time when the model was created, in
        UTC ISO 8601 format. (e.g. '2020-10-19 17:44:02.096572')
    :type utc_time_created: str
    :param flavors: The flavors in which the model can be interpreted.
        (e.g. {sklearn: {sklearn_version: 0.23.2}, python_function: {loader_module: office.plrmodel, python_version: 3.6})
    :type flavors: Dict[str, Any]
    :param datastore: Azure Resource Manager ID of the datastore where the asset is stored.
    :type datastore: str
    :param path: The remote path to the asset on the datastore.
    :type path: str
    :param base_path: TBD.
    :type base_path: str
    :param description: Description of the resource.
    :type description: str
    :param creation_context: Creation metadata of the asset.
    :type creation_context: SystemData
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    def __init__(
        self,
        name: str = None,
        id: str = None,
        version: int = None,
        local_path: Optional[Union[str, PathLike]] = None,
        utc_time_created: str = None,
        flavors: Dict[str, Dict[str, Any]] = {},
        datastore: str = None,
        path: str = None,
        description: str = None,
        creation_context: SystemData = None,
        tags: Dict = None,
        properties: Dict = None,
        base_path: str = None,
        **kwargs,
    ):
        super().__init__(
            name=name,
            id=id,
            version=version,
            path=path,
            local_path=local_path,
            datastore=datastore,
            description=description,
            creation_context=creation_context,
            tags=tags,
            properties=properties,
            base_path=base_path,
            **kwargs,
        )

        self.utc_time_created = utc_time_created
        self.flavors = flavors

    @classmethod
    def load(
        cls,
        path: Union[PathLike, str],
        params_override: list = None,
        **kwargs,
    ) -> "Model":
        """Construct a model object from yaml file.

        :param path: Path to a local file as the source.
        :type path: str
        :param params_override: Fields to overwrite on top of the yaml file. Format is [{"field1": "value1"}, {"field2": "value2"}]
        :type params_override: list

        :return: Constructed model object.
        :rtype: Model
        """
        yaml_dict = load_yaml(path)
        return cls._load(data=yaml_dict, yaml_path=path, params_override=params_override, **kwargs)

    @classmethod
    def _load(
        cls,
        data: Dict = {},
        yaml_path: Union[PathLike, str] = None,
        params_override: list = [],
        **kwargs,
    ) -> "Model":
        context = {
            BASE_PATH_CONTEXT_KEY: Path(yaml_path).parent if yaml_path else Path("./"),
            PARAMS_OVERRIDE_KEY: params_override,
        }
        return load_from_dict(ModelSchema, data, context, **kwargs)

    def _dump_yaml(self) -> Dict:
        return ModelSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    @classmethod
    def _from_rest_object(cls, model_rest_object: ModelVersionResource) -> "Model":
        rest_model_version = model_rest_object.properties
        arm_id = AMLVersionedArmId(arm_id=model_rest_object.id)
        flavors = {key: flavor.data for key, flavor in rest_model_version.flavors.items()}
        model = Model(
            id=model_rest_object.id,
            name=arm_id.asset_name,
            version=int(arm_id.asset_version),
            path=rest_model_version.path,
            description=rest_model_version.description,
            tags=rest_model_version.tags,
            flavors=flavors,
            datastore=rest_model_version.datastore_id,
            properties=rest_model_version.properties,
            creation_context=model_rest_object.system_data,
        )
        return model

    @classmethod
    def _from_container_rest_object(cls, model_container_rest_object: ModelContainerResource) -> "Model":
        model = Model(
            name=model_container_rest_object.name,
            version=1,
            id=model_container_rest_object.id,
            creation_context=model_container_rest_object.system_data,
        )

        # Setting version to None since while asset creation if version is not provided
        # it is defaulted to 1 and is required to be int. This should go away once container
        # concept is finalized
        model.version = None
        return model

    def _to_rest_object(self) -> ModelVersionResource:
        model_version = ModelVersion(
            description=self.description,
            tags=self.tags,
            flavors={
                key: FlavorData(data=dict(value)) for key, value in self.flavors.items()
            },  # flatten OrderedDict to dict
            datastore_id=self.datastore,
            path=self.path,
        )
        model_version_resource = ModelVersionResource(properties=model_version)

        return model_version_resource
