# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_code_help():
    helps[
        "ml code"
    ] = """
        type: group
        short-summary: Manage Azure ML code assets.
        long-summary: >
            Azure ML code assets are references to code file(s) in storage.
            Code assets are created automatically when you submit training jobs
            or deploy a model for inference.
    """
    helps[
        "ml code show"
    ] = """
        type: command
        short-summary: Show details for a code asset.
        examples:
        - name: Show details for a code asset with the specified name and version
          text: az ml code show --name my-code --version 1 --resource-group my-resource-group --workspace-name my-workspace
    """
