# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import re
from typing import Dict, Any
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._sweep.sweep_job import SweepJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import (
    to_iso_duration_format_mins,
    from_iso_duration_format_mins,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BASE_PATH_CONTEXT_KEY,
    TYPE,
    JobType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    CodeConfiguration as RestCodeConfiguration,
    EarlyTerminationPolicy,
    Objective,
    SweepJob as RestSweepJob,
    JobBaseResource,
    TrialComponent,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Job, ParameterizedCommand
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict
from .search_space import SweepDistribution

module_logger = logging.getLogger(__name__)


class SweepJob(Job):
    """Sweep job for hyperparameter tuning.

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param description: Description of the resource.
    :type description: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param base_path: TBD.
    :type base_path: str
    :param experiment_name:  Name of the experiment the job will be created under, if None is provided, job will be created under experiment 'Default'.
    :type experiment_name: str
    :param status: Status of the job.
    :type status: str
    :param creation_context: Creation metadata of the job.
    :type creation_context: SystemData
    :param interaction_endpoints: Infomation on how to interact with the job.
    :type interaction_endpoints: dict[str, JobEndpoint]
    :param algorithm: Algorithm to use to find the optimal hyper parameters.
    :type algorithm: str
    :param search_space: Range of parameters.
    :type search_space: Dict
    :param objective: Metric to optimize for.
    :type objective: Objective
    :param trial: Training command and configurations.
    :type trial: ParameterizedCommand
    :param early_termination: Condition to terminate the training early.
    :type early_termination: EarlyTerminationPolicy
    :param max_concurrent_trials: Maximum number of trials to run at once.
    :type max_concurrent_trials: int
    :param max_total_trials: Maximum number of trial runs.
    :type max_total_trials: int
    :param timeout_minutes: Maximum time to run.
    :type timeout_minutes: int
    :param output: Location of job output and logs in storage.
    :type output: OutputDataset
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    # Swept parameters are sent to HD as environment variables, and this the
    # swept parameter environment variable prefix that HD supports.
    AZUREML_SWEEP_PREFIX = "$AZUREML_SWEEP_"

    def __init__(
        self,
        algorithm: str = None,
        search_space: Dict[str, SweepDistribution] = None,
        objective: Objective = None,
        trial: ParameterizedCommand = None,
        early_termination: EarlyTerminationPolicy = None,
        max_concurrent_trials: int = None,
        max_total_trials: int = None,
        timeout_minutes: int = None,
        **kwargs: Any
    ):
        kwargs[TYPE] = JobType.SWEEP
        super().__init__(**kwargs)
        self._algorithm = algorithm
        self._search_space = search_space
        self._objective = objective
        self._trial = trial
        self._early_termination = early_termination
        self.job_type = JobType.SWEEP
        self._max_concurrent_trials = max_concurrent_trials
        self._max_total_trials = max_total_trials
        self._timeout_minutes = timeout_minutes

    @property
    def algorithm(self) -> str:
        return self._algorithm

    @algorithm.setter
    def algorithm(self, value: str) -> None:
        self._algorithm = value

    @property
    def search_space(self) -> Dict[str, SweepDistribution]:
        return self._search_space

    @search_space.setter
    def search_space(self, value: Dict[str, SweepDistribution]) -> None:
        self._search_space = value

    @property
    def objective(self) -> Objective:
        return self._objective

    @objective.setter
    def objective(self, value: Objective) -> None:
        self._objective = value

    @property
    def trial(self) -> ParameterizedCommand:
        return self._trial

    @trial.setter
    def trial(self, value: ParameterizedCommand) -> None:
        self._trial = value

    @property
    def early_termination(self) -> EarlyTerminationPolicy:
        return self._early_termination

    @early_termination.setter
    def early_termination(self, value: EarlyTerminationPolicy) -> None:
        self._early_termination = value

    @property
    def max_concurrent_trials(self) -> int:
        return self._max_concurrent_trials

    @max_concurrent_trials.setter
    def max_concurrent_trials(self, value: int) -> None:
        self._max_concurrent_trials = value

    @property
    def max_total_trials(self) -> int:
        return self._max_total_trials

    @max_total_trials.setter
    def max_total_trials(self, value: int) -> None:
        self._max_total_trials = value

    @property
    def timeout_minutes(self) -> int:
        return self._timeout_minutes

    @timeout_minutes.setter
    def timeout_minutes(self, value: int) -> None:
        self._timeout_minutes = value

    def _dump_yaml(self) -> Dict:
        return SweepJobSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    def _to_rest_object(self) -> JobBaseResource:
        search_space = {param: space._to_rest_object() for (param, space) in self.search_space.items()}

        self._generate_code_configuration()

        trial_component = TrialComponent(
            code_id=self.trial.code,
            environment_id=self.trial.environment,
            input_data_bindings=self.trial._data_bindings,
            command=self.trial._bound_command,
        )
        sweep_job = RestSweepJob(
            description=self.description,
            experiment_name=self.experiment_name,
            search_space=search_space,
            algorithm=self.algorithm.lower().capitalize() if self.algorithm is not None else None,
            max_total_trials=self.max_total_trials,
            max_concurrent_trials=self.max_concurrent_trials,
            timeout=to_iso_duration_format_mins(self.timeout_minutes),
            early_termination=self._early_termination,
            properties=self.properties,
            compute=self.trial.compute.dump_to_rest(),
            objective=self.objective,
            trial=trial_component,
            tags=self.tags,
        )
        sweep_job_resource = JobBaseResource(properties=sweep_job)
        sweep_job_resource.name = self.name
        return sweep_job_resource

    @classmethod
    def _load_from_dict(cls, data: Dict, context: Dict, additional_message: str, **kwargs) -> "SweepJob":
        loaded_schema = load_from_dict(SweepJobSchema, data, context, additional_message, **kwargs)
        loaded_schema["trial"] = ParameterizedCommand(**(loaded_schema["trial"]))
        sweep_job = SweepJob(**loaded_schema)
        return sweep_job

    @classmethod
    def _load_from_rest(cls, obj: JobBaseResource) -> "SweepJob":
        properties: RestSweepJob = obj.properties

        # Unpack termination schema
        early_termination = properties.early_termination

        trial = ParameterizedCommand()
        trial.load(properties.trial)
        # Compute also appears in both layers of the yaml, but only one of the REST.
        # This should be a required field in one place, but cannot be if its optional in two
        trial.compute = InternalComputeConfiguration(
            target=properties.compute.target,
            is_local=properties.compute.is_local,
            instance_count=properties.compute.instance_count,
        )

        return SweepJob(
            name=obj.name,
            id=obj.id,
            description=properties.description,
            properties=properties.properties,
            tags=properties.tags,
            experiment_name=properties.experiment_name,
            interaction_endpoints=properties.interaction_endpoints,
            status=properties.status,
            creation_context=obj.system_data,
            trial=trial,
            algorithm=properties.algorithm,
            search_space={
                param: SweepDistribution._from_rest_object(dist) for (param, dist) in properties.search_space.items()
            },
            max_concurrent_trials=properties.max_concurrent_trials,
            max_total_trials=properties.max_total_trials,
            timeout_minutes=from_iso_duration_format_mins(properties.timeout),
            early_termination=early_termination,
            objective=properties.objective,
            output=properties.output,
        )

    def _generate_code_configuration(self) -> RestCodeConfiguration:
        self.trial._bind_inputs()
        # subsitute "{search_space.<param>}" with "$AZUREML_SWEEP_<param>"
        for param in self.search_space:
            template = r"\{search_space." + param + r"\}"
            self.trial._bound_command = re.sub(template, self.AZUREML_SWEEP_PREFIX + param, self.trial._bound_command)
        return self.trial._generate_code_configuration()
