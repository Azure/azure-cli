# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    EndpointAuthMode,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import UnionField, NestedField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.identity import IdentitySchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmStr, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType, ComputeType
from marshmallow import ValidationError, fields, pre_load, validates

module_logger = logging.getLogger(__name__)


class EndpointSchema(PathAwareSchema):
    id = fields.Str()
    name = fields.Str(required=True)
    type = fields.Str()
    description = fields.Str()
    tags = fields.Dict()
    properties = fields.Dict()
    traffic = fields.Dict(
        keys=fields.Str(),
        values=fields.Int(),
        metadata={
            "description": "a dict with key as deployment name and value as traffic percentage. The values need to sum to 100"
        },
    )
    auth_mode = StringTransformedEnum(
        allowed_values=[EndpointAuthMode.AML_TOKEN, EndpointAuthMode.KEY, EndpointAuthMode.AAD_TOKEN],
        casing_transform=camel_to_snake,
        metadata={
            "description": "authentication method: no auth, key based or azure ml token based. aad_token is only valid for batch endpoint."
        },
    )
    scoring_uri = fields.Str(metadata={"description": "the endpoint uri that can be used for scoring"})
    location = fields.Str()
    swagger_uri = fields.Str()
    identity = NestedField(IdentitySchema)

    @validates("traffic")
    def validate_traffic(self, data, **kwargs):
        if sum(data.values()) > 100:
            raise ValidationError("Traffic rule percentages must sum to less than or equal to 100%")
