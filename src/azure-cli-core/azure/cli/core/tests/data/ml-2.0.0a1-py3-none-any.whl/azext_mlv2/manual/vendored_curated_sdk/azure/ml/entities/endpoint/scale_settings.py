# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from abc import abstractmethod
import logging
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    OnlineScaleSettings,
    ManualScaleSettings as RestManualScaleSettings,
    AutoScaleSettings as RestAutoScaleSettings,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    ScaleType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import (
    to_iso_duration_format,
    from_iso_duration_format,
)

module_logger = logging.getLogger(__name__)


class ScaleSettings(RestTranslatableMixin):
    """Scale settings for online deployment

    :param scale_type: Type of the scale settings, allowed values are "auto" and "manual".
    :type scale_type: str
    :param min_instances: Minimum number of the instances
    :type min_instances: int, optional
    :param max_instances: Maximum number of the instances
    :type max_instances: int, optional
    """

    def __init__(self, scale_type: str, min_instances: int = None, max_instances: int = None):
        self.scale_type = scale_type
        self.min_instances = min_instances
        self.max_instances = max_instances

    @abstractmethod
    def _to_rest_object(self) -> OnlineScaleSettings:
        pass

    def _merge_with(self, other: "ScaleSettings") -> None:
        if other:
            self.scale_type = other.scale_type or self.scale_type
            self.min_instances = other.min_instances or self.min_instances
            self.max_instances = other.max_instances or self.max_instances

    @classmethod
    def _from_rest_object(cls, settings: OnlineScaleSettings) -> "ScaleSettings":
        if isinstance(settings, RestManualScaleSettings):
            return ManualScaleSettings._from_rest_object(settings)
        elif isinstance(settings, RestAutoScaleSettings):
            return AutoScaleSettings._from_rest_object(settings)
        else:
            raise Exception(f"Unsupported online scale setting type {settings.scale_type}.")


class ManualScaleSettings(ScaleSettings):
    """Manual scale settings

    :param scale_type: Type of the scale settings, allowed values are "auto" and "manual".
    :type scale_type: str
    :param min_instances: Minimum number of the instances
    :type min_instances: int, optional
    :param max_instances: Maximum number of the instances
    :type max_instances: int, optional
    :param instance_count: Number of instances
    :type instance_count: int
    """

    def __init__(
        self,
        scale_type: str = str(ScaleType.MANUAL),
        min_instances: int = None,
        max_instances: int = None,
        instance_count: int = None,
    ):
        super(ManualScaleSettings, self).__init__(
            scale_type=scale_type,
            min_instances=min_instances,
            max_instances=max_instances,
        )
        self.instance_count = instance_count

    def _to_rest_object(self) -> RestManualScaleSettings:
        return RestManualScaleSettings(
            min_instances=self.min_instances,
            max_instances=self.max_instances,
            instance_count=self.instance_count,
        )

    def _merge_with(self, other: "ManualScaleSettings") -> None:
        if other:
            super()._merge_with(other)
            self.instance_count = other.instance_count or self.instance_count

    @classmethod
    def _from_rest_object(cls, settings: RestManualScaleSettings) -> "ManualScaleSettings":
        return ManualScaleSettings(
            scale_type=settings.scale_type,
            min_instances=settings.min_instances,
            max_instances=settings.max_instances,
            instance_count=settings.instance_count,
        )

    def __eq__(self, other: "ManualScaleSettings") -> bool:
        if not other:
            return False
        # only compare mutable fields
        return (
            self.scale_type.lower() == other.scale_type.lower()
            and self.min_instances == other.min_instances
            and self.max_instances == other.max_instances
            and self.instance_count == other.instance_count
        )

    def __ne__(self, other: "ManualScaleSettings") -> bool:
        return not self.__eq__(other)


class AutoScaleSettings(ScaleSettings):
    """Auto scale settings

    :param scale_type: Type of the scale settings, allowed values are "auto" and "manual".
    :type scale_type: str
    :param min_instances: Minimum number of the instances
    :type min_instances: int, optional
    :param max_instances: Maximum number of the instances
    :type max_instances: int, optional
    :param polling_interval: The polling interval in ISO 8691 format. Only supports duration with
     precision as low as Seconds.
    :type polling_interval: str
    :param target_utilization_percentage:
    :type target_utilization_percentage: int
    """

    def __init__(
        self,
        scale_type: str = str(ScaleType.AUTO),
        min_instances: int = None,
        max_instances: int = None,
        polling_interval: int = None,
        target_utilization_percentage: int = None,
    ):
        super(AutoScaleSettings, self).__init__(
            scale_type=scale_type,
            min_instances=min_instances,
            max_instances=max_instances,
        )
        self.polling_interval = polling_interval
        self.target_utilization_percentage = target_utilization_percentage

    def _to_rest_object(self) -> RestAutoScaleSettings:
        return RestAutoScaleSettings(
            min_instances=self.min_instances,
            max_instances=self.max_instances,
            polling_interval=to_iso_duration_format(self.polling_interval),
            target_utilization_percentage=self.target_utilization_percentage,
        )

    def _merge_with(self, other: "AutoScaleSettings") -> None:
        if other:
            super()._merge_with(other)
            self.polling_interval = other.polling_interval or self.polling_interval
            self.target_utilization_percentage = (
                other.target_utilization_percentage or self.target_utilization_percentage
            )

    @classmethod
    def _from_rest_object(cls, settings: RestAutoScaleSettings) -> "AutoScaleSettings":
        return AutoScaleSettings(
            scale_type=settings.scale_type,
            min_instances=settings.min_instances,
            max_instances=settings.max_instances,
            polling_interval=from_iso_duration_format(settings.polling_interval),
            target_utilization_percentage=settings.target_utilization_percentage,
        )

    def __eq__(self, other: "AutoScaleSettings") -> bool:
        if not other:
            return False
        # only compare mutable fields
        return (
            self.scale_type.lower() == other.scale_type.lower()
            and self.min_instances == other.min_instances
            and self.max_instances == other.max_instances
            and self.polling_interval == other.polling_interval
            and self.target_utilization_percentage == other.target_utilization_percentage
        )

    def __ne__(self, other: "AutoScaleSettings") -> bool:
        return not self.__eq__(other)
