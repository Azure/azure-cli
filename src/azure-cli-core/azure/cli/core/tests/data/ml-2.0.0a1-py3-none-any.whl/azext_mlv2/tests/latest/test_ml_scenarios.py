# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from collections import OrderedDict
from io import StringIO
import os
from typing import Any
import pytest
from azure.cli.testsdk import ScenarioTest
import yaml
from pathlib import Path
from tempfile import TemporaryDirectory
from ..util import *
from unittest.mock import Mock, patch
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._arm_deployments import ArmDeploymentExecutor
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AZUREML_PRIVATE_FEATURES_ENV_VAR
from azure_devtools.scenario_tests import AllowLargeResponse
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope


class MlTests(ScenarioTest):
    def __init__(self, method_name: Any) -> None:
        super().__init__(
            method_name,
            recording_processors=[
                MD5HeaderRemover(),
                ResourceGroupReplacer(),
                WorkspaceNameReplacer(),
                AzureBlobReplacer(),
                CodeAssetNameReplacer(),
                ComponentNameReplacer(),
                DataNameReplacer(),
                EnvironmentNameReplacer(),
                APIVersionReplacer(),
                DeploymentNameReplacer(),
                OperationStatusReplacer(),
                ResourceGroupReplacer_2(),
                ResponseReplace(),
            ],
            replay_processors=[
                MD5HeaderRemover(),
                ResourceGroupReplacer(),
                WorkspaceNameReplacer(),
                AzureBlobReplacer(),
                CodeAssetNameReplacer(),
                ComponentNameReplacer(),
                DataNameReplacer(),
                EnvironmentNameReplacer(),
                APIVersionReplacer(),
                DeploymentNameReplacer(),
                OperationStatusReplacer(),
                ResourceGroupReplacer_2(),
            ],
        )
        self.kwargs.update(
            {
                "jobName": self.create_random_name(prefix="test-job-", length=24),
                "datasetName": self.create_random_name(prefix="test-dataset-", length=24),
                "modelName": self.create_random_name(prefix="test-model-", length=24),
                "environmentName": self.create_random_name(prefix="test-environment-", length=24),
                "onlineEndpointName": self.create_random_name(prefix="test-onl-endpt-", length=24),
                "workspaceName": self.create_random_name(prefix="test-ws-", length=15),
                "computeName": self.create_random_name(prefix="testcomp", length=15),
                "subscription": self.get_subscription_id(),
                "blobDatastoreName": self.create_random_name(prefix="testblobds", length=24),
                "fileDatastoreName": self.create_random_name(prefix="testfileds", length=24),
                "componentName": self.create_random_name(prefix="test-component-", length=24),
                "modelName2": self.create_random_name(prefix="test-model2-", length=24),
            }
        )

    def tearDown(self):
        # os.environ = self.original_env
        # # Autorest.Python 2.x
        # assert not [t for t in threading.enumerate() if t.name.startswith("AzureOperationPoller")], \
        #     "You need to call 'result' or 'wait' on all AzureOperationPoller you have created"
        # # Autorest.Python 3.x
        # assert not [t for t in threading.enumerate() if t.name.startswith("LROPoller")], \
        #     "You need to call 'result' or 'wait' on all LROPoller you have created"
        """
        We don't want Azure CLI's teardown to check that LROPoller threads terminate.
        """
        pass

    def test_data(self) -> None:
        data_obj = self.cmd(
            "az ml data create --name {datasetName} --file tests/test_configs/data_local_path.yaml --version 1"
        )
        data_obj = yaml.safe_load(data_obj.output)
        assert data_obj["name"] == self.kwargs.get("datasetName", None)
        assert "az-ml-artifacts/" in data_obj["path"]
        assert data_obj["version"] == 1
        assert "workspaceblobstore" in data_obj["datastore"]
        assert data_obj["path"].endswith("/data")

        data_show_job = self.cmd("az ml data show --name {datasetName} --version 1")
        data_show_job = yaml.safe_load(data_show_job.output)
        assert_same(data_obj, data_show_job)

        data2 = self.cmd(
            "az ml data create --name {datasetName} --file tests/test_configs/data_file.yaml --version 2 --set local_path=python/simple_train.py description=bla"
        )
        data2 = yaml.safe_load(data2.output)
        assert data2["name"] == self.kwargs.get("datasetName", None)
        assert data2["version"] == 2
        assert data2["path"].endswith("simple_train.py")
        assert data2["description"] == "bla"

        data2 = self.cmd("az ml data update --name {datasetName} --version 2 --set description=blabla")
        data2 = yaml.safe_load(data2.output)
        assert data2["name"] == self.kwargs.get("datasetName", None)
        assert data2["version"] == 2
        assert data2["description"] == "blabla"

        data_list = self.cmd("az ml data list --max-results 1")
        assert len(yaml.safe_load(data_list.output)) != 0

    def test_job(self) -> None:
        # TODO: Assumes there is a compute called testCompute, which may prevent a successful recording
        job_obj = self.cmd("az ml job create --file tests/test_configs/jobs/command_job_test.yml --name {jobName}")
        job_obj = yaml.safe_load(job_obj.output)
        assert job_obj["name"] == self.kwargs.get("jobName", None)
        assert "testCompute" in job_obj["compute"]["target"]
        assert "AzureML-Minimal" in job_obj["environment"]
        assert "1" in job_obj["environment"]
        assert job_obj["experiment_name"] == "mfe-test1"
        assert job_obj["command"] == "pip freeze"

        job_show_obj = self.cmd("az ml job show --name {jobName}")
        job_show_obj = yaml.safe_load(job_show_obj.output)
        assert_same(
            job_obj,
            job_show_obj,
            filter=["status", "creation_context", "properties.ProcessStatusFile", "properties.ProcessInfoFile"],
        )
        # TODO: why does creation_context differs in the output of creation and show?
        # Ignoring properties ProcessStatusFile and ProcessInfoFile, present only after the job is running

        self.cmd("az ml job stream --name {jobName}")
        with TemporaryDirectory() as tmp_path:
            self.cmd("az ml job download --name {jobName} --download-path '" + tmp_path + "'")
            assert (Path(tmp_path) / self.kwargs.get("jobName", None)).is_dir()

        updated_job = self.cmd("az ml job update --name {jobName} --set description=bla")
        updated_job = yaml.safe_load(updated_job.output)

        assert updated_job["description"] == "bla"
        assert_same(
            job_show_obj,
            updated_job,
            filter=[
                "status",
                "tags",
                "creation_context",
                "properties.ProcessStatusFile",
                "properties.ProcessInfoFile",
                "description",
            ],
        )
        self.cmd("az ml job cancel --name {jobName}")
        # Ignoring properties ProcessStatusFile and ProcessInfoFile, present only after the job is running

    def test_sweep_job(self) -> None:
        job_obj = self.cmd("az ml job create --file tests/test_configs/sweep_job_test.yaml --name {jobName}")
        job_obj = yaml.safe_load(job_obj.output)
        assert job_obj["name"] == self.kwargs.get("jobName", None)
        assert "testCompute" in job_obj["trial"]["compute"]["target"]
        assert job_obj["experiment_name"] == "sdk-cli-v2"
        with open("tests/test_configs/sweep_job_test.yaml", "r") as f:
            file_obj = yaml.safe_load(f)

        # Check sweep-specific properties. Search space is verified in other testing.
        job_objective = job_obj["objective"]
        for param, value in file_obj["objective"].items():
            assert param in job_objective
            job_value = job_objective.get(param)
            assert value == job_value

        assert file_obj["max_total_trials"] == job_obj["max_total_trials"]
        assert file_obj["max_concurrent_trials"] == job_obj["max_concurrent_trials"]
        assert file_obj["timeout_minutes"] == job_obj["timeout_minutes"]

        # TODO: Put this back when MFE properly populates early termination. Bug here on MFE to track: https://msdata.visualstudio.com/Vienna/_workitems/edit/1167323
        """job_early_termination = job_obj["early_termination"]
        for param, value in file_obj["early_termination"].items():
            assert param in job_early_termination
            job_value = job_early_termination.get(param)
            assert value == job_value"""

    @patch.dict(os.environ, {AZUREML_PRIVATE_FEATURES_ENV_VAR: "True"})
    def test_pipeline_job_defaults_simple(self) -> None:
        job_obj = self.cmd(
            "az ml job create --file tests/test_configs/pipeline_jobs/helloworld_pipeline_job_defaults_e2e.yml --name {jobName}"
        )
        job_obj = yaml.safe_load(job_obj.output)
        assert "datastore" in job_obj["defaults"]["component_job"]
        assert "cpu-cluster" in job_obj["compute"]["target"]

        # sanity check outputs for two of the jobs that have outputs
        hello_job_1 = job_obj["jobs"]["hello_world_component_inline_1"]
        assert hello_job_1["outputs"]
        hello_job_1_outputs = hello_job_1["outputs"]
        assert hello_job_1_outputs["output_path"]

        hello_job_2 = job_obj["jobs"]["hello_world_component_inline_2"]
        assert hello_job_2["outputs"]
        hello_job_2_outputs = hello_job_2["outputs"]
        assert hello_job_2_outputs["output_path"]

    @patch.dict(os.environ, {AZUREML_PRIVATE_FEATURES_ENV_VAR: "True"})
    def test_pipeline_job_input_paths(self) -> None:
        job_obj = self.cmd(
            "az ml job create --file tests/test_configs/pipeline_jobs/helloworld_pipeline_job_with_component_output.yml --name {jobName}"
        )
        job_obj = yaml.safe_load(job_obj.output)
        print(job_obj)
        with open("tests/test_configs/pipeline_jobs/helloworld_pipeline_job_with_component_output.yml", "r") as f:
            file_obj = yaml.safe_load(f)
        assert job_obj["inputs"]
        job_obj_inputs = job_obj["inputs"]
        # check all given inputs are in the returned object
        for input_name, input_value in file_obj["inputs"].items():
            assert input_name in job_obj_inputs
            job_input = job_obj_inputs[input_name]
            if isinstance(input_value, OrderedDict):
                assert job_input["data"]
                assert isinstance(job_input["data"], str)
                assert input_value["mode"].lower() == job_input["mode"].lower() if input_value["mode"] else True
            else:
                assert job_input == input_value

        # check all of the given outputs are in the returned object
        job_obj_outputs = job_obj.get("outputs", None)
        assert job_obj_outputs
        for output_name, output_value in file_obj["outputs"].items():
            assert output_name in job_obj_outputs
            job_output = job_obj_outputs[output_name]
            assert job_output["data"] == output_value["data"]
            assert job_output["mode"].lower() == output_value["mode"].lower() if output_value["mode"] else True

        # check the default datastore is present
        assert job_obj["defaults"]["component_job"]["datastore"]

        # assert that all of the jobs are there
        job_obj_jobs = job_obj.get("jobs", None)
        assert job_obj_jobs
        for job_name, job_value in file_obj["jobs"].items():
            submitted_job = job_obj_jobs.get(job_name, None)
            assert submitted_job
            # first check the inputs
            submitted_job_inputs = submitted_job.get("inputs", None)
            assert submitted_job_inputs
            for input_name, input_value in job_value["inputs"].items():
                submitted_job_input = submitted_job_inputs.get(input_name, None)
                assert submitted_job_input
                assert submitted_job_input == input_value

            # next, check the outputs
            submitted_job_outputs = submitted_job.get("outputs", None)
            assert submitted_job_outputs
            for output_name, output_value in job_value["outputs"].items():
                submitted_job_output = submitted_job_outputs.get(output_name, None)
                assert submitted_job_output
                if isinstance(output_value, str):
                    assert output_value == submitted_job_output
                else:
                    assert output_value["data"] == submitted_job_output["data"]
                    assert (
                        output_value["mode"].lower() == submitted_job_output["mode"].lower()
                        if output_value["mode"]
                        else True
                    )

    def test_model(self) -> None:
        model_obj = self.cmd(
            "az ml model create --file tests/test_configs/model_full.yml --name {modelName} --set tags.abc=456"
        )
        model_obj = yaml.safe_load(model_obj.output)
        assert model_obj["name"] == self.kwargs.get("modelName", None)
        assert model_obj["description"] == "this is my test model"
        assert "model.pkl" in model_obj["path"]
        assert "az-ml-artifacts" in model_obj["path"]
        assert model_obj["tags"]["abc"] == "456"
        assert model_obj["tags"]["foo"] == "bar"

        model_show_job = self.cmd("az ml model show --name {modelName} --version 3")
        model_show_job = yaml.safe_load(model_show_job.output)
        assert_same(model_obj, model_show_job)
        self.cmd("az ml model delete --name {modelName} --version 3")
        with pytest.raises(Exception):
            self.cmd("az ml model show --name {modelname} --version 3")

        model_local_obj = self.cmd(
            "az ml model create --local-path tests/test_configs/model.pkl --name {modelName} --version 5 --set tags.abc=789"
        )
        model_local_obj = yaml.safe_load(model_local_obj.output)
        assert model_local_obj["name"] == self.kwargs.get("modelName", None)
        assert "model.pkl" in model_local_obj["path"]
        # assert model_local_obj["tags"]["abc"] == "789"

        model_local_show_job = self.cmd("az ml model show --name {modelName} --version 5")
        model_local_show_job = yaml.safe_load(model_local_show_job.output)
        assert_same(model_local_obj, model_local_show_job)

        # list model
        model = self.cmd("az ml model list --max-results 1")
        assert len(yaml.safe_load(model.output)) == 1

    def test_model_remote_path(self) -> None:

        model_obj = self.cmd(
            "az ml model create --file tests/test_configs/model_full.yml --name {modelName} --set tags.abc=456"
        )
        model_obj = yaml.safe_load(model_obj.output)
        self.kwargs.update({"path": model_obj["path"], "datastore": model_obj["datastore"]})
        model_remote_obj = self.cmd(
            "az ml model create --file tests/test_configs/model_path.yml --name {modelName2} --set path={path} datastore={datastore}"
        )
        model_remote_obj = yaml.safe_load(model_remote_obj.output)
        model_remote_obj["datastore"] == model_obj["datastore"]
        model_remote_obj["path"] == model_obj["path"]
        self.cmd("az ml model delete --name {modelName} --version 3")
        with pytest.raises(Exception):
            self.cmd("az ml model show --name {modelname} --version 3")

    def test_model_without_yml(self) -> None:
        model_obj = self.cmd(
            "az ml model create --name {modelName} --local-path tests/test_configs/model.pkl --version 1"
        )
        model_obj = yaml.safe_load(model_obj.output)
        assert model_obj["name"] == self.kwargs.get("modelName", None)
        assert "model.pkl" in model_obj["path"]
        assert "az-ml-artifacts" in model_obj["path"]

        model_show_job = self.cmd("az ml model show --name {modelName} --version 1")
        model_show_job = yaml.safe_load(model_show_job.output)
        assert_same(model_obj, model_show_job)
        self.cmd("az ml model delete --name {modelName} --version 1")
        with pytest.raises(Exception):
            self.cmd("az ml model show --name {modelname} --version 1")

    def test_environment_params_override(self) -> None:
        self.cmd(
            "az ml environment create --file tests/test_configs/environment/environment_conda_name_version.yml --name {environmentName}"
        )

    def test_environment(self) -> None:
        env_obj = self.cmd(
            "az ml environment create --file tests/test_configs/environment/environment_conda.yml --name {environmentName} --set version=1"
        )
        env_obj = yaml.safe_load(env_obj.output)
        assert env_obj["name"] == self.kwargs.get("environmentName", None)
        assert env_obj["version"] == 1
        assert "docker" in env_obj
        env_show_obj = self.cmd("az ml environment show --name {environmentName}")
        env_show_obj = yaml.safe_load(env_show_obj.output)
        assert_same(env_obj, env_show_obj, filter=["creation_context"])
        # list environments
        environments = self.cmd("az ml environment list --max-results 1")
        assert len(yaml.safe_load(environments.output)) == 1
        """
        Bug in line 249 environment.py
        """
        # env_update_obj = self.cmd("az ml environment update -n {environmentName} -v 1 --set tags.name=test_tag")
        # env_update_obj = yaml.safe_load(env_update_obj.output)
        # assert env_update_obj["name"] == self.kwargs.get("environmentName", None)
        # assert env_update_obj["tags"]["name"] == "test_tag"
        env_delete_obj = self.cmd("az ml environment delete -n {environmentName} -v 1")
        assert env_delete_obj.output == ""

    def test_environment_with_docker(self) -> None:
        env_obj = self.cmd(
            "az ml environment create --file tests/test_configs/environment/environment_docker.yml --name {environmentName} --set version=1"
        )
        env_obj = yaml.safe_load(env_obj.output)
        assert env_obj["name"] == self.kwargs.get("environmentName", None)
        assert env_obj["docker"]["image"] == "mcr.microsoft.com/azureml/base:0.2.2"
        assert "conda_file" in env_obj
        assert env_obj["version"] == 1

        env_show_obj = self.cmd("az ml environment show --name {environmentName}")
        env_show_obj = yaml.safe_load(env_show_obj.output)
        assert_same(env_obj, env_show_obj, filter=["creation_context"])

    def test_environment_using_dockerfile(self) -> None:
        env_obj = self.cmd(
            "az ml environment create --file tests/test_configs/environment/environment_docker_file.yml --name {environmentName} --set version=1"
        )
        env_obj = yaml.safe_load(env_obj.output)
        assert env_obj["name"] == self.kwargs.get("environmentName", None)
        assert "ubuntu:16.04" in env_obj["docker"]["build"]["dockerfile"]
        assert not env_obj["conda_file"]
        assert env_obj["version"] == 1

        env_show_obj = self.cmd("az ml environment show --name {environmentName}")
        env_show_obj = yaml.safe_load(env_show_obj.output)
        assert_same(env_obj, env_show_obj, filter=["creation_context"])

    def test_workspace(self) -> None:
        ws_obj = self.cmd(
            "az ml workspace create --file tests/test_configs/workspace_full.yaml -w {workspaceName} --no-wait"
        )
        assert ws_obj.output == ""
        # sleep(600) # This sleep is only required for fresh recording of cassette
        ws_obj_s = self.cmd("az ml workspace show -w {workspaceName}")
        ws_obj_s = yaml.safe_load(ws_obj_s.output)
        assert ws_obj_s["name"] == self.kwargs.get("workspaceName", None)
        assert ws_obj_s["friendly_name"] == self.kwargs.get("workspaceName", None)
        assert ws_obj_s["storage_account"] is not None
        assert ws_obj_s["application_insights"] is not None
        assert ws_obj_s["key_vault"] is not None
        assert ws_obj_s["private_endpoints"] is not None
        assert ws_obj_s["customer_managed_key"] is not None
        ws_obj_del = self.cmd("az ml workspace delete -w {workspaceName} --all-resources  --no-wait -y")
        assert ws_obj_del.output == ""

    def test_datastore_blob(self) -> None:
        ds_obj = self.cmd(
            "az ml datastore create --file ./tests/test_configs/blob_store.yml --name {blobDatastoreName}"
        )
        ds_obj = yaml.safe_load(ds_obj.output)
        assert ds_obj["name"] == self.kwargs.get("blobDatastoreName", None)
        assert ds_obj["type"] == "azure_blob"
        assert ds_obj["container_name"] == "testblob"
        ds_show_obj = self.cmd("az ml datastore show -n {blobDatastoreName} --include-secrets")
        ds_show_obj = yaml.safe_load(ds_show_obj.output)
        old_credential = ds_show_obj["credential"]["access_key"]
        assert old_credential
        assert_same(ds_obj, ds_show_obj, filter=["credential"])

        # Update datastore credential. A bit hacked as we cannot check in credentials in code, so the HTTP traffic was recorded once
        # and the credential was removed from the command line
        self.cmd("az ml datastore update --file ./tests/test_configs/blob_store.yml --name {blobDatastoreName}")
        updated_ds_obj = self.cmd("az ml datastore show --name {blobDatastoreName} --include-secrets")
        updated_ds_obj = yaml.safe_load(updated_ds_obj.output)
        assert updated_ds_obj["credential"]["access_key"] != old_credential

    def test_datastore_file(self) -> None:
        ds_obj = self.cmd(
            "az ml datastore create --file ./tests/test_configs/file_store.yml --name {fileDatastoreName}"
        )
        ds_obj = yaml.safe_load(ds_obj.output)
        assert ds_obj["name"] == self.kwargs.get("fileDatastoreName", None)
        assert ds_obj["type"] == "azure_file"
        assert ds_obj["file_share_name"] == "testfileshare"
        ds_show_obj = self.cmd("az ml datastore show -n {fileDatastoreName} --include-secrets")
        ds_show_obj = yaml.safe_load(ds_show_obj.output)
        old_credential = ds_show_obj["credential"]["access_key"]
        assert old_credential
        assert_same(ds_obj, ds_show_obj, filter=["credential"])

        # Update datastore credential. A bit hacked as we cannot check in credentials in code, so the HTTP traffic was recorded once
        # and the credential was removed from the command line
        self.cmd("az ml datastore update --file ./tests/test_configs/file_store.yml --name {fileDatastoreName}")
        updated_ds_obj = self.cmd("az ml datastore show --name {fileDatastoreName} --include-secrets")
        updated_ds_obj = yaml.safe_load(updated_ds_obj.output)
        assert updated_ds_obj["credential"]["access_key"] != old_credential

    def test_compute_aml(self) -> None:
        ws_obj = self.cmd("az ml compute create --name {computeName} --type amlcompute --no-wait")
        assert ws_obj.output == ""
        # sleep(60) # This sleep is only required for fresh recording of cassette
        ws_obj = self.cmd("az ml compute show --name {computeName}")
        ws_obj = yaml.safe_load(ws_obj.output)
        ws_obj["name"] == self.kwargs.get("computeName", None)
        ws_obj["type"] == "AmlCompute"
        ws_obj["size"] == "STANDARD_D2_V2"
        ws_update = self.cmd(
            "az ml compute update -n {computeName} --max-instances 4 --min-instances 1 --idle-time-before-scale-down 100  --identity-type SystemAssigned"
        )
        ws_update = yaml.safe_load(ws_update.output)
        ws_update["min_instances"] == 1
        ws_update["identity_type"] == "SystemAssigned"
        computes = self.cmd("az ml compute list --max-results 1")
        assert len(yaml.safe_load(computes.output)) != 0
        ws_del = self.cmd("az ml compute delete --name {computeName} --no-wait -y")
        assert ws_del.output == ""

    def test_compute_compute_instance(self) -> None:
        ws_obj = self.cmd("az ml compute create --name {computeName} --type computeinstance --no-wait")
        assert ws_obj.output == ""
        # sleep(420) # This sleep is only required for fresh recording of cassette
        ws_obj = self.cmd("az ml compute show --name {computeName}")
        ws_obj = yaml.safe_load(ws_obj.output)
        ws_obj["name"] == self.kwargs.get("computeName", None)
        ws_obj["type"] == "ComputeInstance"
        ws_obj["size"] == "STANDARD_D2_V2"
        ws_del = self.cmd("az ml compute delete --name {computeName} --no-wait -y")
        assert ws_del.output == ""

    def test_compute_aks_attach_detach(self) -> None:
        ws_obj = self.cmd(
            "az ml compute attach --name {computeName} --resource-id '/subscriptions/b17253fa-f327-42d6-9686-f3e553e24763/resourcegroups/banibatch/providers/Microsoft.ContainerService/managedClusters/bani-aks' --type aks --no-wait"
        )
        assert ws_obj.output == ""
        # sleep(500) # This sleep is only required for fresh recording of cassette
        ws_obj_show = self.cmd("az ml compute show --name {computeName}")
        ws_obj_show = yaml.safe_load(ws_obj_show.output)
        ws_obj_show["name"] == self.kwargs.get("computeName", None)
        ws_obj_show["type"] == "AKS"
        ws_obj_delete = self.cmd("az ml compute detach --name {computeName} --no-wait -y")
        assert ws_obj_delete.output == ""
        # sleep(300) # This sleep is only required for fresh recording of cassette
        with pytest.raises(SystemExit):
            ws_obj = self.cmd("az ml compute show --name {computeName}")
        assert ws_obj.output == ""

    def test_compute_list(self) -> None:
        ws_obj_list = self.cmd("az ml compute list")
        ws_obj_list = yaml.safe_load(ws_obj_list.output)
        assert len(ws_obj_list) > 0

    @patch.object(ArmDeploymentExecutor, "_check_deployment_status")
    def test_online_endpoint_simple_deployment_flow(self, mock_method) -> None:
        cmd1 = "az ml endpoint create -n {onlineEndpointName} --file tests/test_configs/online/managed/simple-flow/1-create-endpoint-with-blue.yaml"
        cmd2 = "az ml endpoint show -n {onlineEndpointName}"
        cmd3 = "az ml endpoint invoke -n {onlineEndpointName} --request-file tests/test_configs/online/model-1/sample-request.json"
        cmd4 = "az ml endpoint delete -n {onlineEndpointName} -y"
        self.cmd(cmd1)
        online_ept_obj_show = self.cmd(cmd2)
        online_ept_obj_show = yaml.safe_load(online_ept_obj_show.output)
        assert online_ept_obj_show["auth_mode"] == "aml_token"
        assert "blue" in {d["name"] for d in online_ept_obj_show["deployments"]}
        assert online_ept_obj_show["traffic"]["blue"] == 100
        self.cmd(cmd3)
        self.cmd(cmd4)

    def test_online_endpoint_show(self) -> None:
        cmd2 = "az ml endpoint show -n {onlineEndpointName}"
        online_ept_obj_show = self.cmd(cmd2)
        online_ept_obj_show = yaml.safe_load(online_ept_obj_show.output)
        assert len(online_ept_obj_show) > 0

    @patch.object(ArmDeploymentExecutor, "_check_deployment_status")
    def test_online_endpoint_imperative_cli_flow(self, mock_method) -> None:
        cmd1 = "az ml endpoint create -n {onlineEndpointName} --file tests/test_configs/online/managed/canary-imperative-flow/1-create-endpoint.yaml"
        cmd2 = "az ml endpoint update -n {onlineEndpointName} --deployment blue --deployment-file tests/test_configs/online/managed/canary-imperative-flow/2-create-blue.yaml"
        cmd3 = 'az ml endpoint update -n {onlineEndpointName} --traffic "blue:100"'
        cmd4 = "az ml endpoint invoke -n {onlineEndpointName} --request-file tests/test_configs/online/model-1/sample-request.json"
        cmd5 = "az ml endpoint update -n {onlineEndpointName} --deployment blue --instance-count 2"
        cmd6 = 'az ml endpoint update -n {onlineEndpointName} --deployment-file tests/test_configs/online/managed/canary-imperative-flow/3-create-green.yaml  --traffic "blue:100,green:0"'
        cmd7 = "az ml endpoint invoke -n {onlineEndpointName} --request-file tests/test_configs/online/model-1/sample-request.json"
        cmd8 = 'az ml endpoint update -n {onlineEndpointName} --traffic "blue:90,green:10"'
        cmd9 = 'az ml endpoint update -n {onlineEndpointName} --traffic "blue:0,green:100"'
        self.cmd(cmd1)
        self.cmd(cmd2)
        self.cmd(cmd3)
        self.cmd(cmd4)
        self.cmd(cmd5)
        self.cmd(cmd6)
        self.cmd(cmd7)
        self.cmd(cmd8)
        self.cmd(cmd9)

    @patch.object(ArmDeploymentExecutor, "_check_deployment_status")
    def test_online_endpoint_declarative_gitops_flow(self, mock_method) -> None:
        if not self.in_recording:
            patcher = patch.object(WorkspaceScope, "resource_group_name", "000000000000000")
            patcher.start()
        cmd1 = "az ml endpoint create -n {onlineEndpointName} --file tests/test_configs/online/managed/simple-flow/1-create-endpoint-with-blue.yaml"
        cmd2 = "az ml endpoint update -n {onlineEndpointName} --file tests/test_configs/online/managed/canary-declarative-flow/2-scale-blue.yaml"
        cmd3 = "az ml endpoint update -n {onlineEndpointName} --file tests/test_configs/online/managed/canary-declarative-flow/3-create-green.yaml"
        cmd4 = "az ml endpoint update -n {onlineEndpointName} --file tests/test_configs/online/managed/canary-declarative-flow/4-flight-green.yaml"
        cmd5 = "az ml endpoint update -n {onlineEndpointName} --file tests/test_configs/online/managed/canary-declarative-flow/5-full-green.yaml"
        cmd6 = "az ml endpoint update -n {onlineEndpointName} --file tests/test_configs/online/managed/canary-declarative-flow/6-delete-blue.yaml"
        cmd7 = "az ml endpoint delete -n {onlineEndpointName} -y"
        self.cmd(cmd1)
        self.cmd(cmd2)
        self.cmd(cmd3)
        self.cmd(cmd4)
        self.cmd(cmd5)
        self.cmd(cmd6)
        self.cmd(cmd7)

    @AllowLargeResponse()
    @patch.dict(os.environ, {AZUREML_PRIVATE_FEATURES_ENV_VAR: "True"})
    def test_component(self):
        component_obj = self.cmd(
            "az ml component create --file tests/test_configs/components/helloworld_component.yml --set name={componentName}"
        )
        component_obj = yaml.safe_load(component_obj.output)
        assert component_obj["version"] == 1
        assert component_obj["type"] == "command_component"
        assert component_obj["name"] == self.kwargs.get("componentName", None)
        assert component_obj["display_name"] == "CommandComponentBasic"

        # show component
        component_show_obj = self.cmd("az ml component show --name {componentName} --version 1")
        component_show_obj = yaml.safe_load(component_show_obj.output)
        assert component_obj == component_show_obj
        # show latest component
        component_show_obj = self.cmd("az ml component show --name {componentName}")
        component_show_obj = yaml.safe_load(component_show_obj.output)
        assert component_show_obj["version"] == 1
        assert component_obj == component_show_obj

        # list components
        components = self.cmd("az ml component list --max-results 1")
        assert len(yaml.safe_load(components.output)) != 0
        # list component versions
        component_versions = self.cmd("az ml component list --name {componentName}")
        component_versions = yaml.safe_load(component_versions.output)
        assert len(component_versions) == 1
        component_list_obj = component_versions[0]
        assert component_list_obj == component_obj

        # update component
        component_update_obj = self.cmd(
            "az ml component update --name {componentName} -v 1 --set display_name=NewComponent"
        )
        component_update_obj = yaml.safe_load(component_update_obj.output)
        assert component_update_obj["display_name"] == "NewComponent"

        # delete component
        component_delete_obj = self.cmd("az ml component delete --name {componentName} -v 1")
        assert component_delete_obj.output == ""

    @patch.object(ArmDeploymentExecutor, "_check_deployment_status")
    def test_online_endpoint_with_remote_model_path(self, mock_method) -> None:
        model = self.cmd(
            "az ml model create -n {modelName} -v 1 -l tests/test_configs/online/model-1/model/sklearn_regression_model.pkl"
        )
        model = yaml.safe_load(model.output)
        self.kwargs.update({"path": model["path"], "datastore": model["datastore"]})

        self.cmd(
            "az ml endpoint create -n {onlineEndpointName} --file tests/test_configs/online-endpoint-with-blue.yaml --set deployments[0].model.path={path} deployments[0].model.datastore={datastore}"
        )
        model2 = self.cmd("az ml model show -n model-remote -v 1")
        model2 = yaml.safe_load(model2.output)


class MlBatchEndpointTests(ScenarioTest):
    def __init__(self, method_name: Any) -> None:
        super().__init__(
            method_name,
            recording_processors=[
                MD5HeaderRemover(),
                ResourceGroupReplacer(),
                WorkspaceNameReplacer(),
                AzureBlobReplacer(),
                CodeAssetNameReplacer(),
                APIVersionReplacer(),
                DataNameReplacer(),  # extra needed for batch endpoints
            ],
            replay_processors=[
                MD5HeaderRemover(),
                ResourceGroupReplacer(),
                WorkspaceNameReplacer(),
                AzureBlobReplacer(),
                CodeAssetNameReplacer(),
                APIVersionReplacer(),
                DataNameReplacer(),  # extra needed for batch endpoints
            ],
        )
        self.kwargs.update({"batchEndpointName": self.create_random_name(prefix="test-bat-endpt-", length=24)})

    def test_batch_endpoint(self) -> None:
        batch_endpoint = self.cmd(
            "az ml endpoint create --file tests/test_configs/batch_endpoint.yaml --name {batchEndpointName} --type batch"
        )
        batch_endpoint = yaml.safe_load(batch_endpoint.output)
        assert batch_endpoint["name"] == self.kwargs.get("batchEndpointName", None)
        assert batch_endpoint["type"] == "batch"
        assert batch_endpoint["auth_mode"] == "aad_token"
        # Bug in MFE that batch endpoint properties are not preserved, uncomment after fixed
        # assert batch_endpoint["properties"] == {"p1": "v1", "p2": "v2"}
        assert "blue" in {d["name"] for d in batch_endpoint["deployments"]}

        batch_endpoint_show = self.cmd("az ml endpoint show --type batch --name {batchEndpointName}")
        batch_endpoint_show = yaml.safe_load(batch_endpoint_show.output)

        assert_same(batch_endpoint, batch_endpoint_show)

        # Invoke with a pre-registered data asset as the input
        batch_job = self.cmd(
            "az ml endpoint invoke --type batch --name {batchEndpointName} --input-data list_data_test:1"
        )
        batch_job = yaml.safe_load(batch_job.output)
        # sub, rg and ws will be replaced, so only asserting the last part of the arm id
        assert batch_job["properties"]["dataset"]["datasetId"].endswith("data/list_data_test/versions/1")

        # Invoke with a public uri as the input
        batch_job2 = self.cmd(
            "az ml endpoint invoke --type batch --name {batchEndpointName} --input-path https://pipelinedata.blob.core.windows.net/sampledata/mnist/ --set error_threshold=10 output_file_name=test.txt"
        )
        batch_job2 = yaml.safe_load(batch_job2.output)
        # When invoked with a cloud uri, most things are auto generated, only thing we can assert on is the input data type
        assert batch_job2["properties"]["dataset"]["dataInputType"] == "DatasetId"
        assert batch_job2["properties"]["errorThreshold"] == 10
        assert batch_job2["properties"]["outputFileName"] == "test.txt"

        # Invoke with a local directory as the input
        batch_job3 = self.cmd(
            "az ml endpoint invoke --type batch --name {batchEndpointName} --input-local-path tests/test_configs/data --output-path tests/output --instance-count 2 --mini-batch-size 5"
        )
        batch_job3 = yaml.safe_load(batch_job3.output)
        # When invoked with a cloud uri, most things are auto generated, only thing we can assert on is the input data type
        assert batch_job3["properties"]["dataset"]["dataInputType"] == "DatasetId"
        assert batch_job3["properties"]["outputDataset"]["path"] == "tests/output"
        assert batch_job3["properties"]["miniBatchSize"] == 5
        assert batch_job3["properties"]["compute"]["instanceCount"] == 2
