Microsoft Azure CLI Command modules Namespace Package
=====================================

This is the Microsoft Azure CLI command module namespace package.

This package is not intended to be installed directly by the end user.

It provides the necessary files for other packages to extend the azure cli command module namespaces.
