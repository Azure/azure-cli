# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
from collections import OrderedDict
from azext_mlv2.manual.custom.utils import deep_get


def transform_environment(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("latest version", r.get("latest_version")),
            ]
        )
        if r.get("version", None):
            entry["version"] = r.get("version")
        transformed.append(entry)

    return transformed


def transform_environment_list(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
            ]
        )
        if r.get("latest_version", None):
            entry["latest version"] = r.get("latest_version")
        if r.get("version", None):
            entry["version"] = r.get("version")
        transformed.append(entry)

    return transformed


def transform_job(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("status", r.get("status")),
                ("experiment", r.get("experiment_name")),
                ("status", r.get("status")),
                ("compute target", r.get("compute", "")),
                ("job type", r.get("type")),
                ("created on", deep_get(r, ["creation_context", "created_at"], None)),
            ]
        )
        transformed.append(entry)
    return transformed


def transform_data(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("latest version", r.get("latest_version")),
            ]
        )
        if r.get("version", None):
            entry["version"] = r.get("version")
            entry["data type"] = r.get("version")
            entry["path"] = r.get("path")
        transformed.append(entry)

    return transformed


def transform_dataset(result):

    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
            ]
        )
        if r.get("version", None):
            entry["version"] = r.get("version")
            paths = []
            for path in r.get("paths"):
                if path.get("file", None):
                    paths.append(path.get("file"))
                elif path.get("folder", None):
                    paths.append(path.get("folder", None))
            entry["paths"] = ", ".join(paths)
        transformed.append(entry)

    return transformed


def transform_datastore(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [("name", r.get("name")), ("storage type", r.get("type")), ("storage account name", r.get("account_name"))]
        )
        transformed.append(entry)

    return transformed


def transform_compute(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("compute type", r.get("type")),
                ("state", r.get("state", None) or r.get("provisioning_state", None)),
                ("Instance type", r.get("size", None)),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_vmsize(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("family", r.get("family", None)),
                ("v_cp_us", r.get("v_cp_us", None)),
                ("gpus", r.get("gpus", None)),
                ("os_vhd_size_mb", r.get("os_vhd_size_mb", None)),
                ("max_resource_volume_mb", r.get("max_resource_volume_mb", None)),
                ("memory_gb", r.get("memory_gb", None)),
                ("low_priority_capable", r.get("low_priority_capable", None)),
                ("premium_io", r.get("premium_io", None)),
                ("supported_compute_types", r.get("supported_compute_types", None)),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_usage(result):
    transformed = []
    for r in result:
        name = r.get("name", None)
        entry = OrderedDict(
            [
                ("aml_workspace_location", r.get("aml_workspace_location", None)),
                ("type", r.get("type", None)),
                ("unit", r.get("unit", None)),
                ("current_value", r.get("current_value", None)),
                ("limit", r.get("limit", None)),
                ("name", name["value"] if name and "value" in name else None),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_workspace(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("location", r.get("location")),
                ("description", r.get("description", None)),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_model(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("latest version", r.get("latest version")),
            ]
        )
        if r.get("version", None):
            entry["version"] = r.get("version")
            entry["model type"] = r.get("type")
            entry["path"] = r.get("path", None)
        transformed.append(r)

    return transformed


def transform_model_list(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
            ]
        )

        if r.get("latest_version", None):
            entry["latest version"] = r.get("latest_version")
        if r.get("version", None):
            entry["version"] = r.get("version")
            entry["model type"] = r.get("type")
            entry["path"] = r.get("path", None)
        transformed.append(entry)

    return transformed


def transform_component(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("latest version", r.get("latest_version")),
            ]
        )
        if r.get("version", None):
            entry["version"] = r.get("version")
            entry["Component type"] = r.get("type")
        transformed.append(entry)

    return transformed


def transform_workspace_connection(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("target", r.get("target")),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_deployment(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("endpoint_name", r.get("endpoint_name")),
                ("provisioning_state", r.get("provisioning_state", None)),
                ("instance_type", r.get("instance_type", None)),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_deployment_list(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("endpoint_name", r.get("endpoint_name")),
                ("provisioning_state", r.get("provisioning_state", None)),
                ("instance_type", r.get("instance_type", None)),
                ("model", r.get("model")),
                ("type", r.get("type")),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_endpoint_list(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("location", r.get("location")),
                ("traffic", r.get("traffic")),
                ("provisioning_state", r.get("provisioning_state")),
            ]
        )
        transformed.append(entry)

    return transformed


def transform_batch_endpoint_list(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("id", r.get("id")),
                ("name", r.get("name")),
                ("deployment_name", deep_get(r, ["defaults", "deploymentName"])),
                ("location", r.get("location")),
                ("provisioning_state", r.get("provisioning_state")),
                ("scoring_uri", r.get("scoring_uri")),
                ("auth_mode", r.get("auth_mode")),
            ]
        )
        transformed.append(entry)
    return transformed


def transform_batch_deployment_list(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("id", r.get("id")),
                ("name", r.get("name")),
                ("model", r.get("model")),
                ("code", deep_get(r, ["code_configuration", "code"])),
                ("environment", r.get("environment")),
                ("compute", r.get("compute")),
            ]
        )
        transformed.append(entry)
    return transformed


def transform_batch_deployment_list_jobs(result):
    transformed = []
    for r in result:
        entry = OrderedDict(
            [
                ("name", r.get("name")),
                ("status", r.get("status")),
                ("web link", r.get("web_link")),
                ("output", r.get("output")),
            ]
        )
        transformed.append(entry)
    return transformed
