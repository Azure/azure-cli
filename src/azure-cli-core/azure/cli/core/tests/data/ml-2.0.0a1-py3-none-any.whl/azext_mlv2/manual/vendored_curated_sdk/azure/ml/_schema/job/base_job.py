# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from marshmallow import fields
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType
from .creation_context import CreationContextSchema
from .interaction_endpoints import JobEndpointSchema
from .job_output import JobOutputSchema

module_logger = logging.getLogger(__name__)


class BaseJobSchema(PathAwareSchema):
    creation_context = NestedField(CreationContextSchema, dump_only=True)
    interaction_endpoints = fields.Dict(keys=fields.Str(), values=NestedField(JobEndpointSchema))
    name = fields.Str()
    id = ArmStr(azureml_type=AzureMLResourceType.JOB, dump_only=True, required=False)
    tags = fields.Dict(keys=fields.Str(), values=fields.Str())
    status = fields.Str(dump_only=True)
    experiment_name = fields.Str()
    properties = fields.Dict(keys=fields.Str(), values=fields.Str())
    description = fields.Str()
    log_files = fields.Dict(
        keys=fields.Str(),
        values=fields.Str(),
        dump_only=True,
        metadata={
            "description": "The list of log files associated with this run. This section is only populated by the service and will be ignored if contained in a yaml sent to the service (e.g. via `az ml job create` ...)"
        },
    )
    output = NestedField(
        JobOutputSchema(), metadata={"description": "The output configurations for the component used."}, dump_only=True
    )
