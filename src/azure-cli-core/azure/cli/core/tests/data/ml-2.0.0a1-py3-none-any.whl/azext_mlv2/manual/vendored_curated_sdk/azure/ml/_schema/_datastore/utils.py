# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    DatastoreCredentials,
    AccountKeyCredentials,
    SasCredentials,
    ServicePrincipalCredentials,
    CertificateCredentials,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    CredentialsType,
)


def generate_credential_from_internal_datastore(
    ds_credential: Union[AccountKeyCredentials, SasCredentials, ServicePrincipalCredentials, CertificateCredentials]
) -> DatastoreCredentials:
    if isinstance(ds_credential, AccountKeyCredentials):
        return DatastoreCredentials(type=CredentialsType.ACCOUNT_KEY, account_key=ds_credential)
    elif isinstance(ds_credential, SasCredentials):
        return DatastoreCredentials(type=CredentialsType.SAS, sas=ds_credential)
    elif isinstance(ds_credential, ServicePrincipalCredentials):
        return DatastoreCredentials(type=CredentialsType.SERVICE_PRINCIPAL, service_principal=ds_credential)
    else:
        return DatastoreCredentials(type=CredentialsType.CERTIFICATE, certificate=ds_credential)


def get_credential_from_rest(
    credentials: DatastoreCredentials,
) -> Union[AccountKeyCredentials, SasCredentials, ServicePrincipalCredentials]:
    if credentials.type == CredentialsType.ACCOUNT_KEY:
        return credentials.key
    elif credentials.type == CredentialsType.SAS:
        return credentials.sas_token
    elif credentials.type == CredentialsType.SERVICE_PRINCIPAL:
        return credentials.service_principal
    return credentials.certificate
