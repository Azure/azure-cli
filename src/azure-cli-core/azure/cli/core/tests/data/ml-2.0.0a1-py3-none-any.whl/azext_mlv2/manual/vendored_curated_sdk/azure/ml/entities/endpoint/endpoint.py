# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from os import PathLike
from pathlib import Path
from typing import Any, Dict, Optional, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint import BatchEndpointSchema, K8sOnlineEndpointSchema, ManagedOnlineEndpointSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BASE_PATH_CONTEXT_KEY,
    BATCH_ENDPOINT_TYPE,
    EndpointYamlFields,
    ONLINE_ENDPOINT_TYPE,
    PARAMS_OVERRIDE_KEY,
    CommonYamlFields,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.resource import Resource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import find_type_in_override
from marshmallow.utils import RAISE
from marshmallow import ValidationError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict

module_logger = logging.getLogger(__name__)


class Endpoint(Resource):
    """Endpoint base class.

    :param base_path: #TODO
    :type base_path: Optional[str], optional
    :param auth_mode: the authentication mode, defaults to None
    :type auth_mode: str, optional
    :param location: defaults to None
    :type location: str, optional
    :param traffic: Traffic rules on how the traffic will be routed across deployments, defaults to {}
    :type traffic: Dict[str, int], optional
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str, optional
    :param name: Name of the resource.
    :type name: str, optional
    :param tags: Internal use only.
    :type tags: Dict[str, str], optional
    :param properties: Internal use only.
    :type properties: Dict[str, Any], optional
    :param description: Description of the resource.
    :type description: str, optional
    :param scoring_uri: URI to use to perform a prediction, readonly.
    :type scoring_uri: str, optional
    :param swagger_uri: URI to check the swagger definition of the endpoint.
    :type swagger_uri: str, optional
    """

    def __init__(
        self,
        base_path: Optional[str] = None,  # TODO: maybe delete this?
        type: str = None,
        auth_mode: str = None,
        location: str = None,
        traffic: Dict[str, int] = None,
        id: str = None,
        name: str = None,
        tags: Dict[str, str] = None,
        properties: Dict[str, Any] = None,
        description: str = None,
        scoring_uri: str = None,
        swagger_uri: str = None,
    ):
        # MFE is case-insensitive for Name. So convert the name into lower case here.
        if name:
            name = name.lower()
        super().__init__(name, id, description, tags, properties)
        self.type = type
        self.auth_mode = auth_mode
        self.location = location
        self.traffic = dict(traffic) if traffic else {}

        self._scoring_uri = scoring_uri
        self._swagger_uri = swagger_uri

    @property
    def scoring_uri(self) -> Optional[str]:
        return self._scoring_uri

    @property
    def swagger_uri(self) -> Optional[str]:
        return self._swagger_uri

    @classmethod
    def load(cls, path: Union[PathLike, str], params_override: list = [], **kwargs) -> "Endpoint":

        yaml_dict = load_yaml(path)
        return cls._load(data=yaml_dict, yaml_path=path, params_override=params_override, **kwargs)

    @classmethod
    def _load(
        cls,
        data: Dict = {},
        yaml_path: Union[PathLike, str] = None,
        params_override: list = [],
        **kwargs,
    ) -> "Endpoint":

        context = {
            BASE_PATH_CONTEXT_KEY: Path(yaml_path).parent if yaml_path else Path.cwd(),
            PARAMS_OVERRIDE_KEY: params_override,
        }

        type_in_override = find_type_in_override(params_override)
        type = type_in_override or data.pop(CommonYamlFields.TYPE, ONLINE_ENDPOINT_TYPE)
        try:
            if type == BATCH_ENDPOINT_TYPE:
                return load_from_dict(BatchEndpointSchema, data, context)
            elif data.get(EndpointYamlFields.TARGET):
                return load_from_dict(K8sOnlineEndpointSchema, data, context)
            else:
                return load_from_dict(ManagedOnlineEndpointSchema, data, context)
        except ValidationError as err:
            module_logger.error(err.messages)
            raise err
        except Exception as e:
            module_logger.error(
                f'Endpoint type needs to be set to either "{ONLINE_ENDPOINT_TYPE}" or "{BATCH_ENDPOINT_TYPE}", provided is {type}. Inner error message: {e}'
            )
            raise e

    def dump(self, path: Union[PathLike, str]) -> None:
        pass

    def _merge_with(self, other: "Endpoint") -> None:
        if other:
            if self._name != other._name:
                raise Exception(f"The endpoint name: {self._name} and {other._name} are not matched when combining.")
            if self.type != other.type:
                raise Exception(
                    f"The endpoint {self._name}'s type {self.type} are not matched with the endpoint {other._name}'s type {other.type}"
                )
            self.description = other.description or self.description
            if other.tags:
                self.tags = {**self.tags, **other.tags}
            if other.properties:
                self.properties = {**self.properties, **other.properties}
            self.auth_mode = other.auth_mode or self.auth_mode
            self.traffic = other.traffic
