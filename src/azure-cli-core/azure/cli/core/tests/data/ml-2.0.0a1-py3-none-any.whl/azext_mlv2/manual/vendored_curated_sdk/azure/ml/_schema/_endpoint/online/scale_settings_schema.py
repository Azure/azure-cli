# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import EndpointYamlFields, ScaleSettingsType
from marshmallow import ValidationError, fields, post_load, validates_schema

module_logger = logging.getLogger(__name__)


class ScaleSettingsSchema(metaclass=PatchedSchemaMeta):
    min_instances = fields.Int()
    max_instances = fields.Int()


class ManualScaleSettingsSchema(ScaleSettingsSchema):
    scale_type = StringTransformedEnum(
        required=True, allowed_values=ScaleSettingsType.MANUAL, casing_transform=(lambda x: x.lower().capitalize())
    )
    instance_count = fields.Int(required=True)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> "ManualScaleSettings":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ManualScaleSettings

        return ManualScaleSettings(**data)


class AutoScaleSettingsSchema(ScaleSettingsSchema):
    scale_type = StringTransformedEnum(
        required=True, allowed_values=ScaleSettingsType.AUTOMATIC, casing_transform=(lambda x: x.lower().capitalize())
    )
    polling_interval = fields.Int()
    target_utilization_percentage = fields.Int()

    @post_load
    def make(self, data: Any, **kwargs: Any) -> "AutoScaleSettings":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import AutoScaleSettings

        return AutoScaleSettings(**data)
