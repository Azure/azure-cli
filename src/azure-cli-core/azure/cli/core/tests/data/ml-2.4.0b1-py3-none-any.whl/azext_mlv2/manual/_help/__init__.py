# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azext_mlv2.manual.custom.utils import private_features_enabled

from ._component_help import get_component_help
from ._environment_help import get_environment_help
from ._model_help import get_model_help
from ._data_help import get_data_help
from ._dataset_help import get_dataset_help
from ._job_help import get_job_help
from ._online_endpoint_help import get_online_endpoint_help
from ._batch_endpoint_help import get_batch_endpoint_help
from ._online_deployment_help import get_online_deployment_help
from ._batch_deployment_help import get_batch_deployment_help
from ._workspace_help import get_workspace_help
from ._workspace_connection_help import get_workspace_connection_help
from ._compute_help import get_compute_help
from ._datastore_help import get_datastore_help

from knack.help_files import helps

get_environment_help()
get_model_help()
get_data_help()
get_dataset_help()
get_job_help()
get_online_endpoint_help()
get_batch_endpoint_help()
get_online_deployment_help()
get_batch_deployment_help()
get_compute_help()
get_workspace_help()
get_datastore_help()
get_component_help()
get_workspace_connection_help()

helps[
    "ml"
] = """
    type: group
    short-summary: Manage Azure Machine Learning resources with the Azure CLI ML extension v2.

    long-summary: |
                  Install Azure CLI ML extension v2
                  https://docs.microsoft.com/azure/machine-learning/how-to-configure-cli
"""
