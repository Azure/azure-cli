# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict, List
from itertools import islice

from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities import (
    Compute,
    AmlCompute,
    KubernetesCompute,
    IdentityConfiguration,
    UserAssignedIdentity,
)
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.constants import ComputeType, COMPUTE_UPDATE_ERROR
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._load_functions import load_compute


IDENTITY_ERROR = "Identity_type can only be either of 'SystemAssigned', 'UserAssigned'"


def ml_compute_list(cmd, resource_group_name, workspace_name, type=None, max_results=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if max_results:
            results = islice(ml_client.compute.list(compute_type=type), int(max_results))
        else:
            results = ml_client.compute.list(compute_type=type)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_show(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return _dump_entity_with_warnings(ml_client.compute.get(name=name))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_list_nodes(cmd, resource_group_name, workspace_name, name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        nodes = ml_client.compute.list_nodes(name=name)
        return list(map(lambda x: _dump_entity_with_warnings(x), nodes))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_create(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=None,
    vnet_name=None,
    subnet=None,
    admin_username=None,
    admin_password=None,
    ssh_key_value=None,
    ssh_public_access_enabled=None,
    file=None,
    size=None,
    no_wait=False,
    user_tenant_id=None,
    user_object_id=None,
    min_instances=None,
    max_instances=None,
    idle_time_before_scale_down=None,
    description=None,
    identity_type=None,
    user_assigned_identities=None,
    tier=None,
    tags=None,
    params_override=None,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    if name:
        params_override.append({"name": name})
    if type:
        params_override.append({"type": type.lower()})
    if vnet_name:
        params_override.append({"network_settings.vnet_name": vnet_name})
    if subnet:
        params_override.append({"network_settings.subnet": subnet})
    if admin_username:
        params_override.append({"ssh_settings.admin_username": admin_username})
    if admin_password:
        params_override.append({"ssh_settings.admin_password": admin_password})
    if ssh_key_value:
        params_override.append({"ssh_settings.ssh_key_value": ssh_key_value})
    if size:
        params_override.append({"size": size})
    if user_tenant_id:
        params_override.append({"create_on_behalf_of.user_tenant_id": user_tenant_id})
    if user_object_id:
        params_override.append({"create_on_behalf_of.user_object_id": user_object_id})
    if min_instances:
        params_override.append({"min_instances": min_instances})
    if max_instances:
        params_override.append({"max_instances": max_instances})
    if idle_time_before_scale_down:
        params_override.append({"idle_time_before_scale_down": idle_time_before_scale_down})
    if description:
        params_override.append({"description": description})
    if identity_type:
        params_override.append({"identity.type": identity_type})
    if user_assigned_identities:
        identities = _process_user_assigned_identities(user_assigned_identities)
        params_override.append({"identity.user_assigned_identities": identities})
    if tier:
        params_override.append({"tier": tier})
    if ssh_public_access_enabled:
        params_override.append({"ssh_public_access_enabled": ssh_public_access_enabled})
    if tags:
        params_override.append({"tags": tags})

    try:
        compute = load_compute(path=file, params_override=params_override)

        compute = ml_client.begin_create_or_update(compute, no_wait=no_wait)
        return _dump_entity_with_warnings(compute)
    except Exception as e:
        log_and_raise_error(e, debug)


def ml_compute_delete(cmd, resource_group_name, workspace_name, name, no_wait=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.compute.begin_delete(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_start(cmd, resource_group_name, workspace_name, name, no_wait=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.compute.begin_start(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_stop(cmd, resource_group_name, workspace_name, name, no_wait=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.compute.begin_stop(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_restart(cmd, resource_group_name, workspace_name, name, no_wait=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.compute.begin_restart(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_list_sizes(cmd, resource_group_name, workspace_name, location=None, type=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        list_sizes = ml_client.compute.list_sizes(location=location, compute_type=type)
        return list(map(lambda x: _dump_entity_with_warnings(x), list_sizes))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_list_usage(cmd, resource_group_name, workspace_name, location=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        usagelist = ml_client.compute.list_usage(location=location)
        result = []
        for y, x in enumerate(usagelist):
            result.append(_dump_entity_with_warnings(x))
        return result
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_compute_update(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    max_instances=None,
    min_instances=None,
    idle_time_before_scale_down=None,
    identity_type=None,
    user_assigned_identities=None,
    parameters: Dict = None,
    no_wait: bool = False,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    compute_type = parameters["type"]
    if compute_type not in (ComputeType.AMLCOMPUTE, ComputeType.KUBERNETES):
        log_and_raise_error(COMPUTE_UPDATE_ERROR.format(name, compute_type))

    try:
        identity = None
        if identity_type or user_assigned_identities:
            if user_assigned_identities:
                user_assigned_identities = [
                    UserAssignedIdentity(resource_id=resource_id) for resource_id in user_assigned_identities.split(",")
                ]
            identity = IdentityConfiguration(type=identity_type, user_assigned_identities=user_assigned_identities)
        if compute_type == ComputeType.AMLCOMPUTE:
            compute = AmlCompute(
                name=name,
                location=parameters["location"],
                max_instances=max_instances if max_instances else parameters["max_instances"],
                min_instances=min_instances if min_instances else parameters["min_instances"],
                idle_time_before_scale_down=idle_time_before_scale_down
                if idle_time_before_scale_down
                else parameters.get("idle_time_before_scale_down", None),
                identity=identity,
            )
        elif compute_type == ComputeType.KUBERNETES:
            parameters["properties"]["namespace"] = parameters["namespace"]
            compute = KubernetesCompute(
                name=name,
                location=parameters["location"],
                identity=identity,
                namespace=parameters["namespace"],
                properties=parameters["properties"],
            )
        compute = ml_client.compute.begin_update(compute, no_wait=no_wait)
        return _dump_entity_with_warnings(compute)
    except Exception as err:
        log_and_raise_error(err, debug)


def _validate_identity(identity_type, user_assigned_identities):
    if identity_type:
        if identity_type not in ["SystemAssigned", "UserAssigned", "None"]:
            raise ValueError(IDENTITY_ERROR)


# Convert comma separated strings to a list of dictionaries
def _process_user_assigned_identities(resource_ids: str) -> List[dict]:
    return [{"resource_id": resource_id} for resource_id in resource_ids.split(",")]


def ml_compute_attach(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=None,
    resource_id=None,
    admin_username=None,
    admin_password=None,
    ssh_port=None,
    no_wait=False,
    ssh_private_key_file=None,
    file=None,
    namespace=None,
    identity_type=None,
    user_assigned_identities=None,
):
    _validate_identity(identity_type, user_assigned_identities)
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    params_override = []
    if name:
        params_override.append({"name": name})
    if ssh_private_key_file:
        params_override.append({"ssh_settings.ssh_private_key_file": ssh_private_key_file})
    if admin_username:
        params_override.append({"ssh_settings.admin_username": admin_username})
    if admin_password:
        params_override.append({"ssh_settings.admin_password": admin_password})
    if ssh_port:
        params_override.append({"ssh_settings.ssh_port": ssh_port})
    if type:
        params_override.append({"type": type})
    if resource_id:
        params_override.append({"resource_id": resource_id})
    if namespace:
        params_override.append({"namespace": namespace})
    if identity_type:
        params_override.append({"identity.type": identity_type})
    if user_assigned_identities:
        identities = _process_user_assigned_identities(user_assigned_identities)
        params_override.append({"identity.user_assigned_identities": identities})
    try:
        compute = load_compute(path=file, params_override=params_override)
        if compute.type == "kubernetes":
            if not compute.resource_id:
                raise Exception('The "resource_id" is a required parameter for attaching a kubernetes compute!')
        return _dump_entity_with_warnings(ml_client.begin_create_or_update(compute, no_wait=no_wait))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_detach(cmd, resource_group_name, workspace_name, name, no_wait=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.compute.begin_delete(
            name=name,
            action="Detach",
            no_wait=no_wait,
        )
    except Exception as err:
        log_and_raise_error(err, debug)
