.. :changelog:

Release History
===============
0.1.5 (2017-06-21)
++++++++++++++++++
* No changes.

0.1.4 (2017-06-13)
++++++++++++++++++
* Move all existing recording files to latest folder

0.1.3 (2017-05-30)
------------------
* Minor fixes.

0.1.2 (2017-05-09)
------------------
* Minor fixes.

0.1.1 (2017-05-05)
------------------
* Minor fix - Use new style module packaging.

0.1.0 (2017-05-05)
------------------
* inital cognitive services CLI

