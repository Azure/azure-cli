from azure.cli.core.help_files import helps

helps['hello world'] = """
    type: command
    short-summary: Test test test test.
"""

def helloworld():
    print('HELLO WORLD!')

def load_params(_):
    pass

def load_commands():
    from azure.cli.core.commands import cli_command
    cli_command(__name__, 'hello world', 'azext_hello#helloworld')
