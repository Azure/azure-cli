# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities import BatchDeployment as Deployment
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.entities._load_functions import load_batch_deployment


def ml_batch_deployment_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    endpoint_name=None,
    name=None,
    no_wait=False,
    set_default=False,
    params_override=None,
    **kwargs
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    try:
        if name:
            params_override.append({"name": name})
        if endpoint_name:
            params_override.append({"endpoint_name": endpoint_name})
        deployment = load_batch_deployment(path=file, params_override=params_override)
        deployment = ml_client.begin_create_or_update(entity=deployment, no_wait=no_wait)

        if set_default:
            endpoint = ml_client.batch_endpoints.get(deployment.endpoint_name)
            endpoint.defaults = {"deployment_name": deployment.name}
            endpoint = ml_client.begin_create_or_update(entity=endpoint)
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        deployment = ml_client.batch_deployments.get(name, endpoint_name)
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    endpoint_name,
    no_wait=False,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.batch_deployments.begin_delete(name, endpoint_name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_list(cmd, resource_group_name, workspace_name, endpoint_name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return list(
            map(
                lambda deployment: _dump_entity_with_warnings(deployment),
                ml_client.batch_deployments.list(endpoint_name),
            )
        )
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_list_jobs(cmd, resource_group_name, workspace_name, name, endpoint_name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        results = ml_client.batch_deployments.list_jobs(endpoint_name=endpoint_name, name=name)
        return list(map(lambda deployment: _dump_entity_with_warnings(deployment), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_update(
    cmd,
    resource_group_name,
    workspace_name,
    no_wait=False,
    parameters: Dict = None,
    file=None,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        deployment = Deployment.load_from_dict(data=parameters, path=file)
        deployment = ml_client.begin_create_or_update(entity=deployment, no_wait=no_wait)
        if deployment:  # TODO: https://msdata.visualstudio.com/Vienna/_workitems/edit/1252491/
            return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_batch_deployment_show(cmd, resource_group_name, workspace_name, name=None, endpoint_name=None, file=None):
    params_override = []
    if name:
        params_override.append({"name": name})

    if endpoint_name:
        params_override.append({"endpoint_name": endpoint_name})
    if file:
        return load_batch_deployment(file, params_override=params_override)._to_dict()
    else:
        return ml_batch_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name)
