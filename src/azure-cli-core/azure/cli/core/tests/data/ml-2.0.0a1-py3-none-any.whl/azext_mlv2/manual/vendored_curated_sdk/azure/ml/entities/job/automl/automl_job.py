# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import (
    JobBaseResource,
    AutoMLJob as RestAutoMLJob,
    GeneralSettings,
    LimitSettings,
    TrainingSettings,
    DataSettings,
    CodeConfiguration,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import JobType, TYPE, BASE_PATH_CONTEXT_KEY
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Job
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.automl.featurization import FeaturizationSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.automl.forecasting import ForecastingSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import InternalComputeConfiguration
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.automl import AutoMLJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import (
    to_iso_duration_format_mins,
    from_iso_duration_format_mins,
)

module_logger = logging.getLogger(__name__)


class AutoMLJob(Job):
    """AutoMLJob

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param description: Description of the resource.
    :type description: str
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param base_path: TBD.
    :type base_path: str
    :param experiment_name:  Name of the experiment the job will be created under, if None is provided, job will be created under experiment 'Default'.
    :type experiment_name: str
    :param status: Status of the job.
    :type status: str
    :param creation_context: Creation metadata of the job.
    :type creation_context: SystemData
    :param interaction_endpoints: Infomation on how to interact with the job.
    :type interaction_endpoints: dict[str, JobEndpoint]
    :param general_settings: The general settings of the AutoML Job
    :type general_settings: GeneralSettings
    :param data_settings: The data settings containing the training and validation dataset information
    :type data_settings: DataSettings
    :param experiment_limits: Limit settings for the job
    :type experiment_limits: ExperimentLimits
    :param forecasting_settings: Forecasting-specific parameters for the job
    :type forecasting_settings: ForecastingSettings
    :param training_settings: Training-related settings for the job
    :type training_settings: TrainingSettings
    :param featurization_settings: Featurization configuration for the job
    :type featurization_settings: FeaturizationSettings
    :param compute: Compute defintion containing the compute information for the job
    :type compute: InternalComputeConfiguration
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    def __init__(
        self,
        general_settings: GeneralSettings = None,
        data_settings: DataSettings = None,
        limit_settings: LimitSettings = None,
        forecasting_settings: ForecastingSettings = None,
        training_settings: TrainingSettings = None,
        featurization_settings: FeaturizationSettings = None,
        compute: InternalComputeConfiguration = None,
        **kwargs,
    ):
        kwargs[TYPE] = JobType.AUTOML
        super().__init__(**kwargs)
        self.general_settings = general_settings
        self.data_settings = data_settings
        self.limit_settings = limit_settings
        self.forecasting_settings = forecasting_settings
        self.training_settings = training_settings
        self.featurization_settings = featurization_settings
        self.compute = compute

    @classmethod
    def _load_from_dict(cls, data: Dict, context: Dict, additional_message: str = None, **kwargs) -> "AutoMLJob":
        loaded_schema = load_from_dict(AutoMLJobSchema, data, context, additional_message, **kwargs)
        return AutoMLJob(**loaded_schema)

    def _to_rest_object(self) -> JobBaseResource:
        # convert the job timeout and trial timeout to isodate format\
        self.limit_settings.trial_timeout = to_iso_duration_format_mins(self.limit_settings.trial_timeout)
        self.limit_settings.job_timeout = to_iso_duration_format_mins(self.limit_settings.job_timeout)
        rest_job = RestAutoMLJob(
            compute=self.compute.dump_to_rest(),
            description=self.description,
            tags=self.tags,
            properties=self.properties,
            experiment_name=self.experiment_name,
            general_settings=self.general_settings,
            limit_settings=self.limit_settings,
            data_settings=self.data_settings,
            featurization_settings=self.featurization_settings._to_rest_object()
            if self.featurization_settings
            else None,
            forecasting_settings=self.forecasting_settings._to_rest_object() if self.forecasting_settings else None,
            training_settings=self.training_settings,
        )
        automl_job_resource = JobBaseResource(properties=rest_job)
        automl_job_resource.name = self.name
        return automl_job_resource

    @classmethod
    def _load_from_rest(cls, obj: JobBaseResource) -> "AutoMLJob":
        properties: RestAutoMLJob = obj.properties
        rest_compute = properties.compute
        # convert the trial and job timeout from iso format
        if properties.limit_settings:
            properties.limit_settings.trial_timeout = from_iso_duration_format_mins(
                properties.limit_settings.trial_timeout
            )
            properties.limit_settings.job_timeout = from_iso_duration_format_mins(properties.limit_settings.job_timeout)
        compute = InternalComputeConfiguration(
            target=rest_compute.target,
            is_local=rest_compute.is_local,
            instance_count=rest_compute.instance_count,
            properties=rest_compute.properties,
        )
        return AutoMLJob(
            name=obj.name,
            id=obj.id,
            description=properties.description,
            tags=properties.tags,
            properties=properties.properties,
            experiment_name=properties.experiment_name,
            status=properties.status,
            creation_context=obj.system_data,
            interaction_endpoints=properties.interaction_endpoints,
            compute=compute,
            general_settings=properties.general_settings,
            limit_settings=properties.limit_settings,
            data_settings=properties.data_settings,
            forecasting_settings=ForecastingSettings._from_rest_object(properties.forecasting_settings)
            if properties.forecasting_settings
            else None,
            featurization_settings=FeaturizationSettings._from_rest_object(properties.featurization_settings)
            if properties.featurization_settings
            else None,
            training_settings=properties.training_settings,
        )

    def _dump_yaml(self) -> Dict:
        return AutoMLJobSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    def __eq__(self, other: "AutoMLJob") -> bool:
        return (
            self.compute == other.compute
            and self.description == other.description
            and self.tags == other.tags
            and self.properties == other.properties
            and self.experiment_name == other.experiment_name
            and self.general_settings == other.general_settings
            and self.limit_settings == other.limit_settings
            and self.data_settings == other.data_settings
            and self.featurization_settings == other.featurization_settings
            and self.training_settings == other.training_settings
        )

    def __ne__(self, other: "AutoMLJob") -> bool:
        return not self.__eq__(other)
