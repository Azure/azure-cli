# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import uuid
from typing import Dict, Union
from os import PathLike

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.resource import Resource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import SystemData
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import dump_yaml_to_file


class Asset(Resource):
    """Base class for asset, can't be instantiated directly.

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param base_path: TBD.
    :type base_path: str
    :param version: Version of the asset.
    :type version: int
    :param description: Description of the resource.
    :type description: str
    :param creation_context: Creation metadata of the asset.
    :type creation_context: SystemData
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    def __init__(
        self,
        name: str = None,
        id: str = None,
        base_path: str = None,
        version: int = None,
        description: str = None,
        creation_context: SystemData = None,
        tags: Dict = None,
        properties: Dict = None,
        **kwargs,
    ):

        self._is_anonymous = kwargs.pop("is_anonymous", False)

        if not name and version is None:
            name = str(uuid.uuid4())
            version = 1
            self._is_anonymous = True
        elif name and version is None:
            raise Exception("If asset name is specified, version must be specified also.")
        elif version is not None and not name:
            raise Exception("If version is specified, name must be specified also.")

        super().__init__(
            name=name, id=id, description=description, tags=tags, properties=properties, base_path=base_path, **kwargs
        )

        self._creation_context = creation_context

        self.version = version

    @property
    def version(self) -> int:
        return self._version

    @version.setter
    def version(self, value: int) -> None:
        if value is None:
            self._version = value
        elif str(value).isdigit() and int(value) > 0:
            self._version = int(value)
        else:
            raise Exception("Asset version must be a non-zero integer.")

    @property
    def creation_context(self) -> SystemData:
        return self._creation_context

    def dump(self, path: Union[PathLike, str]) -> None:
        """Dump the artifact content into a file in yaml format.

        :param path: Path to a local file as the target, new file will be created, raises exception if the file exists.
        :type path: str
        """
        yaml_serialized = self._dump_yaml()
        dump_yaml_to_file(path, yaml_serialized, default_flow_style=False)

    def __eq__(self, other) -> bool:
        return (
            self.name == other.name
            and self.id == other.id
            and self.version == other.version
            and self.description == other.description
            and self.tags == other.tags
            and self.properties == other.properties
            and self.base_path == other.base_path
            and self._is_anonymous == other._is_anonymous
        )

    def __ne__(self, other) -> bool:
        return not self.__eq__(other)
