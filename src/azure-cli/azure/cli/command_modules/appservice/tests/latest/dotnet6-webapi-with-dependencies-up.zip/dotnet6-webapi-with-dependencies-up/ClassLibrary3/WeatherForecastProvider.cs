﻿using ClassLibrary3.Interfaces;

namespace ClassLibrary3
{
    public class WeatherForecastProvider: IWeatherForecastProvider
    {
        public IEnumerable<WeatherForecastDTO> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecastDTO
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureInCelsius = Random.Shared.Next(-20, 55),
                SummaryId = Random.Shared.Next(9)
            });
        }
    }
}