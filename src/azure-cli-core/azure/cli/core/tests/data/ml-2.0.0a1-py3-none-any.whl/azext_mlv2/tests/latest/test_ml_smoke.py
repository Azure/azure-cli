# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import pytest

from azure.cli.core import MainCommandsLoader, AzCli
from azure.cli.core.commands import AzCliCommandInvoker, ExtensionCommandSource
from azure.cli.core.util import get_az_version_string
from azure.cli.core.parser import AzCliCommandParser
from azure.cli.core._help import AzCliHelp, CliCommandHelpFile, ArgumentGroupRegistry
from azure.cli.testsdk import ScenarioTest
from io import StringIO
from typing import Any
from unittest.mock import Mock, patch
from ..util import *


def get_extension_commands():

    cli_ctx = AzCli(
        cli_name="az",
        commands_loader_cls=MainCommandsLoader,
        invocation_cls=AzCliCommandInvoker,
        parser_cls=AzCliCommandParser,
        help_cls=AzCliHelp,
    )

    # 1. Create invoker and load command table.
    invoker = cli_ctx.invocation_cls(
        cli_ctx=cli_ctx,
        commands_loader_cls=cli_ctx.commands_loader_cls,
        parser_cls=cli_ctx.parser_cls,
        help_cls=cli_ctx.help_cls,
    )

    cmd_table = invoker.commands_loader.load_command_table(None)

    #   filter the command table to only get commands from extensions
    cmd_table = {k: v for k, v in cmd_table.items() if isinstance(v.command_source, ExtensionCommandSource)}
    print("FOUND {} command(s) from the extension.".format(len(cmd_table)))

    # return the actual commands
    return cmd_table.keys()


def check_successful_exit(exit: Any):
    assert exit.type == SystemExit
    assert exit.value.code == 0


def check_command_output(output: str, command: str):
    assert command in output
    assert "Arguments" in output


@patch("azure.cli.core.util.check_connectivity", Mock())
class MlSmokeTests(ScenarioTest):
    def __init__(self, method_name: Any) -> None:
        super().__init__(
            method_name,
            recording_processors=[
                UserAgentRemover(),
            ],
            replay_processors=[
                UserAgentRemover(),
            ],
        )

    def test_all_commands_for_smoke(self) -> None:

        # Tests below will try to retrieve the
        # --help for all "az ml" commands.

        # From time to time,
        # az cli may check for updates
        # when retrieving commands help.
        # https://github.com/Azure/azure-cli/blob/f92cea11e4e97af64c41ab7d35562639fc9d71b9/src/azure-cli-core/azure/cli/core/util.py#L345

        # That update check may include a
        # connectivity check by issuing
        # a HEAD request to example.org.
        # https://github.com/Azure/azure-cli/blob/f92cea11e4e97af64c41ab7d35562639fc9d71b9/src/azure-cli-core/azure/cli/core/util.py#L778

        # Sometimes example.org seem to be
        # returning incosistent gzip and content
        # size headers, triggering a vcr error.

        # This statement will force the
        # check for updates, so the cassette is
        # generated all the time.
        # When recreating the cassette,
        # you may need to try a few times!
        get_az_version_string(use_cache=False)

        # Get all the commands
        commands = get_extension_commands()

        # Execute each cli command
        for command in commands:
            # Rewind the cassette to use it for each command
            self.cassette.rewind()
            with pytest.raises(SystemExit) as exit, patch("sys.stdout", new=StringIO()) as fake_out:
                self.cmd(f"{command} --help")

            # Smoke check on output and exit code
            check_command_output(fake_out.getvalue(), command)
            check_successful_exit(exit)
