# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_environment_help():
    helps[
        "ml environment"
    ] = """
        type: group
        short-summary: Manage Azure ML environments.
        long-summary: >
            Azure ML environments define the execution environment for jobs and endpoint deployments,
            encapsulating the dependencies for training and inference. These environment definitions
            are built into Docker images.
    """
    helps[
        "ml environment list"
    ] = """
        type: command
        short-summary: List environments in a workspace.
        examples:
        - name: List all the environments in a workspace
          text: az ml environment list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the environment versions for the specified name in a workspace
          text: az ml environment list --name my-env --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml environment show"
    ] = """
        type: command
        short-summary: Show details for an environment.
        examples:
        - name: Show details for an environment with the specified name and version
          text: az ml environment show --name my-env --version 1 --resource-group my-resource-group --workspace-name my-workspace
        - name: Show details for the latest version of an environment with the specified name
          text: az ml environment show --name my-env --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml environment create"
    ] = """
        type: command
        short-summary: Create an environment.
        long-summary: >
            Environments can be defined from a Docker image, Dockerfile, or Conda file.
            Azure ML maintains a set of CPU and GPU Docker images that you can use as base images.
            For information on these images, see https://github.com/Azure/AzureML-Containers.


            The created environment will be tracked in the workspace under the specified name
            and version.
        examples:
        - name: Create an environment from a YAML specification file
          text: az ml environment create --file my_env.yml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml environment delete"
    ] = """
        type: command
        short-summary: Delete an environment.
    """
    helps[
        "ml environment update"
    ] = """
        type: command
        short-summary: Update an environment.
        long-summary: >
            Only the 'description' and 'tags' properties can be updated.
    """
