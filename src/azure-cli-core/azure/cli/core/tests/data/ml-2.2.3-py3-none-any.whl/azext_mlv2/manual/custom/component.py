# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict
from itertools import islice

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ComponentVersion
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings


def ml_component_list(cmd, resource_group_name, workspace_name, name=None, max_results=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if max_results:
            results = islice(ml_client.components.list(name=name), int(max_results))
        else:
            results = ml_client.components.list(name=name)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_component_show(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        component = ml_client.components.get(name=name, version=version, label=label)
        return _dump_entity_with_warnings(component)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_component_create(cmd, file, resource_group_name, workspace_name, version=None, params_override=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    try:
        # 1. update override params
        if version:
            params_override.append({"version": version})
        # 2. load to component schema
        component = ComponentVersion.load(path=file, params_override=params_override)
        # 3. create component
        result = ml_client.create_or_update(component)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_component_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        # 1. load parameters into component entity
        component_entity = ComponentVersion._load(data=parameters, yaml_path=".")
        # 2. update the component
        result = ml_client.create_or_update(component_entity)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        log_and_raise_error(err, debug)
