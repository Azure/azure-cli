import json
import traceback
from colorama import init
from azure.core.exceptions import HttpResponseError, ODataV4Format, AzureError
from requests.exceptions import SSLError, HTTPError
from jmespath.exceptions import JMESPathError
from msrestazure.azure_exceptions import CloudError
from msrest.exceptions import HttpOperationError, ValidationError, ClientRequestError
from azure.common import AzureException
from azure.cli.core import azclierror
from azure.cli.core.style import print_styled_text, Style
from knack.log import get_logger
from knack.cli import CLIError

from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.constants import LIMITED_RESULTSET_WARNING_FORMAT

module_logger = get_logger()

init()


def print_styled_text_with_level(level, text):
    if not isinstance(text, str):
        text = str(text)
    print_styled_text(
        [
            (
                level,
                text,
            )
        ]
    )


def _extract_error_from_details(error_details):
    """
    Converts error message to ARMErrorFormat (if possible)
    and builds error message from it. Otherwise raise exception
    by using message for error passed.
    """
    if isinstance(error_details, str):
        return error_details
    try:
        if hasattr(error_details, "message"):
            json_error = json.loads(error_details.message)
        else:
            json_error = json.loads(error_details)
        formatted_error = ODataV4Format(json_object=json_error)
        return formatted_error.message_details()
    except Exception:
        module_logger.debug(f"Error parsing details of deployment failed error : {error_details.message}")
        return error_details.message_details()


def _handle_deployment_failed_error(error_response):
    """
    Extracts error message from error details and returns an exception
    """
    if error_response.error.details:
        details = error_response.error.details
        for error_details in details:
            # For time being only handling first element. Assuming there will be only one error message
            # coming from service side rather then clubbing multiple together
            return _extract_error_from_details(error_details)
    return error_response


def log_and_raise_error(error, debug=False):
    # use an f-string to automatically call str() on error
    if debug:
        module_logger.error(traceback.print_exc())

    if isinstance(error, HttpResponseError):
        module_logger.debug(f"Received HttpResponseError: {traceback.format_exc()}")

        if error.error and isinstance(error.error, ODataV4Format):
            if error.error and error.error.code and error.error.code == "DeploymentFailed":
                processed_error = _handle_deployment_failed_error(error_response=error)
                cli_error = azclierror.DeploymentError(processed_error)
            else:
                cli_error = error
        elif (
            hasattr(error, "response")
            and hasattr(error.response, "internal_response")
            and error.response.internal_response.text
        ):
            cli_error = HttpResponseError(error.response.internal_response.text)
            cli_error.response = error.response
        else:
            cli_error = error
    # For common error types listed below, let AzureCLI error handling to process it so the error can be classified properly.
    # https://github.com/Azure/azure-cli/blob/110f7b402020f3d3ebd2bfb923ac5a01d026cdd1/src/azure-cli-core/azure/cli/core/util.py#L207
    elif isinstance(
        error,
        (
            azclierror.AzCLIError,
            JMESPathError,
            SSLError,
            CloudError,
            ValidationError,
            CLIError,
            AzureError,
            AzureException,
            ClientRequestError,
            HttpOperationError,
            HTTPError,
            KeyboardInterrupt,
        ),
    ):
        cli_error = error
    else:
        module_logger.debug(traceback.format_exc())

        # For any other error, wrap as 'CLIError' otherwise AzureCLI will treat it as unexpected error
        cli_error = CLIError(f"Met error {type(error)}:{error}\nPlease check log in debug mode for more details.")

    raise cli_error


def print_limited_result_set_warning(max_results):
    print_styled_text_with_level(Style.WARNING, str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
