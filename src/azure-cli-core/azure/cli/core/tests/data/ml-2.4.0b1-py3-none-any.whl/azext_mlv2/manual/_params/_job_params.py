# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azext_mlv2.manual.custom.utils import private_features_enabled

from ._common_params import (
    add_common_params,
    add_override_param,
    add_include_archived_param,
    add_archived_only_param,
    add_file_param,
)
from azure.cli.core.commands.parameters import get_three_state_flag
from azext_mlv2.manual.vendored_curated_sdk.azure.ai.ml.constants import YAMLRefDocLinks


def add_job_common_params(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the job.")


def load_job_params(self):
    with self.argument_context("ml job create") as c:
        add_common_params(c)
        add_job_common_params(c)
        add_override_param(c)
        add_file_param(c, "job", [YAMLRefDocLinks.COMMAND_JOB, YAMLRefDocLinks.SWEEP_JOB, YAMLRefDocLinks.PIPELINE_JOB])
        c.argument(
            "save_as",
            options_list=["--save-as", "-a"],
            help="File to which the created job's state in YAML format will be written.",
        )
        c.argument(
            "stream", options_list=["--stream", "-s"], help="Indicates whether to stream the job's logs to the console."
        )
        c.argument(
            "web", options_list=["--web", "-e"], help="Show the job's run details in Azure ML studio in a web browser."
        )

    with self.argument_context("ml job update") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument(
            "web", options_list=["--web", "-e"], help="Show the job's run details in Azure ML studio in a web browser."
        )

    with self.argument_context("ml job list") as c:
        add_common_params(c)
        c.argument(
            "max_results",
            options_list=["--max-results", "-r"],
            type=int,
            help="Max number of results to return. Default is 50",
        )
        c.argument("all_results", arg_type=get_three_state_flag(), help="Returns all results.")
        add_include_archived_param(c, help_message="List archived jobs and active jobs.")
        add_archived_only_param(c, help_message="List archived jobs only.")
        c.argument(
            "parent_job_name",
            options_list=["--parent-job-name", "-p"],
            type=str,
            help="Name of the parent job. Will list all jobs whose parent_job_name matches the given name.",
        )
        if private_features_enabled():
            c.argument(
                "schedule_defined",
                options_list=["--schedule-defined"],
                action="store_true",
                help="If passed, only jobs that initially defined a schedule will be listed.",
            )
            c.argument(
                "scheduled_job_name",
                options_list=["--scheduled-job-name"],
                type=str,
                help="Name of a job that initially defined a schedule. All jobs that were triggered by this job's schedule will be listed.",
            )

    with self.argument_context("ml job show") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument(
            "web", options_list=["--web", "-e"], help="Show the job's run details in Azure ML studio in a web browser."
        )

    with self.argument_context("ml job download") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument(
            "download_path",
            options_list=["--download-path", "-p"],
            help="Path to download the job files to. If omitted, job files will be downloaded to the current directory.",
        )
        c.argument(
            "output_name",
            options_list=["--output-name"],
            help="The name of the user-defined output to download. This should correspond to a key in the outputs dictionary of a job. If omitted, the job's default artifact output files will be downloaded.",
        )
        c.argument("all", options_list=["--all"], help="Download all the outputs of the job.")

    with self.argument_context("ml job stream") as c:
        add_common_params(c)
        add_job_common_params(c)

    with self.argument_context("ml job cancel") as c:
        add_common_params(c)
        add_job_common_params(c)

    with self.argument_context("ml job archive") as c:
        add_common_params(c)
        add_job_common_params(c)

    with self.argument_context("ml job restore") as c:
        add_common_params(c)
        add_job_common_params(c)
