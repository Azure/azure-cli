# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import UnionField
from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField
from .scale_settings_schema import AutoScaleSettingsSchema, ManualScaleSettingsSchema
from .request_settings_schema import RequestSettingsSchema
from .resource_requirements_schema import ResourceRequirementsSchema
from .liveness_probe import LivenessProbeSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.deployment import DeploymentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import BASE_PATH_CONTEXT_KEY

module_logger = logging.getLogger(__name__)


class OnlineDeploymentSchema(DeploymentSchema):
    name = fields.Str(required=True)
    app_insights_enabled = fields.Bool()
    scale_settings = UnionField([NestedField(AutoScaleSettingsSchema), NestedField(ManualScaleSettingsSchema)])
    request_settings = NestedField(RequestSettingsSchema)
    liveness_probe = NestedField(LivenessProbeSchema)
    provisioning_state = fields.Str()


class K8sOnlineDeploymentSchema(OnlineDeploymentSchema):
    resource_requirements = NestedField(ResourceRequirementsSchema)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import K8sOnlineDeployment

        return K8sOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class ManagedOnlineDeploymentSchema(OnlineDeploymentSchema):
    instance_type = fields.Str()
    readiness_probe = NestedField(LivenessProbeSchema)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ManagedOnlineDeployment

        return ManagedOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
