# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import fields
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import (
    PathAwareSchema,
    UnionField,
    NestedField,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.input_output import InputPortSchema, ParameterSchema, OutputPortSchema


class BaseComponentSchema(PathAwareSchema):
    name = fields.Str(required=True)
    version = fields.Int(required=True)  # currently only int type is supported
    display_name = fields.Str()
    description = fields.Str()
    tags = fields.Dict(keys=fields.Str(), values=fields.Str())
    is_deterministic = fields.Bool()
    inputs = fields.Dict(
        keys=fields.Str(),
        values=UnionField(
            [
                NestedField(InputPortSchema),
                NestedField(ParameterSchema),
            ]
        ),
    )
    outputs = fields.Dict(keys=fields.Str(), values=NestedField(OutputPortSchema))
