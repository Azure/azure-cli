# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import BatchDeployment as Deployment
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings


def ml_batch_deployment_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    endpoint_name=None,
    name=None,
    no_wait=False,
    set_default=False,
    params_override=None,
    **kwargs
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    params_override = params_override or []

    try:
        if name:
            params_override.append({"name": name})
        if endpoint_name:
            # Endpoint names are case insensitive, but given the case sensitive nature of MFE the convention is to always use lowercase
            params_override.append({"endpoint_name": endpoint_name.lower()})
        deployment = Deployment.load(path=file, params_override=params_override)
        deployment = ml_client.begin_create_or_update(entity=deployment, no_wait=no_wait)

        if set_default:
            endpoint = ml_client.batch_endpoints.get(deployment.endpoint_name)
            endpoint.defaults = {"deployment_name": deployment.name}
            endpoint = ml_client.begin_create_or_update(entity=endpoint)
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        deployment = ml_client.batch_deployments.get(name, endpoint_name)
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    endpoint_name,
    no_wait=False,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.batch_deployments.begin_delete(name, endpoint_name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_list(cmd, resource_group_name, workspace_name, endpoint_name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return list(
            map(
                lambda deployment: _dump_entity_with_warnings(deployment),
                ml_client.batch_deployments.list(endpoint_name),
            )
        )
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_list_jobs(cmd, resource_group_name, workspace_name, name, endpoint_name):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        return ml_client.batch_deployments.list_jobs(endpoint_name=endpoint_name, name=name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_deployment_update(
    cmd,
    resource_group_name,
    workspace_name,
    no_wait=False,
    parameters: Dict = None,
    file=None,
):
    """
    The update does not need to take parameters like `endpoint_name` and `file` because it's been
    preprocessed by the `_ml_batch_deployment_merge` function as a prestep defined generic_update_commands.

    See here for more information: https://github.com/Azure/azure-cli/blob/master/doc/authoring_command_modules/authoring_commands.md#generic-update-commands
    """
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        deployment = Deployment.load_from_dict(data=parameters, path=file)
        deployment = ml_client.begin_create_or_update(entity=deployment, no_wait=no_wait)
        if deployment:  # TODO: https://msdata.visualstudio.com/Vienna/_workitems/edit/1252491/
            return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_batch_deployment_show(cmd, resource_group_name, workspace_name, name=None, endpoint_name=None, file=None):
    params_override = []
    if name:
        params_override.append({"name": name})

    if endpoint_name:
        params_override.append({"endpoint_name": endpoint_name})
    if file:
        deployment = Deployment.load(file, params_override=params_override)
        return ml_batch_deployment_show(
            cmd, resource_group_name, workspace_name, deployment.name, deployment.endpoint_name
        )
    else:
        return ml_batch_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name)


def _ml_batch_deployment_merge(instance, name=None, endpoint_name=None, file=None):
    """
    instance is what `ml_batch_deployment_show` returns, and it is of Type Dict

    The purpose of this function is to merge the raw instance with file.
    The merging logic is that whatever resides in file overrides instance.
    """
    deployment = Deployment.load_from_dict(instance)
    params_override = []
    if endpoint_name:
        lower_endpoint_name = endpoint_name.lower()
        params_override.append({"endpoint_name": lower_endpoint_name})
        deployment.endpoint_name = lower_endpoint_name
    if file:
        params_override.append({"name": name})
        deployment._merge_with(Deployment.load(file, params_override=params_override))
    instance = _dump_entity_with_warnings(deployment)
    return instance
