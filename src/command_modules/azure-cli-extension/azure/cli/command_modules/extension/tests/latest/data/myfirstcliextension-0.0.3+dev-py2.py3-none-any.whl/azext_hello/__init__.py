from azure.cli.core.help_files import helps

helps['hello world'] = """
    type: command
    short-summary: Test test test test.
"""

print("Imported my extension")

def helloworld():
    print('HELLO WORLD!!')

def load_params(_):
    pass

def load_commands():
    from azure.cli.core.commands import cli_command
     # TODO This name has to be unique.
    cli_command(__name__, 'hello world', 'azext_hello#helloworld')
