# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import fields

from ..schema import PathAwareSchema
from ..fields import UnionField, FileRefField


class ComputeSchema(PathAwareSchema):
    name = fields.Str(required=True)
    location = fields.Str()
    type = fields.Str(required=True)
    tags = fields.Dict(keys=fields.Str(), values=fields.Str())
    description = fields.Str()
    size = fields.Str()
    admin_username = fields.Str()
    admin_password = fields.Str()
    ssh_key_value = UnionField([FileRefField(), fields.Str()])
    ssh_public_access = fields.Str()
    subnet = fields.Str()
    vnet_name = fields.Str()
    enable_public_ip = fields.Bool()
    user_tenant_id = fields.Str()
    user_object_id = fields.Str()
    min_instances = fields.Int()
    max_instances = fields.Int()
    idle_time_before_scale_down = fields.Int()
    state = fields.Str()
    resource_id = fields.Str()
    ssl_configuration = fields.Str()
    provisioning_errors = fields.Str(dump_only=True)
    identity_type = fields.Str()
    user_assigned_identities = fields.Str()
    applications = fields.List(fields.Dict(keys=fields.Str(), values=fields.Str()))
    created_on = fields.Str(dump_only=True)
    provisioning_state = fields.Str(dump_only=True)
    # Below are CI specific
    last_operation = fields.Dict(keys=fields.Str(), values=fields.Str())
    public_ip_address = fields.Str()
    private_ip_address = fields.Str()
    priority = fields.Str()
