# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._sweep.constants import TYPE, BASE_ERROR_MESSAGE
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import SearchSpace
from marshmallow import fields, post_load, ValidationError, pre_dump
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PatchedSchemaMeta


class UniformSchema(metaclass=PatchedSchemaMeta):
    type = StringTransformedEnum(required=True, allowed_values=SearchSpace.UNIFORM_LOGUNIFORM)
    min_value = fields.Float(required=True)
    max_value = fields.Float(required=True)

    @pre_dump
    def predump(self, data, **kwargs):
        if data.type.lower() not in SearchSpace.UNIFORM_LOGUNIFORM:
            raise ValidationError(BASE_ERROR_MESSAGE + str(SearchSpace.UNIFORM_LOGUNIFORM))
        return data

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Uniform, LogUniform

        return Uniform(**data) if data[TYPE] == SearchSpace.UNIFORM else LogUniform(**data)


class QUniformSchema(metaclass=PatchedSchemaMeta):
    type = StringTransformedEnum(required=True, allowed_values=SearchSpace.QUNIFORM_QLOGUNIFORM)
    min_value = fields.Float(required=True)
    max_value = fields.Float(required=True)
    q = fields.Int(required=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import QUniform, QLogUniform

        return QUniform(**data) if data[TYPE] == SearchSpace.QUNIFORM else QLogUniform(**data)
