# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from os import PathLike
from pathlib import Path
from typing import Dict, List, Optional, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    AKS,
    AKSProperties,
    AmlCompute,
    AmlComputeProperties,
    ComputeInstance,
    ComputeInstanceProperties,
    ComputeInstanceSshSettings,
    ComputeResource,
    PersonalComputeInstanceSettings,
    ResourceId,
    UserAccountCredentials,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute.compute import ComputeSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._compute_utils import make_identity_and_scale_settings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import dump_yaml_to_file, load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import load_from_dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BASE_PATH_CONTEXT_KEY,
    PARAMS_OVERRIDE_KEY,
    ComputeDefaults,
    ComputeType,
    CommonYamlFields,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Resource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin
from marshmallow.utils import RAISE
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.util import find_type_in_override


class Compute(Resource, RestTranslatableMixin):
    """Compute resource

    :param type: The type of the compute, possible values are ["aks", "managed", "amlcompute", "computeinstance", "virtualmachine"]
    :type type: str
    :param name: Name of the compute
    :type name: Optional[str], optional
    :param location: The resource location, defaults to None
    :type location: Optional[str], optional
    :param description: Description of the resource.
    :type description: Optional[str], optional
    :param size: Compute Size, defaults to None
    :type size: Optional[str], optional
    :param admin_username: Describes the admin user name., defaults to None
    :type admin_username: Optional[str], optional
    :param admin_password: Describes the admin user password, defaults to None
    :type admin_password: Optional[str], optional
    :param ssh_key_value:  Specifies the SSH rsa public key file as a string. Use "ssh-keygen -t
        rsa -b 2048" to generate your SSH key pairs.
    :type ssh_key_value: Optional[str], optional
    :param ssh_public_access: State of the public SSH port. Possible values are: Disabled -
        Indicates that the public ssh port is closed on this instance. Enabled - Indicates that the
        public ssh port is open and accessible according to the VNet/subnet policy if applicable.
        Possible values include: "Enabled", "Disabled". Default value: "Disabled". defaults to None
    :type ssh_public_access: Optional[bool], optional
    :param subnet:
    :type subnet: Optional[str], optional
    :param vnet_name: vnet name, defaults to None
    :type vnet_name: Optional[str], optional
    :param enable_public_ip: enable public ip, defaults to False
    :type enable_public_ip: Optional[bool], optional
    :param user_tenant_id: User’s AAD Tenant Id, defaults to None
    :type user_tenant_id: Optional[str], optional
    :param user_object_id: User’s AAD Object Id, defaults to None
    :type user_object_id: Optional[str], optional
    :param tags: Tags that can be specified by customers. defaults to None
    :type tags: Optional[Dict[str, str]], optional
    :param min_instances: Min number of nodes to use., defaults to None
    :type min_instances: Optional[int], optional
    :param max_instances: Max number of nodes to use., defaults to None
    :type max_instances: Optional[int], optional
    :param idle_time_before_scale_down: Node Idle Time before scaling down amlCompute. defaults to None
    :type idle_time_before_scale_down: Optional[int], optional
    :param state: defaults to None
    :type state: Optional[str], optional
    :param resource_id: ARM resource id of the underlying compute, defaults to None
    :type resource_id: Optional[str], optional
    :param ssl_configuration:
    :type ssl_configuration: Optional[str], optional
    :param provisioning_errors: defaults to None
    :type provisioning_errors: Optional[str], optional
    :param identity_type:  The identity type. Possible values include: "SystemAssigned",
        "SystemAssigned,UserAssigned", "UserAssigned", "None, defaults to None
    :type identity_type: Optional[str], optional
    :param user_assigned_identities: The user assigned identities associated with the resource., defaults to None
    :type user_assigned_identities: Optional[List[str]], optional
    :param applications: defaults to None
    :type applications: Optional[List[Dict[str, str]]], optional
    :param created_on: defaults to None
    :type created_on: Optional[str], optional
    :param provisioning_state: defaults to None
    :type provisioning_state: Optional[str], optional
    :param last_operation: defaults to None
    :type last_operation: Optional[Dict[str, str]], optional
    :param public_ip_address: defaults to None
    :type public_ip_address: Optional[str], optional
    :param private_ip_address:defaults to None
    :type private_ip_address: Optional[str], optional
    :param priority: [description], defaults to None
    :type priority: Virtual Machine priority. Possible values include: "Dedicated", "LowPriority"., optional
    """

    def __init__(
        self,
        type: str,
        name: Optional[str] = None,
        id: Optional[str] = None,
        location: Optional[str] = None,
        description: Optional[str] = None,
        size: Optional[str] = None,
        admin_username: Optional[str] = None,
        admin_password: Optional[str] = None,
        ssh_key_value: Optional[str] = None,
        ssh_public_access: Optional[bool] = False,
        subnet: Optional[str] = None,
        vnet_name: Optional[str] = None,
        enable_public_ip: Optional[bool] = False,
        user_tenant_id: Optional[str] = None,
        user_object_id: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        min_instances: Optional[int] = None,
        max_instances: Optional[int] = None,
        idle_time_before_scale_down: Optional[int] = None,
        state: Optional[str] = None,
        resource_id: Optional[str] = None,
        ssl_configuration: Optional[str] = None,
        provisioning_errors: Optional[str] = None,
        identity_type: Optional[str] = None,
        user_assigned_identities: Optional[List[str]] = None,
        applications: Optional[List[Dict[str, str]]] = None,
        created_on: Optional[str] = None,
        provisioning_state: Optional[str] = None,
        # Below are CI specific
        last_operation: Optional[Dict[str, str]] = None,
        public_ip_address: Optional[str] = None,
        private_ip_address: Optional[str] = None,
        priority: Optional[str] = None,
        **kwargs,
    ):
        super().__init__(name=name, description=description, tags=tags, **kwargs)
        self.location = location
        self.type = type.lower()
        self.size = size
        self.admin_username = admin_username
        self.admin_password = admin_password
        self.ssh_key_value = ssh_key_value
        self.ssh_public_access = ssh_public_access
        self.subnet = subnet
        self.vnet_name = vnet_name
        self.enable_public_ip = enable_public_ip
        self.user_tenant_id = user_tenant_id
        self.user_object_id = user_object_id
        self.min_instances = min_instances
        self.max_instances = max_instances
        self.idle_time_before_scale_down = idle_time_before_scale_down
        self.state = state
        self.resource_id = resource_id
        self.ssl_configuration = ssl_configuration
        self.provisioning_errors = provisioning_errors
        self.identity_type = identity_type
        self.user_assigned_identities = user_assigned_identities
        self.applications = applications
        self.created_on = created_on
        # Below are CI specific
        self.last_operation = last_operation
        self.public_ip_address = public_ip_address
        self.private_ip_address = private_ip_address
        self.priority = priority

    def set_defaults(self):  # TODO: the service should have defaults
        if not self.admin_username:
            self.admin_username = ComputeDefaults.ADMIN_USER
        if not self.size:
            self.size = ComputeDefaults.VMSIZE
        if not self.min_instances:
            self.min_instances = ComputeDefaults.MIN_NODES
        if not self.max_instances:
            self.max_instances = ComputeDefaults.MAX_NODES
        if not self.idle_time_before_scale_down:
            self.idle_time_before_scale_down = ComputeDefaults.IDLE_TIME

    def _to_rest_object(self) -> ComputeResource:
        self.set_defaults()
        compute_res = None
        ssh_settings = None
        if self.subnet:
            subnet_resource = ResourceId(additional_properties={}, id=self.subnet)
        else:
            subnet_resource = None
        if self.type == ComputeType.COMPUTEINSTANCE:
            if self.ssh_key_value:
                ssh_settings = ComputeInstanceSshSettings(
                    ssh_public_access="Enabled",
                    admin_user_name=self.admin_username,
                    admin_public_key=self.ssh_key_value,
                )

            personal_compute_instance_settings = None
            if self.user_object_id and self.user_tenant_id:
                personal_compute_instance_settings = PersonalComputeInstanceSettings(
                    assigned_user={"objectId": self.user_object_id, "tenantId": self.user_tenant_id}
                )

            compute_instance_prop = ComputeInstanceProperties(
                vm_size=self.size,
                subnet=subnet_resource,
                ssh_settings=ssh_settings,
                personal_compute_instance_settings=personal_compute_instance_settings,
            )
            compute_instance = ComputeInstance(
                description=self.description, compute_type=self.type, properties=compute_instance_prop
            )
            compute_res = ComputeResource(location=self.location, tags=self.tags, properties=compute_instance)
        elif self.type == ComputeType.AMLCOMPUTE:

            ssh_settings = None
            if self.ssh_key_value or self.admin_password:
                ssh_settings = UserAccountCredentials(
                    admin_user_name=self.admin_username,
                    admin_user_ssh_public_key=self.ssh_key_value,
                    admin_user_password=self.admin_password,
                )

            scale_settings, identity = make_identity_and_scale_settings(
                max_instances=self.max_instances,
                min_instances=self.min_instances,
                idle_time_before_scale_down=self.idle_time_before_scale_down,
                identity_type=self.identity_type,
                user_assigned_identities=self.user_assigned_identities,
            )

            aml_prop = AmlComputeProperties(
                vm_size=self.size,
                vm_priority=self.priority,
                user_account_credentials=ssh_settings,
                scale_settings=scale_settings,
                subnet=subnet_resource,
            )

            aml_comp = AmlCompute(description=self.description, compute_type=self.type, properties=aml_prop)
            compute_res = ComputeResource(
                location=self.location, tags=self.tags, properties=aml_comp, identity=identity
            )
        elif self.type == ComputeType.AKS:
            aks_prop = AKSProperties()
            aks_comp = AKS(resource_id=self.resource_id, compute_type=self.type, properties=aks_prop)
            compute_res = ComputeResource(location=self.location, tags=self.tags, properties=aks_comp)

        return compute_res

    @classmethod
    def _from_rest_object(cls, rest_obj: ComputeResource) -> "Compute":
        prop = rest_obj.properties
        if prop.compute_type.lower() == ComputeType.VIRTUALMACHINE:
            from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import VirtualMachineCompute

            return VirtualMachineCompute._from_rest_obj(rest_obj)
        cls = cls(type=prop.compute_type)
        cls.name = rest_obj.name
        cls.location = rest_obj.location
        cls.tags = rest_obj.tags
        cls.description = prop.description
        cls.created_on = prop.additional_properties["createdOn"]
        cls.provisioning_state = prop.provisioning_state
        if prop.resource_id:
            cls.resource_id = prop.resource_id

        if not cls.type:
            cls.type = "*** Unsupported Compute Type ***"
            return

        if cls.type.lower() not in (ComputeType.AMLCOMPUTE, ComputeType.COMPUTEINSTANCE, ComputeType.AKS):
            cls.type = "*** Unsupported Compute Type ***"
            return

        if cls.type.lower() == ComputeType.AMLCOMPUTE:
            cls.min_instances = prop.properties.scale_settings.min_node_count
            cls.max_instances = prop.properties.scale_settings.max_node_count
            if prop.properties.scale_settings.node_idle_time_before_scale_down:
                cls.idle_time_before_scale_down = (
                    prop.properties.scale_settings.node_idle_time_before_scale_down.total_seconds()
                )
            if rest_obj.identity:
                cls.identity_type = rest_obj.identity.type
                cls.user_assigned_identities = rest_obj.identity.user_assigned_identities

        if prop.provisioning_errors:
            cls.provisioning_errors = prop.provisioning_errors[0].error.code
            return cls

        if not cls.type.lower() == ComputeType.AKS and prop.properties.subnet:
            cls.subnet = prop.properties.subnet.id
        if cls.type.lower() == ComputeType.AKS:
            cls.size = prop.properties.agent_vm_size
        else:
            cls.size = prop.properties.vm_size
            if cls.type.lower() == ComputeType.COMPUTEINSTANCE:
                cls.state = prop.properties.state
                cls.public_ip_address = prop.properties.connectivity_endpoints.public_ip_address
                cls.private_ip_address = prop.properties.connectivity_endpoints.private_ip_address
                cls.last_operation = prop.properties.last_operation.as_dict()
                cls.applications = []
                for app in prop.properties.applications:
                    cls.applications.append(app.as_dict())
        return cls

    def dump(self, path: Union[PathLike, str]) -> None:
        """Dump the compute content into a file in yaml format.

        :param path: Path to a local file as the target, new file will be created, raises exception if the file exists.
        :type path: str
        """

        yaml_serialized = self._dump_yaml()
        dump_yaml_to_file(path, yaml_serialized, default_flow_style=False)

    def _dump_yaml(self) -> Dict:
        return ComputeSchema(context={BASE_PATH_CONTEXT_KEY: "./"}).dump(self)

    @classmethod
    def load(
        cls,
        path: Union[PathLike, str],
        params_override: list = None,
        **kwargs,
    ) -> "Compute":
        """Construct a compute object from a yaml file.

        :param path: Path to a local file as the source.
        :type path: str
        :param params_override: Fields to overwrite on top of the yaml file. Format is [{"field1": "value1"}, {"field2": "value2"}]
        :type params_override: list

        :return: Loaded compute object.
        :rtype: Compute
        """

        data = load_yaml(path)
        return Compute._load(data, path, params_override)

    @classmethod
    def _load(
        cls,
        data: Dict = {},
        yaml_path: Union[PathLike, str] = None,
        params_override: list = [],
        **kwargs,
    ) -> "Compute":

        context = {
            BASE_PATH_CONTEXT_KEY: Path(yaml_path).parent if yaml_path else Path("./"),
            PARAMS_OVERRIDE_KEY: params_override,
        }
        type_in_override = find_type_in_override(params_override) if params_override else None
        type = type_in_override or data.get(CommonYamlFields.TYPE, None)  # override takes the priority
        if type == ComputeType.VIRTUALMACHINE:
            from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import VirtualMachineCompute

            return VirtualMachineCompute._load_from_dict(data, context, **kwargs)
        loaded_data = load_from_dict(ComputeSchema, data, context, **kwargs)
        return Compute(**loaded_data)
