# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from marshmallow import fields, post_load, ValidationError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import ComponentJobConstants

module_logger = logging.getLogger(__name__)


class PipelineJobValueInputSchema(metaclass=PatchedSchemaMeta):
    value = UnionField([fields.Str(), fields.Bool(), fields.Int(), fields.Float()])

    @post_load
    def make(self, data, **kwargs):
        return data["value"]


class OutputBindingStr(fields.Field):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def _serialize(self, value, attr, obj, **kwargs):
        if isinstance(value, str) and value.startswith(ComponentJobConstants.OUTPUT_PREFIX):
            return value
        else:
            raise ValidationError(f"Invalid output binding string '{value}' passed")

    def _deserialize(self, value, attr, data, **kwargs):
        if isinstance(value, str) and value.startswith(ComponentJobConstants.OUTPUT_PREFIX):
            return value
        else:
            raise ValidationError(f"Invalid output binding string '{value}' passed")
