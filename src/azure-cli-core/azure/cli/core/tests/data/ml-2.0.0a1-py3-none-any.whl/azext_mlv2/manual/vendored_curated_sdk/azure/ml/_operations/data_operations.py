# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Dict, Iterable, List

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import _get_latest
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import is_ARM_id_for_resource, get_datastore_arm_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import _check_and_upload_path
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import API_VERSION_2021_03_01_PREVIEW
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Data
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts.constants import ASSET_PATH_ERROR, CHANGED_ASSET_PATH_MSG

module_logger = logging.getLogger(__name__)


class DataOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: AzureMachineLearningWorkspaces,
        datastore_operations: DatastoreOperations,
        **kwargs: Dict,
    ):

        super(DataOperations, self).__init__(workspace_scope)
        self._operation = service_client.data_versions
        self._container_operation = service_client.data_containers
        self._datastore_operation = datastore_operations
        self._init_kwargs = kwargs

    def list(self, name: str = None) -> Iterable[Data]:
        """List the data assets of the workspace.

        :param name: Name of a specific data asset, optional.
        :type name: Optional[str]
        :return: A list of Data asset objects.
        :rtype: Iterable[Data]
        """
        if name:
            return map(
                lambda data_version_resource: Data._from_rest_object(data_version_resource),
                self._operation.list(
                    name=name,
                    workspace_name=self._workspace_name,
                    skip_token=None,
                    **self._scope_kwargs,
                ),
            )
        else:
            return map(
                lambda data_container_resource: Data._from_container_rest_object(data_container_resource),
                self._container_operation.list(
                    workspace_name=self._workspace_name,
                    skip_token=None,
                    **self._scope_kwargs,
                ),
            )

    def get(self, name: str, version: int = None) -> Data:
        """Get the specified data asset.

        :param name: Name of data asset.
        :type name: str
        :param version: Version of data asset. Default is the most recently created version.
        :type version: int
        :return: Data asset object.
        """
        if version:
            data_version_resource = self._operation.get(
                name,
                str(version),
                self._subscription_id,
                self._resource_group_name,
                self._workspace_name,
                API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
        else:
            data_version_resource = _get_latest(
                asset_name=name,
                version_operation=self._operation,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
            )

        return Data._from_rest_object(data_version_resource)

    def create_or_update(self, data: Data) -> Data:
        """Returns created or updated data asset.

        If not already in storage, asset will be uploaded to datastore name specified in data.datastore or the workspace's default datastore.

        :param data: Data asset object.
        :type data: Data
        :return: Data asset object.
        """
        name = data.name
        version = data.version

        data = _check_and_upload_path(asset=data, asset_operations=self)
        # Resolve datastore ARM ID in case a remote path is passed in
        if not is_ARM_id_for_resource(data.datastore):
            data._datastore = get_datastore_arm_id(data.datastore, self._workspace_scope)
        data_version_resource = data._to_rest_object()
        try:
            result = self._operation.create_or_update(
                name=name,
                version=str(version),
                workspace_name=self._workspace_name,
                body=data_version_resource,
                **self._scope_kwargs,
            )
        except Exception as e:
            # service side raises an exception if we attempt to update an existing asset's asset path
            if str(e) == ASSET_PATH_ERROR:
                raise Exception(CHANGED_ASSET_PATH_MSG)
            else:
                raise e

        return Data._from_rest_object(result)

    def delete(self, name: str, version: int) -> None:
        """Delete data asset.

        :param name: Name of data asset.
        :type name: str
        :param version: Version of data asset.
        :type version: int
        :return: None
        """
        if version:
            return self._operation.delete(
                name,
                str(version),
                self._subscription_id,
                self._resource_group_name,
                self._workspace_name,
                API_VERSION_2021_03_01_PREVIEW,
                **self._init_kwargs,
            )
        else:
            raise Exception("Deletion on the whole lineage is not supported yet.")
