# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Optional, Union

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    DataBindingMode,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType
from marshmallow import post_load

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.asset import AnonymousAssetSchema, AssetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmVersionedStr, UnionField

module_logger = logging.getLogger(__name__)


class InputOutputEntry:
    def __init__(self, *, mode: Optional[str] = DataBindingMode.MOUNT, data: Union[str, "Data"] = None):
        self.data = data
        self.mode = mode.capitalize() if mode else None


class InputEntrySchema(metaclass=PatchedSchemaMeta):
    mode = StringTransformedEnum(allowed_values=[DataBindingMode.MOUNT, DataBindingMode.DOWNLOAD], required=False)
    data = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.DATA),
            NestedField(AnonymousAssetSchema),
        ]
    )

    @post_load
    def make(self, data, **kwargs):
        return InputOutputEntry(**data)


class OutputEntrySchema(metaclass=PatchedSchemaMeta):
    mode = StringTransformedEnum(allowed_values=[DataBindingMode.MOUNT, DataBindingMode.UPLOAD], required=False)
    data = NestedField(AssetSchema)

    @post_load
    def make(self, data, **kwargs):
        return InputOutputEntry(**data)
