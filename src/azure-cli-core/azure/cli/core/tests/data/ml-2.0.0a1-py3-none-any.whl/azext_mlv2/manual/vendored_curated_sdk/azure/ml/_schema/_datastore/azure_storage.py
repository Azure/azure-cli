# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Any, Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    ContentsType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from marshmallow import fields, post_load

from .credentials import AccountKeySchema, CertificateSchema, SasTokenSchema, ServicePrincipalSchema


class AzureStorageSchema(PathAwareSchema):
    name = fields.Str()
    account_name = fields.Str(required=True)
    credential = UnionField(
        [
            NestedField(AccountKeySchema),
            NestedField(SasTokenSchema),
            NestedField(ServicePrincipalSchema),
            NestedField(CertificateSchema),
        ],
        required=True,
    )
    endpoint = fields.Str()
    protocol = fields.Str()
    description = fields.Str()
    tags = fields.Dict(keys=fields.Str(), values=fields.Str())


class AzureFileSchema(AzureStorageSchema):
    storage_type = StringTransformedEnum(
        allowed_values=ContentsType.AZURE_FILE, casing_transform=camel_to_snake, data_key="type", required=True
    )
    file_share_name = fields.Str(required=True)

    @post_load
    def make(self, data: Dict[str, Any], **kwargs) -> "AzureFileDatastore":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import AzureFileDatastore

        data.pop("storage_type", None)
        return AzureFileDatastore(**data)


class AzureBlobSchema(AzureStorageSchema):
    storage_type = StringTransformedEnum(
        allowed_values=ContentsType.AZURE_BLOB, casing_transform=camel_to_snake, data_key="type", required=True
    )
    container_name = fields.Str(required=True)

    @post_load
    def make(self, data: Dict[str, Any], **kwargs) -> "AzureBlobDatastore":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import AzureBlobDatastore

        data.pop("storage_type", None)
        return AzureBlobDatastore(**data)


class AzureDataLakeGen2Schema(AzureStorageSchema):
    storage_type = StringTransformedEnum(
        allowed_values=ContentsType.AZURE_DATA_LAKE_GEN2,
        casing_transform=camel_to_snake,
        data_key="type",
        required=True,
    )
    container_name = fields.Str(required=True)

    @post_load
    def make(self, data: Dict[str, Any], **kwargs) -> "AzureDataLakeGen2Datastore":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import AzureDataLakeGen2Datastore

        data.pop("storage_type", None)
        return AzureDataLakeGen2Datastore(**data)
