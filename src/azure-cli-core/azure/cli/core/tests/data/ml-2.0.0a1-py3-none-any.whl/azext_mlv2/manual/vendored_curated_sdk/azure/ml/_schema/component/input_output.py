# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import fields, validate

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, UnionField


class InputPortSchema(metaclass=PatchedSchemaMeta):
    input_type = fields.Str(validate=validate.OneOf(["generic"]))
    data_type = fields.Str(validate=validate.OneOf(["path", "null"]), default="null", data_key="type")
    description = fields.Str()
    optional = fields.Bool()
    default = fields.Str()


class OutputPortSchema(metaclass=PatchedSchemaMeta):
    input_type = fields.Str(validate=validate.OneOf(["generic"]))
    data_type = fields.Str(validate=validate.OneOf(["path", "null"]), default="null", data_key="type")
    description = fields.Str()


class ParameterSchema(metaclass=PatchedSchemaMeta):
    data_type = fields.Str(
        validate=validate.OneOf(["number", "integer", "boolean", "string", "object", "null"]),
        default="null",
        data_key="type",
    )
    optional = fields.Bool()
    default = UnionField([fields.Str(), fields.Number(), fields.Bool()])
    description = fields.Str()
    max = UnionField([fields.Str(), fields.Number()])
    min = UnionField([fields.Str(), fields.Number()])
    enum = fields.List(fields.Str())
