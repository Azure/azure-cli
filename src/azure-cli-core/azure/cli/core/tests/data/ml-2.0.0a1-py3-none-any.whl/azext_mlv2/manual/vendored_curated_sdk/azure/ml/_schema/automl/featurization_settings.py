# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields as flds, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, NestedField, StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.job.automl.featurization import (
    FeaturizationSettings,
    FeaturizationConfig,
    TransformerParameters,
    ImputerSettings,
    HashOneHotEncoderSettings,
)


class CustomFeaturizationSchema(metaclass=PatchedSchemaMeta):
    fields = flds.List(flds.Str())


class ImputerSchema(CustomFeaturizationSchema):
    strategy = flds.Str()
    fill_value = flds.Float()

    @post_load
    def make(self, data, **kwargs):
        return ImputerSettings(**data)


class OneHotEncoderSchema(CustomFeaturizationSchema):
    number_of_bits = flds.Int()

    @post_load
    def make(self, data, **kwargs):
        return HashOneHotEncoderSettings(**data)


class TransfomerParamsSchema(metaclass=PatchedSchemaMeta):
    imputer = flds.List(NestedField(ImputerSchema()))
    hash_one_hot_encoder = flds.List(NestedField(OneHotEncoderSchema()))
    tfidf = flds.Dict()

    @post_load
    def make(self, data, **kwargs):
        return TransformerParameters(**data)


class FeaturizationConfigSchema(metaclass=PatchedSchemaMeta):
    blocked_transformers = flds.List(flds.Str())
    column_purposes = flds.Dict()
    transformer_params = NestedField(TransfomerParamsSchema())

    @post_load
    def make(self, data, **kwargs):
        return FeaturizationConfig(**data)


class FeaturizationSettingsSchema(metaclass=PatchedSchemaMeta):
    featurization_config = UnionField(
        [
            StringTransformedEnum(allowed_values=[AutoMLConstants.AUTO, AutoMLConstants.OFF]),
            NestedField(FeaturizationConfigSchema()),
        ]
    )
    enable_dnn_featurization = flds.Bool()

    @post_load
    def make(self, data, **kwargs):
        return FeaturizationSettings(**data)
