# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_max_results_params


def load_data_params(self):
    with self.argument_context("ml data list") as c:
        add_common_params(c)
        c.argument(
            "name",
            options_list=["--name", "-n"],
            type=str,
            help="Name of the data asset. If provided, all the data versions under this name will be returned.",
        )
        add_max_results_params(c)

    with self.argument_context("ml data show") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the data asset.")
        c.argument(
            "version",
            options_list=["--version", "-v"],
            help="Version of the data asset. If omitted, the latest version is shown.",
        )

    with self.argument_context("ml data create") as c:
        add_common_params(c)
        add_override_param(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the data asset.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the data asset.")
        c.argument("description", options_list=["--description", "-d"], help="Description of the data asset.")
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML data specification.",
        )

    with self.argument_context("ml data update") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the data asset.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the data asset.")

    with self.argument_context("ml data delete") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the data asset.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the data asset.")
