# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_batch_endpoint_help():
    helps[
        "ml batch-endpoint"
    ] = """
        type: group
        short-summary: Manage Azure ML batch endpoints.
        long-summary: >
          Azure ML endpoints provide a simple interface for creating and managing model deployments.
          Each endpoint can have one or more deployments. Batch endpoints are used for offline batch scoring.
    """
    helps[
        "ml batch-endpoint create"
    ] = """
        type: command
        short-summary: Create an endpoint.
        long-summary: >
          To create an endpoint, provide a YAML file with a batch endpoint
          configuration. If the endpoint already exists, it will be over-written with the new settings.
        examples:
        - name: Create an endpoint from a YAML specification file
          text: az ml batch-endpoint create --file endpoint.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Create an endpoint with name
          text: az ml batch-endpoint create --name endpointname --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-endpoint delete"
    ] = """
        type: command
        short-summary: Delete an endpoint.
        examples:
        - name: Delete an batch endpoint, including all its deployments
          text: az ml batch-endpoint delete --name my-batch-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-endpoint invoke"
    ] = """
        type: command
        short-summary: Invoke an endpoint
        long-summary: >
          You can start batch inference run by invoking the endpoint with some data. For batch
          endpoints, invocation will trigger an asynchronous batch scoring job.
        examples:
        - name: Invoke a batch endpoint with input data from a registered Azure ML data asset (and override default deployment setting for mini_batch_size)
          text: az ml batch-endpoint invoke --name my-batch-endpoint  --input-data azureml:my-dataset:1 --mini-batch-size 64 --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke a batch endpoint with input data from a storage URL
          text: az ml batch-endpoint invoke --name my-batch-endpoint  --input-path folder:https://pipelinedata.blob.core.windows.net/sampledata/mnist --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke a batch endpoint with input data from local files
          text: az ml batch-endpoint invoke --name my-batch-endpoint  --input-local-path ./mnist --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke a batch endpoint with a local directory as the input and output path and overwrite some batch deployment settings during endpoint invoke
          text: az ml batch-endpoint invoke --name my-batch-endpoint  --input-local-path ./mnist --instance-count 2 --mini-batch-size 5 --output-path folder:azureml://datastores/workspaceblobstore/paths/tests/output --resource-group my-resource-group --workspace-name my-workspace

    """
    helps[
        "ml batch-endpoint list"
    ] = """
        type: command
        short-summary: List endpoints in a workspace.
        examples:
        - name: List all the batch endpoints in a workspace
          text: az ml batch-endpoint list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the batch endpoints in a workspace
          text: az ml batch-endpoint list  --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the batch endpoints in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml batch-endpoint list --query \"[].{Name:name}\"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """

    helps[
        "ml batch-endpoint show"
    ] = """
        type: command
        short-summary: Show details for an endpoint.
        examples:
        - name: Show the details for a batch endpoint
          text: az ml batch-endpoint show --name my-batch-endpoint  --resource-group my-resource-group --workspace-name my-workspace
        - name: Show the provisioning state of an endpoint using --query argument to execute a JMESPath query on the results of commands.
          text: az ml batch-endpoint show -n my-endpoint --query "{Name:name,State:provisioning_state}"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-endpoint update"
    ] = """
        type: command
        short-summary: Update an endpoint.
        long-summary: >
          The 'description', 'tags', and 'defaults' properties of an endpoint can be updated.
          In addition, new deployments can be added to an endpoint, and existing deployments
          can be updated.
        examples:
        - name: Update an endpoint from a YAML specification file
          text: az ml batch-endpoint update --name my-batch-endpoint --file updated_endpoint.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Add a new deployment to an existing endpoint
          text: az ml batch-endpoint update --name my-batch-endpoint  --set defaults.deployment_name=depname  --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-endpoint list-jobs"
    ] = """
        type: command
        short-summary: List the batch scoring jobs for a batch endpoint.
        examples:
        - name: List all the batch scoring jobs for an endpoint
          text: az ml batch-endpoint list-jobs --name my-batch-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
