# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import time
import os
from pathlib import Path
from typing import Union, Dict
from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import (
    BATCH_ENDPOINT_TYPE,
    DeploymentType,
    EndpointYamlFields,
    ONLINE_ENDPOINT_TYPE,
    EndpointGetLogsFields,
    EndpointKeyType,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import (
    Endpoint,
    BatchEndpoint,
    ManagedOnlineEndpoint,
    K8sOnlineEndpoint,
    Deployment,
    K8sOnlineDeployment,
    ManagedOnlineDeployment,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets import Data
from .print_error import print_error_and_exit
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import get_datastore_arm_id, remove_aml_prefix
from .utils import _is_debug_set


def ml_endpoint_show(cmd, resource_group_name, workspace_name, name, type=ONLINE_ENDPOINT_TYPE, local=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        endpoint = ml_client.endpoints.get(type=type, name=name, local=local)
        return endpoint.dump()
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    name=None,
    type=None,
    local=False,
    no_wait=False,
    params_override=[],
    **kwargs
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        if name:
            # MFE is case-insensitive for Name. So convert the name into lower case here.
            params_override.append({"name": name.lower()})
        if type:
            params_override.append({"type": type})
        endpoint = Endpoint.load(path=file, params_override=params_override)
        endpoint = ml_client.endpoints.create(endpoint, local=local, no_wait=no_wait)
        if endpoint:
            return endpoint.dump()
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_create_load(cmd, resource_group_name, workspace_name, file, name=None, type=None, no_wait=False):
    try:
        return load_yaml(file)
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    deployment=None,
    type=ONLINE_ENDPOINT_TYPE,
    local=False,
    no_wait=False,
):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        return ml_client.endpoints.delete(type=type, name=name, deployment=deployment, local=local, no_wait=no_wait)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_get_deployment_logs(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    deployment,
    lines=EndpointGetLogsFields.LINES,
    type=ONLINE_ENDPOINT_TYPE,
    local=False,
    container=None,
):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        logs = ml_client.endpoints.get_deployment_logs(
            type=type,
            endpoint_name=name,
            deployment_name=deployment,
            lines=lines,
            local=local,
            container_type=container,
        )
        print(logs.replace("\\n", "\n"))
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_get_credentials(cmd, resource_group_name, workspace_name, name, type=ONLINE_ENDPOINT_TYPE):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        return ml_client.endpoints.list_keys(type=type, name=name)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_list(cmd, resource_group_name, workspace_name, type=ONLINE_ENDPOINT_TYPE, local=False):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        return ml_client.endpoints.list(type=type, local=local)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_update(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=None,
    deployment=None,
    traffic=None,
    instance_count=None,
    file=None,
    deployment_file=None,
    local=False,
    no_wait=False,
    **kwargs
) -> None:
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        # MFE is case-insensitive for Name. So convert the name into lower case here.
        if name:
            name = name.lower()
        deployment_name = deployment.lower() if deployment else None
        endpoint_dict = kwargs["parameters"]
        if instance_count and not deployment_name:
            raise Exception("Deployment name must be specified when updating instance_count")
        elif instance_count and deployment_name:
            deployments = endpoint_dict[EndpointYamlFields.DEPLOYMENTS]
            for d in deployments:
                # We already make sure all the names are converted into lower case. So we can compare directly here.
                if d[EndpointYamlFields.NAME].lower() == deployment_name:
                    d[EndpointYamlFields.SCALE_SETTINGS][EndpointYamlFields.INSTANCE_COUNT] = instance_count
        if traffic:
            if isinstance(traffic, str):
                endpoint_dict[EndpointYamlFields.TRAFFIC_NAME] = _transform_traffic_name_from_str_to_dict(traffic)
            elif isinstance(traffic, dict[str, str]):
                endpoint_dict[EndpointYamlFields.TRAFFIC_NAME] = traffic

        params_override = []
        if name:
            params_override.append({"name": name})
        if type:
            params_override.append({"type": type})
        endpoint = Endpoint._load(
            endpoint_dict,
            yaml_path=_get_yaml_path(file=file, deployment_file=deployment_file),
            params_override=params_override,
        )

        return ml_client.endpoints.update(
            endpoint=endpoint,
            deployment=None,
            local=local,
            no_wait=no_wait,
        )
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_update_load(
    cmd,
    resource_group_name,
    workspace_name,
    file=None,
    deployment_file=None,
    name=None,
    deployment=None,
    type=None,
    local=False,
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        if file:
            cfg = load_yaml(file)
            name = name or cfg.get("name", None)
            type = type or cfg.get("type", None)

        if not name:
            raise Exception("A name must be passed through the CLI or be present in your yaml file")
        name = name.lower()
        deployment_name = deployment.lower() if deployment else None
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        if type:
            old_endpoint = ml_client.endpoints.get(type=type, name=name, local=local)
        else:
            old_endpoint = ml_client.endpoints.get(name=name, local=local)

        new_endpoint = None
        new_deployments = []
        if file:
            params_override = []
            if name:
                params_override.append({"name": name})
            if type:
                params_override.append({"type": type})
            new_endpoint = Endpoint.load(path=file, params_override=params_override)
            new_deployments = [d.name for d in new_endpoint.deployments]
            # for deployments not in the new_endpoint, we need to remove them.
            deployments_to_delete = []
            for deployment_item in old_endpoint.deployments:
                if deployment_item.name not in new_deployments:
                    deployments_to_delete.append(deployment_item)
            for item in deployments_to_delete:
                old_endpoint.deployments.remove(item)

        old_endpoint._merge_with(new_endpoint)
        if deployment_file:
            _merge_deployment_and_endpoint(
                endpoint=old_endpoint,
                deployment_file=deployment_file,
                deployment_name=deployment_name,
            )

        if old_endpoint:
            return old_endpoint.dump()
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_invoke(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    request_file=None,
    input_data=None,
    input_local_path=None,
    input_path=None,
    input_datastore=None,
    output_path=None,
    output_datastore=None,
    deployment=None,
    mini_batch_size=None,
    instance_count=None,
    type=ONLINE_ENDPOINT_TYPE,
    local=False,
    params_override=[],
) -> str:
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        input_data_asset = None
        if type == BATCH_ENDPOINT_TYPE:
            input_data = remove_aml_prefix(input_data)
            input_datastore = remove_aml_prefix(input_datastore)

            data_name = "{}_input_data_{}".format(name, round(time.time()))
            input_data_asset = input_data or Data(
                name=data_name,
                version=1,
                datastore=input_datastore,
                path=input_path,
                local_path=input_local_path,
            )

            if mini_batch_size:
                params_override.append({EndpointYamlFields.MINI_BATCH_SIZE: mini_batch_size})
            if instance_count:
                params_override.append({EndpointYamlFields.BATCH_JOB_INSTANCE_COUNT: instance_count})
            if output_path:
                params_override.append({EndpointYamlFields.BATCH_JOB_OUTPUT_PATH: output_path})
            if output_datastore:
                params_override.append({EndpointYamlFields.BATCH_JOB_OUTPUT_DATSTORE: output_datastore})

        return ml_client.endpoints.invoke(
            endpoint_name=name,
            type=type,
            request_file=request_file,
            input_data=input_data_asset,
            deployment_name=deployment,
            local=local,
            params_override=params_override,
        )
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_list_jobs(cmd, resource_group_name, workspace_name, name, deployment=None, type=BATCH_ENDPOINT_TYPE):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )

        return ml_client.endpoints.list_jobs(endpoint_name=name, type=type, deployment_name=deployment)
    except Exception as err:
        print_error_and_exit(err, debug)


def ml_endpoint_regenerate_keys(
    cmd, resource_group_name, workspace_name, name, type=ONLINE_ENDPOINT_TYPE, key_type=EndpointKeyType.PRIMARY_KEY_TYPE
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)

    try:
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
            debug=debug,
        )
        return ml_client.endpoints.regenerate_keys(type=type, name=name, key_type=key_type)
    except Exception as err:
        print_error_and_exit(err, debug)


def _merge_deployment_and_endpoint(
    endpoint: Endpoint,
    deployment_name: str = None,
    deployment_file: Union[str, os.PathLike] = None,
):
    if deployment_file:
        params_override = []
        if isinstance(endpoint, BatchEndpoint):
            params_override.append({"type": BATCH_ENDPOINT_TYPE})
        elif isinstance(endpoint, K8sOnlineEndpoint):
            params_override.append({"type": DeploymentType.K8S})
        elif isinstance(endpoint, ManagedOnlineEndpoint):
            params_override.append({"type": DeploymentType.MANAGED})

        new_deployment = Deployment.load(path=deployment_file, params_override=params_override)
        if deployment_name:
            new_deployment.name = deployment_name
        old_deployment = next((d for d in endpoint.deployments if d.name == new_deployment.name), None)
        if not old_deployment:
            endpoint.deployments.append(new_deployment)
        else:
            old_deployment._merge_with(new_deployment)


def _transform_traffic_name_from_str_to_dict(traffic_name: str) -> Dict[str, str]:
    return dict((x.strip(), y.strip()) for x, y in (ele.split(":") for ele in traffic_name.split(",")))


def _get_yaml_path(file: Union[str, os.PathLike] = None, deployment_file: Union[str, os.PathLike] = None) -> Dict:
    base_path = None
    if file:  # TODO: since we can only choose one file, there is no need to pass two parameters here
        base_path = Path(file)
    elif deployment_file:
        base_path = Path(deployment_file)
    else:
        base_path = Path.cwd()

    return base_path
