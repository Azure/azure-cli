# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Optional
from .raise_error import log_and_raise_error
from .utils import get_ml_client, _dump_entity_with_warnings
from itertools import islice

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Data


def ml_data_list(cmd, resource_group_name, workspace_name, name=None, max_results=None, include_archived=False):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        if max_results:
            results = islice(ml_client.data.list(name=name, include_archived=include_archived), int(max_results))
        else:
            results = ml_client.data.list(name=name, include_archived=include_archived)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_data_show(cmd, resource_group_name, workspace_name, name, version):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    try:
        data = ml_client.data.get(name=name, version=version)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_data_create(
    cmd,
    resource_group_name: str,
    workspace_name: str,
    file: Optional[str] = None,
    name: Optional[str] = None,
    description: Optional[str] = None,
    version: Optional[str] = None,
    params_override=[],
    type: Optional[str] = None,
    path: Optional[str] = None,
):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )

    if name:
        params_override.append({"name": name})
    if description:
        params_override.append({"description": description})
    if version:
        params_override.append({"version": version})
    if type:
        params_override.append({"type": type})
    if path:
        params_override.append({"path": path})

    try:
        data = Data.load(path=file, params_override=params_override)
        data = ml_client.data.create_or_update(data)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        log_and_raise_error(err, debug)


# This will only be used for generic update
def _ml_data_update(cmd, resource_group_name, workspace_name, name, version, **kwargs):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    data_params = kwargs["parameters"]
    data_params["name"] = name
    data_params["version"] = version

    try:
        data_obj = Data._load(yaml_data=data_params)
        data = ml_client.data.create_or_update(data_obj)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_data_archive(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        return ml_client.data.archive(name=name, version=version, label=label)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_data_restore(cmd, resource_group_name, workspace_name, name, version=None, label=None):
    ml_client, debug = get_ml_client(
        cli_ctx=cmd.cli_ctx, resource_group_name=resource_group_name, workspace_name=workspace_name
    )
    try:
        return ml_client.data.restore(name=name, version=version, label=label)
    except Exception as err:
        log_and_raise_error(err, debug)
