# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands.parameters import get_three_state_flag
from ._common_params import add_common_params, add_override_param, add_lro_param


def add_online_endpoint_common_param(
    c,
    name_help_message="Name of the online endpoint.",
    local_help_message=None,
):
    c.argument("name", options_list=["--name", "-n"], type=str, help=name_help_message)
    if local_help_message is not None:
        c.argument(
            "local",
            arg_type=get_three_state_flag(),
            options_list=["--local"],
            help=local_help_message,
            default=False,
        )


def load_online_endpoint_params(self):
    with self.argument_context("ml online-endpoint create") as c:
        add_common_params(c)
        add_online_endpoint_common_param(
            c,
            local_help_message="Create endpoint locally."
            " Note: traffic and auth is not supported locally."
            " You can use 'az ml online-deployment create --local' directly."
            " It will create an endpoint if one doesn't exist.",
        )
        add_lro_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ml online-endpoint specification.",
        )
        c.argument(
            "auth_mode",
            help="Authentication method for the endpoint. Allowed values: key, aml_token. Default: key.",
        )
        add_override_param(c)

    with self.argument_context("ml online-endpoint show") as c:
        add_common_params(c)
        add_online_endpoint_common_param(
            c,
            local_help_message="Show local endpoint.",
        )

    with self.argument_context("ml online-endpoint delete") as c:
        add_common_params(c)
        add_online_endpoint_common_param(c, local_help_message="Delete local endpoint.")
        add_lro_param(c)

    with self.argument_context("ml online-endpoint get-credentials") as c:
        add_common_params(c)
        add_online_endpoint_common_param(c)

    with self.argument_context("ml online-endpoint list") as c:
        add_common_params(c)
        c.argument(
            "local",
            arg_type=get_three_state_flag(),
            options_list=["--local"],
            help="List all local endpoints.",
            default=False,
        )

    with self.argument_context("ml online-endpoint update") as c:
        add_common_params(c)
        add_lro_param(c)
        add_online_endpoint_common_param(c, local_help_message="Update local endpoint.")
        c.argument(
            "traffic",
            options_list=["--traffic", "-r"],
            help="Space-separated key-value pairs, in quotes, for the traffic settings for the endpoint.",
        )
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ml online-endpoint specification.",
        )

    with self.argument_context("ml online-endpoint invoke") as c:
        add_common_params(c)
        add_online_endpoint_common_param(
            c,
            local_help_message="Invoke local endpoint. This will only work if a local deployment has been created for this endpoint.",
        )
        add_override_param(c)
        c.argument(
            "online_deployment_name",
            options_list=["--deployment-name", "-d"],
            help="Name of the deployment to target.",
        )
        c.argument(
            "request_file",
            options_list=["--request-file", "-r"],
            help="Local path to the JSON file containing the request data.",
        )

    with self.argument_context("ml online-endpoint regenerate-keys") as c:
        add_common_params(c)
        add_lro_param(c)
        add_online_endpoint_common_param(c)
        c.argument("key_type", type=str, help="The type of key to regenerate. Allowed values: primary, secondary.")
