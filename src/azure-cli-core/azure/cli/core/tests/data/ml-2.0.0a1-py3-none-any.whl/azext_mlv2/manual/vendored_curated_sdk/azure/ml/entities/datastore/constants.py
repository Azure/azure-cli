# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# Miscellaneous
DEFAULT_ENDPOINT = "core.windows.net"
HTTPS = "https"
