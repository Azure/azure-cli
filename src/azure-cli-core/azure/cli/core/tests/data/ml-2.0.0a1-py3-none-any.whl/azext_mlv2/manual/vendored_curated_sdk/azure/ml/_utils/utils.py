# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import isodate
import json
import logging
import os
import re
import requests
import sys
import yaml

from contextlib import contextmanager
from datetime import timedelta
from requests.adapters import HTTPAdapter
from typing import Dict, Union, Any, Optional, Tuple
from urllib.parse import urlparse
from urllib3 import Retry
from uuid import UUID


module_logger = logging.getLogger(__name__)

DEVELOPER_URL_MFE_ENV_VAR = "AZUREML_DEV_URL_MFE"

# Prefix used when hitting MFE skipping ARM
MFE_PATH_PREFIX = "/mferp/managementfrontend"
MFE_KEY_IN_WORKSPACE_DISCOVER_URL = "api"
RH_KEY_IN_WORKSPACE_DISCOVER_URL = "history"


def _get_mfe_url_override() -> Optional[str]:
    return os.getenv(DEVELOPER_URL_MFE_ENV_VAR)


def _is_https_url(url: str) -> bool:
    return url.lower().startswith("https")


# https://stackoverflow.com/questions/19053707
def snake_to_camel(text) -> Optional[str]:
    if text:
        """convert snake name to camel"""
        return re.sub("_([a-zA-Z0-9])", lambda m: m.group(1).upper(), text)


# https://stackoverflow.com/questions/1175208
def camel_to_snake(text: str) -> Optional[str]:
    def _convert(text):
        """convert camel case to Snake"""
        text = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", text)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", text).lower()

    # Below is the fix for comma separated strings like "system_assigned, user_assigned"
    if text:
        if "," in text:
            txts = []
            for text in text.split(","):
                text = _convert(text.strip())
                txts.append(text)
            return ",".join(txts)
        else:
            return _convert(text)


def camel_case_transformer(key, attr_desc, value):
    """transfer string to camel case"""
    return (snake_to_camel(key), value)


def create_session_with_retry(retry=3):
    """
    Create requests.session with retry

    :type retry: int
    rtype: Response
    """
    retry_policy = get_retry_policy(num_retry=retry)

    session = requests.Session()
    session.mount("https://", HTTPAdapter(max_retries=retry_policy))
    session.mount("http://", HTTPAdapter(max_retries=retry_policy))
    return session


def get_retry_policy(num_retry=3):
    """
    :return: Returns the msrest or requests REST client retry policy.
    :rtype: urllib3.Retry
    """
    status_forcelist = [413, 429, 500, 502, 503, 504]
    backoff_factor = 0.4
    retry_policy = Retry(
        total=num_retry,
        read=num_retry,
        connect=num_retry,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        # By default this is True. We set it to false to get the full error trace, including url and
        # status code of the last retry. Otherwise, the error message is 'too many 500 error responses',
        # which is not useful.
        raise_on_status=False,
    )
    return retry_policy


def download_text_from_url(source_uri: str, session: requests.Session, timeout: tuple = None):
    """
    Downloads the content from an URL
    Returns the Response text
    :return:
    :rtype: str
    """

    if session is None:
        session = create_session_with_retry()
    response = session.get(source_uri, timeout=timeout)

    # Match old behavior from execution service's status API.
    if response.status_code == 404:
        return ""

    # _raise_request_error(response, "Retrieving content from " + uri)
    return response.text


def load_file(file_path: str):
    try:
        with open(file_path, "r") as f:
            cfg = f.read()
    except OSError:  # FileNotFoundError introduced in Python 3
        raise Exception(f"No such file or directory: {file_path}")
    return cfg


def load_json(file_path: Union[str, os.PathLike, None]) -> Dict:
    try:
        with open(file_path, "r") as f:
            cfg = json.load(f)
    except OSError:  # FileNotFoundError introduced in Python 3
        raise Exception(f"No such file or directory: {file_path}")
    return cfg


def load_yaml(file_path: Union[str, os.PathLike, None]) -> Dict:
    try:
        cfg = {}
        if file_path is not None:
            with open(file_path, "r") as f:
                cfg = yaml.safe_load(f)
        return cfg
    except OSError:  # FileNotFoundError introduced in Python 3
        raise Exception(f"No such file or directory: {file_path}")
    except yaml.YAMLError as e:
        raise Exception(f"Error while parsing yaml file: {file_path} \n\n {str(e)}")


def dump_yaml_to_file(
    file_path: Union[str, os.PathLike, None],
    data_dict: Dict,
    default_flow_style=None,
) -> None:
    try:
        if file_path is not None:
            with open(file_path, "w") as f:
                yaml.dump(data_dict, f, default_flow_style=default_flow_style)
    except OSError:  # FileNotFoundError introduced in Python 3
        raise Exception(f"No such file or directory: {file_path}")
    except yaml.YAMLError as e:
        raise Exception(f"Error while parsing yaml file: {file_path} \n\n {str(e)}")


def dict_eq(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> bool:
    if not dict1 and not dict2:
        return True
    return dict1 == dict2


def get_http_response_and_deserialized_from_pipeline_response(
    pipeline_response: Any, deserialized: Any, *args
) -> Tuple[Any, Any]:
    return pipeline_response.http_response, deserialized


def initialize_logger_info(module_logger: logging.Logger, terminator="\n") -> None:
    module_logger.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(logging.INFO)
    handler.terminator = terminator
    handler.flush = sys.stderr.flush
    module_logger.addHandler(handler)


def xor(a: Any, b: Any) -> bool:
    return bool(a) != bool(b)


def is_url(value: Union[str, os.PathLike]) -> bool:
    try:
        result = urlparse(value)
        return all([result.scheme, result.netloc])
    except ValueError:
        return False


# modified from: https://stackoverflow.com/a/33245493/8093897
def is_valid_uuid(test_uuid: str) -> bool:
    try:
        uuid_obj = UUID(test_uuid, version=4)
    except ValueError:
        return False
    return str(uuid_obj) == test_uuid


def to_iso_duration_format_mins(time_in_mins: Optional[Union[int, float]]) -> str:
    return isodate.duration_isoformat(timedelta(minutes=time_in_mins)) if time_in_mins else None


def from_iso_duration_format_mins(duration: Optional[str]) -> int:
    return int(from_iso_duration_format(duration) / 60) if duration else None


def to_iso_duration_format(time_in_seconds: Optional[Union[int, float]]) -> str:
    return isodate.duration_isoformat(timedelta(seconds=time_in_seconds)) if time_in_seconds else None


def from_iso_duration_format(duration: Optional[str]) -> int:
    return int(isodate.parse_duration(duration).total_seconds()) if duration else None


def to_iso_duration_format_ms(time_in_ms: Optional[Union[int, float]]) -> str:
    return isodate.duration_isoformat(timedelta(milliseconds=time_in_ms)) if time_in_ms else None


def from_iso_duration_format_ms(duration: Optional[str]) -> int:
    return from_iso_duration_format(duration) * 1000 if duration else None


def _get_mfe_base_url_from_discovery_service(workspace_operations: Any, workspace_name: str) -> str:
    discovery_url = workspace_operations.get(workspace_name).discovery_url

    all_urls = json.loads(download_text_from_url(discovery_url, create_session_with_retry()))
    return f"{all_urls[MFE_KEY_IN_WORKSPACE_DISCOVER_URL]}{MFE_PATH_PREFIX}"


def _get_mfe_base_url_from_batch_endpoint(endpoint: "BatchEndpoint") -> str:
    return endpoint.scoring_uri.split("/subscriptions/")[0]


# Allows to use a modified client with a provided url
@contextmanager
def modified_operation_client(operation_to_modify, url_to_use):

    original_api_base_url = None
    try:
        # Modify the operation
        if url_to_use:
            original_api_base_url = operation_to_modify._client._base_url
            operation_to_modify._client._base_url = url_to_use
        yield
    finally:
        # Undo the modification
        if original_api_base_url:
            operation_to_modify._client._base_url = original_api_base_url


def from_iso_duration_format_min_sec(duration: Optional[str]) -> str:
    return duration.split(".")[0].replace("PT", "").replace("M", "m ") + "s"
