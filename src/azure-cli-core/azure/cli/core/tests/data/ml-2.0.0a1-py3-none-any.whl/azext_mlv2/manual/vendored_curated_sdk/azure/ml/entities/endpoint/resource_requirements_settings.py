# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import ContainerResourceRequirements
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.mixins import RestTranslatableMixin

module_logger = logging.getLogger(__name__)


class ResourceRequirementsSettings(RestTranslatableMixin):
    def __init__(
        self,
        cpu: float = None,
        memory_in_gb: float = None,
        gpu: int = None,
        cpu_limit: float = None,
        memory_in_gb_limit: float = None,
    ):
        self.cpu = cpu
        self.memory_in_gb = memory_in_gb
        self.gpu = gpu
        self.cpu_limit = cpu_limit
        self.memory_in_gb_limit = memory_in_gb_limit

    def _to_rest_object(self) -> ContainerResourceRequirements:
        return ContainerResourceRequirements(
            cpu=self.cpu,
            memory_in_gb=self.memory_in_gb,
            gpu=self.gpu,
            cpu_limit=self.cpu_limit,
            memory_in_gb_limit=self.memory_in_gb_limit,
        )

    def _merge_with(self, other: "ResourceRequirementsSettings") -> None:
        if other:
            self.cpu = other.cpu or self.cpu
            self.memory_in_gb = other.memory_in_gb or self.memory_in_gb
            self.gpu = other.gpu or self.gpu
            self.cpu_limit = other.cpu_limit or self.cpu_limit
            self.memory_in_gb_limit = other.memory_in_gb_limit or self.memory_in_gb_limit

    @classmethod
    def _from_rest_object(cls, settings: ContainerResourceRequirements) -> "ResourceRequirementsSettings":

        return (
            ResourceRequirementsSettings(
                cpu=settings.cpu,
                memory_in_gb=settings.memory_in_gb,
                gpu=settings.gpu,
                cpu_limit=settings.cpu_limit,
                memory_in_gb_limit=settings.memory_in_gb_limit,
            )
            if settings
            else None
        )

    def __eq__(self, other: "ResourceRequirementsSettings") -> bool:
        if not other:
            return False
        # only compare mutable fields
        return (
            self.cpu == other.cpu
            and self.memory_in_gb == other.memory_in_gb
            and self.gpu == other.gpu
            and self.cpu_limit == other.cpu_limit
            and self.memory_in_gb_limit == other.memory_in_gb_limit
        )

    def __ne__(self, other: "ResourceRequirementsSettings") -> bool:
        return not self.__eq__(other)
