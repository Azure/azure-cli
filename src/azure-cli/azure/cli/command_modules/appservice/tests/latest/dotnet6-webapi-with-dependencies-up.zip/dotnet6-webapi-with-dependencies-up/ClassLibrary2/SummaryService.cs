﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    internal static class SummaryService
    {
        private const string UNKNOWN = "Unknown";

        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        internal static string Get(int? summaryId)
        {
            return summaryId.HasValue && summaryId.Value < Summaries.Length ? Summaries[summaryId.Value] : UNKNOWN;
        }
    }
}
