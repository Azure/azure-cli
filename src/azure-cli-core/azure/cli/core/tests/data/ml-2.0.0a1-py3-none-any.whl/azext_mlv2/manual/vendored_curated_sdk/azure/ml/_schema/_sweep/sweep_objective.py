# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from marshmallow import fields

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models._azure_machine_learning_workspaces_enums import (
    Goal,
)

module_logger = logging.getLogger(__name__)


class SweepObjectiveSchema(metaclass=PatchedSchemaMeta):
    goal = StringTransformedEnum(required=True, allowed_values=[Goal.MINIMIZE, Goal.MAXIMIZE])
    primary_metric = fields.Str(required=True)
