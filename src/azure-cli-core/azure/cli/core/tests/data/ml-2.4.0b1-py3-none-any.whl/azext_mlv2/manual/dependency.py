# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import pkg_resources

REQUIREMENTS = []
with open("azext_mlv2/manual/requirements.txt", "rt") as fd:
    REQUIREMENTS = [str(requirement) for requirement in pkg_resources.parse_requirements(fd)]
DEPENDENCIES = ['azure-identity', 'marshmallow<4.0.0,>=3.5', 'jsonschema<5.0.0,>=4.0.0', 'tqdm<=4.63.0', 'colorama<=0.4.4', 'pyjwt<=2.3.0', 'azure-storage-blob<=12.9.0,>=12.5.0', 'azure-storage-file-share<13.0.0', 'pydash<=4.9.0', 'pathspec==0.9.*', 'isodate', 'docker', 'azure-common<2.0.0,>=1.1', 'typing_extensions<4.0.0,>=3.10', 'applicationinsights<=0.11.10'] + REQUIREMENTS

