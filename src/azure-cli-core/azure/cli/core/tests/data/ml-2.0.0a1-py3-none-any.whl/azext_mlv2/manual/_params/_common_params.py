# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands.parameters import resource_group_name_type, LocalContextAttribute, LocalContextAction, ALL
from azext_mlv2.manual.action import OverridePropertiesBySet


def add_common_params(c):
    c.argument("resource_group_name", resource_group_name_type)
    c.argument(
        "workspace_name",
        options_list=["--workspace-name", "-w"],
        type=str,
        help="Name of the Azure ML workspace."
        " You can configure the default group using `az configure --defaults workspace=<name>`",
        configured_default="workspace",
        local_context_attribute=LocalContextAttribute(
            name="aml_workspace_name", actions=[LocalContextAction.SET, LocalContextAction.GET], scopes=[ALL]
        ),
    )


def add_override_param(c):
    c.argument(
        "params_override",
        options_list=["--set"],
        help="Update an object by specifying a property path and value to set. Example: --set "
        "property1.property2=<value>.",
        action=OverridePropertiesBySet,
        nargs="+",
    )


def add_max_results_params(c):
    c.argument(
        "max_results",
        options_list=["--max-results", "-r"],
        help="Maximum number of results to return.",
    )
