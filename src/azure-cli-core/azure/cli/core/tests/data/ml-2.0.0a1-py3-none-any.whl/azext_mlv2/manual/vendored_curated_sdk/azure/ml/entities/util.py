# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Optional, Any, Dict
from marshmallow.exceptions import ValidationError
import json
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import CommonYamlFields


def find_type_in_override(params_override: list = []) -> Optional[str]:
    for override in params_override:
        if CommonYamlFields.TYPE in override:
            return override[CommonYamlFields.TYPE]
    return None


def load_from_dict(schema: Any, data: Dict, context: Dict, additional_message: str = "", **kwargs):
    try:
        return schema(context=context).load(data, **kwargs)
    except ValidationError as e:
        pretty_error = json.dumps(e.normalized_messages(), indent=2)
        raise ValidationError(f"Validation for {schema.__name__} failed:\n\n {pretty_error} \n\n {additional_message}")
