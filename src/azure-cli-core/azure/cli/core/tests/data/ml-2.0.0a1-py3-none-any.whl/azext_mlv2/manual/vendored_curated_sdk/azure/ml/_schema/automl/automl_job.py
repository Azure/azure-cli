# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import JobType, AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import ComputeBindingSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import BaseJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.automl import (
    AutoMLGeneralSettingsSchema,
    ForecastingSettingsSchema,
    FeaturizationSettingsSchema,
    TrainingSettingsSchema,
    DataSettingsSchema,
    AutoMLLimitsSchema,
)


class AutoMLJobSchema(BaseJobSchema):
    type = StringTransformedEnum(required=True, allowed_values=JobType.AUTOML)
    general_settings = NestedField(AutoMLGeneralSettingsSchema(), data_key=AutoMLConstants.GENERAL_YAML)
    limit_settings = NestedField(AutoMLLimitsSchema(), data_key=AutoMLConstants.LIMITS_YAML)
    data_settings = NestedField(DataSettingsSchema(), data_key=AutoMLConstants.DATA_YAML)
    featurization_settings = NestedField(FeaturizationSettingsSchema(), data_key=AutoMLConstants.FEATURIZATION_YAML)
    forecasting_settings = NestedField(ForecastingSettingsSchema(), data_key=AutoMLConstants.FORECASTING_YAML)
    training_settings = NestedField(TrainingSettingsSchema(), data_key=AutoMLConstants.TRAINING_YAML)
    compute = NestedField(ComputeBindingSchema())
