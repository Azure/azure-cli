# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_model_help():
    helps[
        "ml model"
    ] = """
        type: group
        short-summary: Manage Azure ML models.
        long-summary: >
            Azure ML models consist of the binary file(s) that represent a machine learning
            model and any corresponding metadata.  These models can be used in endpoint
            deployments for real-time and batch inference.
    """
    helps[
        "ml model create"
    ] = """
        type: command
        short-summary: Create a model.
        long-summary: >
            Models can be created from a local file or directory. The created model will be
            tracked in the workspace under the specified name and version.
        examples:
        - name: Create a model from a YAML specification file
          text: az ml model create --file model.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Create a model from a local folder using command options
          text: az ml model create --name my-model --version 1 --path ./my-model --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model show"
    ] = """
        type: command
        short-summary: Show details for a model.
        examples:
        - name: Show details for a model with the specified name and version
          text: az ml model show --name my-model --version 1 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model download"
    ] = """
        type: command
        short-summary: Download all model-related files.
        long-summary: The files will be downloaded into a folder named after the model's name.
        examples:
        - name: Download a model with the specified name and version
          text: az ml model download --name my-model --version 1 --resource-group my-resource-group --workspace-name my-workspace
        - name: Download a model with the specified name and version, into a specified local path
          text: az ml model download --name my-model --version 1  --download-path local_path --resource-group my-resource-group --workspace-name my-workspace

    """

    helps[
        "ml model list"
    ] = """
        type: command
        short-summary: List models in a workspace.
        examples:
        - name: List all the models in a workspace
          text: az ml model list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the model versions for the specified name in a workspace
          text: az ml model list --name my-model --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the models in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml model list --query \"[].{Name:name}\"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model update"
    ] = """
        type: command
        short-summary: Update a model.
        long-summary: >
            The 'description', and 'tags' properties can be updated.
        examples:
        - name: Update a model's flavors
          text: az ml model update --name my-model --version 1 --set flavors.python_function.python_version=3.8 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model archive"
    ] = """
        type: command
        short-summary: Archive a model.
        long-summary: >
            Archiving a model will hide it by default from list queries (`az ml model list`). You
            can still continue to reference and use an archived model in your workflows.
            You can archive either a model container or a specific model version. Archiving a
            model container will archive all versions of the model under that given name.
            You can restore an archived model using `az ml model restore`. If the entire
            model container is archived, you cannot restore individual versions of the model -
            you will need to restore the model container.
        examples:
        - name: Archive a model container (archives all versions of that model)
          text: az ml model archive --name my-model --resource-group my-resource-group --workspace-name my-workspace
        - name: Archive a specific model version
          text: az ml model archive --name my-model --version 1 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model restore"
    ] = """
        type: command
        short-summary: Restore an archived model.
        long-summary: >
            When an archived model is restored, it will no longer be hidden from list queries (`az ml model list`).
            If an entire model container is archived, you can restore that archived container. This
            will restore all versions of the model under that given name. You cannot restore only a
            specific model version if the entire model container is archived - you will need to
            restore the entire container. If only an individual model version was archived, you can
            restore that specific version.
        examples:
        - name: Restore an archived model container (restores all versions of that model \)
          text: az ml model restore --name my-model --resource-group my-resource-group --workspace-name my-workspace
        - name: Restore a specific archived model version
          text: az ml model restore --name my-model --version 1 --resource-group my-resource-group --workspace-name my-workspace
    """
