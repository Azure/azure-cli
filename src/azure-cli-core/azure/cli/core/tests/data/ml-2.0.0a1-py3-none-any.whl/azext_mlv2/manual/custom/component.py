# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict

from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AZUREML_PRIVATE_FEATURES_ENV_VAR, LIMITED_RESULTSET_WARNING_FORMAT
from azure.identity import AzureCliCredential
from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2020_09_01_preview.machinelearningservices.models import ComponentContainer
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Component
from itertools import islice
from .print_error import print_warning, print_error_and_exit, print_warning_with_fore_reset
from .utils import _is_debug_set, _dump_entity_with_warnings


def ml_component_list(cmd, resource_group_name, workspace_name, name=None, max_results=100):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )
    print_warning_with_fore_reset(str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
    try:
        top_n_items = islice(ml_client.components.list(name=name), int(max_results))
        if name:
            return list(map(lambda x: _dump_entity_with_warnings(x), top_n_items))
        else:
            return list(map(lambda x: _dump_component_container_with_warnings(x), top_n_items))
    except Exception as err:
        print_error_and_exit(err)


def ml_component_show(cmd, resource_group_name, workspace_name, name, version=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )
    try:
        component = ml_client.components.get(name=name, version=version)
        return _dump_entity_with_warnings(component)
    except Exception as err:
        print_error_and_exit(err)


def ml_component_create(cmd, file, resource_group_name, workspace_name, version=None, params_override=[]):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )
    try:
        # 1. update override params
        if version:
            params_override.append({"version": version})
        # 2. load to component schema
        component = Component.load(path=file, params_override=params_override)
        # 3. create component
        result = ml_client.components.create_or_update(component)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        print_error_and_exit(err)


def ml_component_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )

    try:
        # 1. load parameters into component entity
        component_entity = Component._load(data=parameters, yaml_path=".")
        # 2. update the component
        result = ml_client.components.create_or_update(component_entity)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        print_error_and_exit(err)


def ml_component_delete(cmd, name, resource_group_name, workspace_name, version=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=_is_debug_set(cmd.cli_ctx),
    )
    try:
        return ml_client.components.delete(name=name, version=version)
    except Exception as err:
        print_error_and_exit(err)


def _dump_component_container_with_warnings(component_container: ComponentContainer) -> Dict:
    try:
        return component_container.as_dict()  # type: ignore
    except Exception as err:
        print_warning("Failed to deserialize response: " + str(err))
        print_warning(str(component_container))
