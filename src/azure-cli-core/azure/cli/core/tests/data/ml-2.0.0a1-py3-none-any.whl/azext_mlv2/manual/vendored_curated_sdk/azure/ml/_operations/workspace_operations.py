# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Any, Iterable, Dict, Optional
import logging
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._arm_deployments.arm_helper import get_template
from azure.core.polling import LROPoller
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices._azure_machine_learning_workspaces import (
    AzureMachineLearningWorkspaces,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import (
    Workspace as RestWorkspace,
    ListWorkspaceKeysResult,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._arm_deployments import ArmDeploymentExecutor
from azure.identity import ChainedTokenCredential
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import ArmConstants, WorkspaceResourceConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._workspace_utils import (
    delete_resource_by_arm_id,
    get_deployment_name,
    get_resource_group_location,
    get_name_for_dependent_resource,
    get_resource_and_group_name,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Workspace
from marshmallow import RAISE
from azure.core.exceptions import ResourceExistsError


module_logger = logging.getLogger(__name__)


class WorkspaceOperations:
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: AzureMachineLearningWorkspaces,
        all_operations: OperationsContainer,
        credentials: ChainedTokenCredential = None,
        **kwargs: Dict,
    ):
        self._subscription_id = workspace_scope.subscription_id
        self._resource_group_name = workspace_scope.resource_group_name
        self._default_workspace_name = workspace_scope.workspace_name
        self._all_operations = all_operations
        self._operation = service_client.workspaces
        self._credentials = credentials
        self._init_kwargs = kwargs
        self.storage = None
        self.appInsights = None
        self.keyVault = None
        self.resources_being_deployed = {}
        self.containerRegistry = "none"

    def list(self, scope: str = "resource_group") -> Iterable[Workspace]:
        """List all workspaces that the user has access to in the current resource group or subscription

        :param scope: scope of the listing, "resource_group" or "subscription", defaults to "resource_group"
        :type scope: str, optional
        :return: A list of workspaces.
        :rtype: Iterable[Workspace]
        """

        wps_list = None
        if scope == "subscription":
            wps_list = self._operation.list_by_subscription()
        else:
            wps_list = self._operation.list_by_resource_group(self._resource_group_name)
        return [Workspace._from_rest_object(obj) for obj in wps_list]

    def get(self, name: str = None) -> Workspace:
        """Get a workspace by name.

        :param name: Name of the workspace.
        :type name: str
        :return: The workspace with the provided name.
        :rtype: Workspace
        """

        workspace_name = self._check_workspace_name(name)
        obj = self._operation.get(self._resource_group_name, workspace_name)
        return Workspace._from_rest_object(obj)

    def list_keys(self, name: str = None) -> ListWorkspaceKeysResult:
        """List keys for the workspace.

        :param name: Name of the workspace.
        :type name: str
        :return: A list of keys.
        :rtype: ListWorkspaceKeysResult
        """

        workspace_name = self._check_workspace_name(name)
        return self._operation.list_keys(self._resource_group_name, workspace_name)

    def sync_keys(self, name: str = None) -> None:
        """Triggers the workspace to immediately synchronize keys.
        If keys for any resource in the workspace are changed, it can take around an hour for them to automatically be updated. This function enables keys to be updated upon request. An example scenario is needing immediate access to storage after regenerating storage keys.

        :param name: Name of the workspace.
        :type name: str
        """

        workspace_name = self._check_workspace_name(name)
        return self._operation.resync_keys(self._resource_group_name, workspace_name)

    def create(self, workspace: Workspace, no_wait: bool = False, **kwargs: Any) -> Optional[Workspace]:
        """Create a new Azure Machine Learning Workspace.

        Returns the workspace if already exists.

        :param workspace: Workpace definition.
        :type workspace: Workspace
        :param no_wait: Wheather to wait for the workspace creation to complete, defaults to False
        :type no_wait: bool, optional

        :raises ResourceExistsError: If the workspace already exists

        :return: The created workspace or the existing workspace, None is returned when no_wait is True.
        :rtype: Optional[Workspace]
        """
        existing_workspace = None
        try:
            existing_workspace = self.get(workspace.name)
        except Exception:
            pass

        if existing_workspace:
            raise ResourceExistsError(f"Workspace with name {workspace.name} already exists.")
        else:
            self._populate_arm_paramaters(workspace)

        arm_submit = ArmDeploymentExecutor(
            credentials=self._credentials,
            resource_group_name=self._resource_group_name,
            subscription_id=self._subscription_id,
            deployment_name=get_deployment_name(workspace.name),
        )
        arm_submit.deploy_resource(
            template=self.template,
            resources_being_deployed=self.resources_being_deployed,
            parameters=self.param,
            wait=not no_wait,
        )

        if no_wait:
            return
        else:
            return self.get(workspace.name)

    def update(
        self, name: str = None, tags: dict = None, description: str = None, friendly_name: str = None, **kwargs: Any
    ) -> Workspace:
        """Update friendly name, description, tags, and other settings associated with a workspace.

        :param name: Name of the workspace, defaults to the workspace of the MLClient object.
        :type name: str, optional
        :param tags: Tags to set on the workspace, defaults to None
        :type tags: dict, optional
        :param description: Description of the workpace, defaults to None
        :type description: str, optional
        :param friendly_name: friendly name of the workspace, defaults to None
        :type friendly_name: str, optional
        :return: The updated workspace
        :rtype: Workspace
        """
        name = name or self._default_workspace_name
        update_param = {
            "tags": tags,
            "description": description,
            "friendly_name": friendly_name,
        }

        updated_ws = self._operation.update(self._resource_group_name, workspace_name=name, parameters=update_param)
        return Workspace._from_rest_object(updated_ws)

    def delete(self, name: str, delete_dependent_resources: bool, no_wait: bool = False) -> LROPoller:
        """Delete a workspace

        :param name: Name of the workspace
        :type name: str
        :param delete_dependent_resources: Whether to delete resources associated with the workspace, i.e., container registry, storage account, key vault, and application insights. The default is False. Set to True to delete these resources.
        :type delete_dependent_resources: bool
        :param no_wait: Whether to wait for the workspace deletion to complete, defaults to False
        :type no_wait: bool
        :raises response_exception: [description]
        :return: A poller to track the deletion status.
        :rtype: LROPoller
        """

        try:
            workspace = self.get(name)
            if delete_dependent_resources:
                delete_resource_by_arm_id(
                    self._credentials,
                    self._subscription_id,
                    workspace.application_insights,
                    ArmConstants.AZURE_MGMT_APPINSIGHT_API_VERSION,
                )
                delete_resource_by_arm_id(
                    self._credentials,
                    self._subscription_id,
                    workspace.storage_account,
                    ArmConstants.AZURE_MGMT_STORAGE_API_VERSION,
                )
                delete_resource_by_arm_id(
                    self._credentials,
                    self._subscription_id,
                    workspace.key_vault,
                    ArmConstants.AZURE_MGMT_KEYVAULT_API_VERSION,
                )
                delete_resource_by_arm_id(
                    self._credentials,
                    self._subscription_id,
                    workspace.container_registry,
                    ArmConstants.AZURE_MGMT_CONTAINER_REG_API_VERSION,
                )

            return self._operation.begin_delete(self._resource_group_name, name, polling=not no_wait)
        except Exception as response_exception:
            raise response_exception

    def _populate_arm_paramaters(self, workspace: Workspace) -> None:
        if not workspace.location:
            workspace.location = get_resource_group_location(
                self._credentials, self._subscription_id, self._resource_group_name
            )

        self.template = get_template(resource_type=ArmConstants.WORKSPACE_BASE)
        self.param = get_template(resource_type=ArmConstants.WORKSPACE_PARAM)
        self._set_val(self.param["workspaceName"], workspace.name)
        if not workspace.friendly_name:
            self._set_val(self.param["friendlyName"], workspace.name)
        else:
            self._set_val(self.param["friendlyName"], workspace.friendly_name)

        if not workspace.description:
            self._set_val(self.param["description"], workspace.name)
        else:
            self._set_val(self.param["description"], workspace.description)
        self._set_val(self.param["location"], workspace.location)
        self._set_val(self.param["resourceGroupName"], self._resource_group_name)

        if workspace.key_vault:
            resource_name, group_name = get_resource_and_group_name(workspace.key_vault)
            self._set_val(self.param["keyVaultName"], resource_name)
            self._set_val(self.param["keyVaultOption"], "existing")
            self._set_val(self.param["keyVaultResourceGroupName"], group_name)
        else:
            self._generate_key_vault(workspace.name)
            self._set_val(self.param["keyVaultName"], self.keyVault)
            self._set_val(self.param["keyVaultResourceGroupName"], self._resource_group_name)

        if workspace.storage_account:
            resource_name, group_name = get_resource_and_group_name(workspace.storage_account)
            self._set_val(self.param["storageAccountName"], resource_name)
            self._set_val(self.param["storageAccountOption"], "existing")
            self._set_val(self.param["storageAccountResourceGroupName"], group_name)
        else:
            self._generate_storage(workspace.name)
            self._set_val(self.param["storageAccountName"], self.storage)
            self._set_val(self.param["storageAccountResourceGroupName"], self._resource_group_name)

        if workspace.application_insights:
            resource_name, group_name = get_resource_and_group_name(workspace.application_insights)
            self._set_val(self.param["applicationInsightsName"], resource_name)
            self._set_val(self.param["applicationInsightsOption"], "existing")
            self._set_val(
                self.param["applicationInsightsResourceGroupName"],
                group_name,
            )
        else:
            self._generate_appInsights(workspace.name)
            self._set_val(self.param["applicationInsightsName"], self.appInsights)
            self._set_val(self.param["applicationInsightsResourceGroupName"], self._resource_group_name)

        if workspace.container_registry:
            resource_name, group_name = get_resource_and_group_name(workspace.container_registry)
            self._set_val(self.param["containerRegistryName"], resource_name)
            self._set_val(self.param["containerRegistryOption"], "existing")
            self._set_val(self.param["containerRegistryResourceGroupName"], group_name)

        if workspace.customer_managed_key:
            self._set_val(self.param["cmk_keyvault"], workspace.customer_managed_key.key_vault)
            self._set_val(self.param["resource_cmk_uri"], workspace.customer_managed_key.key_uri)
            self._set_val(self.param["encryption_status"], WorkspaceResourceConstants.ENCRYPTION_STATUS_ENABLED)

        if workspace.hbi_workspace:
            self._set_val(self.param["confidential_data"], "true")

        if workspace.private_endpoints:
            endpoint_details = workspace.private_endpoints.connections
            for key in endpoint_details.keys():
                self._set_val(self.param["privateEndpointName"], key)
                self._set_val(self.param["subnetName"], endpoint_details[key].subnet_name)
                self._set_val(self.param["vnetName"], endpoint_details[key].vnet_name)
                self._set_val(self.param["vnetResourceGroupName"], endpoint_details[key].resource_group)
                self._set_val(self.param["privateEndpointType"], workspace.private_endpoints.approval_type)
                self._set_val(self.param["privateEndpointResourceGroupName"], endpoint_details[key].resource_group)

        if workspace.tags:
            for key, val in workspace.tags.items():
                self.param["tagValues"]["value"][key] = val

        self.resources_being_deployed[workspace.name] = (ArmConstants.WORKSPACE, None)

    def _set_val(self, key: str, val: str) -> None:
        key["value"] = val

    def _generate_key_vault(self, name: str) -> None:
        # Vault name must only contain alphanumeric characters and dashes and cannot start with a number.
        # Vault name must be between 3-24 alphanumeric characters.
        # The name must begin with a letter, end with a letter or digit, and not contain consecutive hyphens.
        self.keyVault = get_name_for_dependent_resource(name, "keyvault")
        self.resources_being_deployed[self.keyVault] = (ArmConstants.KEY_VAULT, None)

    def _generate_storage(self, name: str) -> None:
        self.storage = get_name_for_dependent_resource(name, "storage")
        self.resources_being_deployed[self.storage] = (ArmConstants.STORAGE, None)

    def _generate_appInsights(self, name: str) -> None:
        # Application name only allows alphanumeric characters, periods, underscores,
        # hyphens and parenthesis and cannot end in a period
        self.appInsights = get_name_for_dependent_resource(name, "insights")
        self.resources_being_deployed[self.appInsights] = (ArmConstants.APP_INSIGHTS, None)

    def _check_workspace_name(self, name) -> str:
        workspace_name = name or self._default_workspace_name
        if not workspace_name:
            raise Exception("Please provide a workspace name or use a MLClient with a workspace name set.")
        else:
            return workspace_name
