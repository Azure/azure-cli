# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict, Optional, Union
from os import PathLike
from abc import abstractmethod
from pathlib import Path

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities.assets.asset import Asset
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import is_url
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient._2021_03_01_preview.machinelearningservices.models import SystemData


class Artifact(Asset):
    """Base class for artifact, can't be instantiated directly.

    :param name: Name of the resource.
    :type name: str
    :param id:  Global id of the resource, Azure Resource Manager ID.
    :type id: str
    :param version: Version of the resource.
    :type version: int
    :param local_path: The local path to the asset.
    :type local_path: Union[str, os.PathLike]
    :param datastore: Azure Resource Manager ID of the datastore where the asset is stored.
    :type datastore: str
    :param path: The remote path to the asset on the datastore.
    :type path: str
    :param base_path: TBD.
    :type base_path: str
    :param description: Description of the resource.
    :type description: str
    :param creation_context: Creation metadata of the asset.
    :type creation_context: SystemData
    :param tags: Internal use only.
    :type tags: dict
    :param properties: Internal use only.
    :type properties: dict
    :param kwargs: A dictionary of additional configuration parameters.
    :type kwargs: dict
    """

    def __init__(
        self,
        name: str = None,
        id: str = None,
        version: int = None,
        local_path: Optional[Union[str, PathLike]] = None,
        datastore: str = None,
        path: str = None,
        base_path: str = None,
        description: str = None,
        creation_context: SystemData = None,
        tags: Dict = None,
        properties: Dict = None,
        **kwargs,
    ):
        super().__init__(
            name=name,
            id=id,
            base_path=base_path,
            version=version,
            description=description,
            creation_context=creation_context,
            tags=tags,
            properties=properties,
            **kwargs,
        )

        # These attributes are not intended to be changed by users, only retrieved
        self._datastore = datastore
        self._path = path
        self._local_path = Path(self.base_path, local_path).resolve() if (local_path and self.base_path) else local_path

    @property
    def datastore(self) -> Optional[str]:
        return self._datastore

    @property
    def path(self) -> Optional[str]:
        return self._path

    @property
    def local_path(self) -> Optional[Union[str, PathLike]]:
        return self._local_path

    @abstractmethod
    def _dump_yaml(self) -> Dict:
        pass

    def __eq__(self, other) -> bool:
        return (
            type(self) == type(other)
            and self.name == other.name
            and self.id == other.id
            and self.version == other.version
            and self.description == other.description
            and self.tags == other.tags
            and self.properties == other.properties
            and self.base_path == other.base_path
            and self._is_anonymous == other._is_anonymous
            and self.local_path == other.local_path
            and self.path == other.path
            and self.datastore == other.datastore
        )

    def __ne__(self, other) -> bool:
        return not self.__eq__(other)

    def _validate(self) -> None:
        if self.path and not is_url(self.path) and not self.datastore:
            raise ValueError(
                f"When asset's path {self.path} is not an URL, the datastore reference needs to be specified"
            )
