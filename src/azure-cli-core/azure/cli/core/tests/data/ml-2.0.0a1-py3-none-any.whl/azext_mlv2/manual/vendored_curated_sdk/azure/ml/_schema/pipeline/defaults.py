# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import post_load

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import (
    PatchedSchemaMeta,
    UnionField,
    AnonymousCodeAssetSchema,
    ArmVersionedStr,
    NestedField,
    ArmStr,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.environment import AnonymousEnvironmentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.compute_binding import ComputeBindingSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.constants import AzureMLResourceType, JobType


class PipelineJobDefaultsSchema(metaclass=PatchedSchemaMeta):
    code = UnionField(
        [
            NestedField(AnonymousCodeAssetSchema),
            ArmVersionedStr(azureml_type=AzureMLResourceType.CODE),
        ],
        metadata={"description": "A file:, http:, https:, or azureml: url pointing to an AzureML instance."},
    )
    environment = UnionField(
        [
            NestedField(AnonymousEnvironmentSchema),
            ArmVersionedStr(azureml_type=AzureMLResourceType.ENVIRONMENT),
            ArmStr(azureml_type=AzureMLResourceType.ENVIRONMENT),  # support arm str without version
        ]
    )
    datastore = ArmStr(azureml_type=AzureMLResourceType.DATASTORE)
    compute = NestedField(ComputeBindingSchema)

    @post_load
    def make(self, data, **kwargs) -> "PipelineJobDefaults":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import PipelineJobDefaults

        return PipelineJobDefaults(**data)
