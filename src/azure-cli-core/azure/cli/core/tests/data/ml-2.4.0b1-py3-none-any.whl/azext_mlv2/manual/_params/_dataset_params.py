# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param, add_max_results_params
from azure.cli.core.commands.parameters import tags_type


def load_dataset_params(self):
    with self.argument_context("ml dataset list") as c:
        add_common_params(c)
        c.argument(
            "name",
            options_list=["--name", "-n"],
            type=str,
            help="Name of the data asset. If provided, all the data versions under this name will be returned.",
        )
        add_max_results_params(c)

    with self.argument_context("ml dataset show") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the data asset.")
        c.argument(
            "version",
            options_list=["--version", "-v"],
            help="Version of the data asset.",
        )
        c.argument("label", options_list=["--label", "-l"], help="Label of the data asset.")

    with self.argument_context("ml dataset create") as c:
        add_common_params(c)
        add_override_param(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the dataset.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the dataset.")
        c.argument("description", options_list=["--description", "-d"], help="Description of the dataset.")
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML dataset specification.",
        )
        c.argument(
            "paths",
            options_list=["--paths", "-p"],
            help="Path of data in supported URI formats to create the dataset. Examples: 'folder:azureml://datastores/mydatastore/paths/path_to_data/', 'file:azureml://datastores/mydatastore/paths/path_to_data/myfile.csv'",
        )
        c.argument(
            "local_path", options_list=["--local-path", "-l"], help="Local file or folder path to create the dataset."
        )
        c.argument("tags", tags_type, help="Space-separated tags for the dataset.")

    with self.argument_context("ml dataset update") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the data asset.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the data asset.")
        c.argument("label", options_list=["--label", "-l"], help="Label of the data asset.")
