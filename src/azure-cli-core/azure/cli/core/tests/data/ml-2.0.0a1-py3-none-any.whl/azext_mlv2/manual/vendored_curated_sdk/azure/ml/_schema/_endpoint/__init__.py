# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

__path__ = __import__("pkgutil").extend_path(__path__, __name__)


from .batch.batch_endpoint import BatchEndpointSchema
from .online.online_endpoint import K8sOnlineEndpointSchema, ManagedOnlineEndpointSchema
from .code_configuration_schema import CodeConfigurationSchema

__all__ = [
    "BatchEndpointSchema",
    "K8sOnlineEndpointSchema",
    "ManagedOnlineEndpointSchema",
    "CodeConfigurationSchema",
]
