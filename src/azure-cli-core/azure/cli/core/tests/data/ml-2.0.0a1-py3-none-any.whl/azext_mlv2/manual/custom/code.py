# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml import MLClient
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from .print_error import print_error_and_exit
from .utils import _is_debug_set, _dump_entity_with_warnings


def ml_code_show(cmd, resource_group_name, workspace_name, name, version):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
        debug=debug,
    )

    try:
        code = ml_client.code.get(name=name, version=version)
        return _dump_entity_with_warnings(code)
    except Exception as err:
        print_error_and_exit(err, debug)
